/* Owner-confirmed wording. No backend writes and no AI/network calls. */
(function () {
  const MAX_AUTOMATIC_ROW_AGE_MS = 24 * 60 * 60 * 1000;
  const normalize = value => String(value || '').replace(/\s+/g,' ').trim();
  function classify(status,remarks='') {
    const raw=normalize(status), text=normalize(raw+' '+remarks);
    if(/(?:closed|close).{0,35}(?:contact|live\s*chat)|(?:contact|live\s*chat).{0,35}(?:closed|close)/i.test(text)) return {kind:'manual',reason:'Closed — contact LiveChat. An operator must confirm the cause.'};
    if(/(?:unfinish(?:ed)?|unfished|incomplete|remaining|未完成).{0,18}(?:turnover|流水)|(?:turnover|流水).{0,18}(?:unfinish|unfished|incomplete|remaining|未完成)/i.test(text)) {
      const m=text.match(/(?:turnover|流水)\s*(?:shortfall|remaining|balance)?\s*[:：=]?\s*(?:RM|MYR)?\s*(-?\d+(?:,\d{3})*(?:\.\d{1,2})?)(?![\d.])/i);
      if(!m) return {kind:'manual',reason:'Turnover shortfall is not explicit. Confirm the remaining amount manually.'};
      const amount=Math.abs(Number(m[1].replace(/,/g,'')));
      return amount>0?{kind:'turnover',remaining:amount}:{kind:'manual',reason:'Turnover amount needs confirmation.'};
    }
    if(/^payment\s*(?:is\s*)?closed[.!]?$/i.test(raw))return {kind:'payment-closed'};
    if(/^(?:processing|in\s*(?:process|progress)|pending\s*processing)[.!]?$/i.test(raw))return {kind:'processing'};
    return {kind:'manual',reason:'This status has no confirmed mapping. Ask an operator; do not infer its meaning.'};
  }
  function reply(result) {
    if(result.kind==='processing')return 'We are currently handling a large number of withdrawal requests, and our team is working through them as quickly as possible. Your withdrawal is also in the process and will be credited to your bank account once it is completed. We truly appreciate your patience and understanding during this time.';
    if(result.kind==='payment-closed')return 'Kindly resubmit your withdrawal request again. We truly appreciate your patience and cooperation.';
    if(result.kind==='turnover'&&Number.isFinite(result.remaining)&&result.remaining>0)return 'Upon checking, you still need to bet RM'+result.remaining.toLocaleString('en-US',{maximumFractionDigits:2})+' more to meet the turnover requirement for withdrawal.';
    return '';
  }
  const member=value=>(String(value||'').split(/\r?\n/).map(line=>line.trim().replace(/^\+\s*/,'')) .find(line=>line&&!/^\([^)]*\)$/.test(line))||'').replace(/\s*\([^)]*\)\s*$/,'').toLowerCase();
  function headerColumns(cells) {
    const labels=cells.map(value=>normalize(value).toLowerCase().replace(/[^a-z]/g,''));
    const index=(...names)=>labels.findIndex(x=>names.includes(x));
    const cols={id:index('noid','id','no','transactionid','withdrawalid'),status:index('status','withdrawstatus','withdrawalstatus'),member:index('useragent','user','member','memberaccount','username'),currency:index('currency'),amount:index('amount','withdrawamount','withdrawalamount'),time:index('timeconfirmtime','time','requesttime','createdat'),remarks:index('remarks','remark','reason','rejectreason')};
    return ['id','status','member','currency','amount'].every(key=>cols[key]>=0)?cols:null;
  }
  function extract(matrix) {
    const rows=matrix.map(row=>row.map(value=>String(value||'').trim()));let header=-1,cols;
    for(let i=0;i<Math.min(rows.length,30);i++){const found=headerColumns(rows[i]);if(found){header=i;cols=found;break;}}
    if(header<0)return [];
    const out=[],seen=new Set();
    for(const cells of rows.slice(header+1)) {
      const at=name=>cols[name]>=0?cells[cols[name]]||'':'';
      const ids=at('id').match(/\d{4,}/g),id=ids?.at(-1);if(!id||seen.has(id))continue;
      const who=member(at('member')),currency=normalize(at('currency')).toUpperCase(),amountText=at('amount').replace(/,/g,'').trim();
      if(!who||!/^\d+(?:\.\d{1,2})?$/.test(amountText))continue;
      const status=at('status'),result=classify(status,at('remarks'));
      const times=at('time').match(/\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}/g)||[];
      out.push({id,member:who,currency,amount:Number(amountText),status:normalize(status).slice(0,400),requestedAt:times[0]||'',confirmedAt:times[1]||'',result});seen.add(id);
    }
    return out;
  }
  function fingerprint(row){return JSON.stringify([row.id,row.member,row.currency,row.amount,row.status,row.requestedAt,row.confirmedAt,row.result]);}
  function searchRange(days,now=new Date()) {
    if(![1,7,30].includes(days))throw new Error('Choose a 1, 7 or 30 day search window.');
    const format=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kuala_Lumpur',year:'numeric',month:'2-digit',day:'2-digit'});
    const today=format.format(now),start=new Date(today+'T00:00:00+08:00');start.setTime(start.getTime()-(days-1)*86400000);
    return {from:format.format(start)+' 00:00:00',to:today+' 23:59:59'};
  }
  function choose(rows,username,reference='') {
    const matches=rows.filter(row=>row.member===member(username)&&(reference?row.id===String(reference).trim():true));
    if(!matches.length)return {error:'No matching withdrawal in this report range. Widen the date range or check manually.'};
    if(matches.length>1)return {error:'Several withdrawals match. Select the exact reference below before drafting.'};
    if(matches[0].currency!=='MYR')return {error:'This is not a MYR withdrawal; an operator must check it.'};
    if(!reply(matches[0].result))return {error:matches[0].result.reason||'This status needs an operator check.'};
    return {row:matches[0]};
  }
  function containsBackendReply(text) {
    const value=normalize(text).toLowerCase();
    return value.includes(normalize(reply({kind:'processing'})).toLowerCase())||value.includes(normalize(reply({kind:'payment-closed'})).toLowerCase())||/upon checking, you still need to bet rm[\d,.]+ more to meet the turnover requirement for withdrawal[.]/i.test(value);
  }
  function rowAge(row,now=Date.now()) {
    const raw=String(row.requestedAt||'').trim();
    const explicit=/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:Z|[+-]\d{2}:\d{2})$/.test(raw);
    const plain=/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(raw);
    if(!explicit&&!plain)return {safe:false,label:'Age unknown (requested time missing or invalid)'};
    const parts=raw.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})/);
    if(!parts||Number(parts[4])>23||Number(parts[5])>59||Number(parts[6])>59||new Date(Date.UTC(Number(parts[1]),Number(parts[2])-1,Number(parts[3]))).toISOString().slice(0,10)!==raw.slice(0,10))return {safe:false,label:'Age unknown (invalid time)'};
    const base=Date.parse(raw.replace(' ','T')+(plain?'Z':''));
    if(!Number.isFinite(base)||new Date(base).toISOString().slice(0,10)!==raw.slice(0,10)&&plain)return {safe:false,label:'Age unknown (invalid time)'};
    // No report timezone is known. Bound a naive time across UTC-12 through UTC+14.
    const youngest=now-base-(plain?12*3600000:0),oldest=now-base+(plain?14*3600000:0);
    const days=Math.floor(youngest/86400000),hours=Math.floor(youngest/3600000);
    const label=youngest<0?'Time may be in the future':days>=1?days+' day'+(days===1?'':'s')+' ago':hours>=1?hours+' hour'+(hours===1?'':'s')+' ago':'Less than an hour ago';
    return {safe:youngest>=0&&oldest<=MAX_AUTOMATIC_ROW_AGE_MS,label:youngest<0?'Age unverified (requested time or timezone needs checking)':(plain?'At least ':'')+label+(plain?' (timezone unverified)':'')};
  }
  function draftGuard({row,reference='',confirmed=false,pagination=false,manual=false,now=Date.now()}) {
    if(reference&&String(reference).trim()!==row.id)return 'The entered withdrawal reference does not match this row.';
    if(!rowAge(row,now).safe&&!reference&&!confirmed)return 'The requested time is older than 24 hours or its age is unverified. Enter the exact reference or confirm this is the withdrawal the customer asked about.';
    if(pagination&&!reference&&!manual)return 'More than one report page may exist. Enter the exact withdrawal reference or use the manual check.';
    return '';
  }
  function hasPagination(texts) {
    if(texts.filter(value=>/^\s*\d+\s*$/.test(value)).length>1)return true;
    return texts.some(value=>{
      const text=normalize(value);
      const pages=text.match(/\bpage\s*(\d+)\s*(?:of|\/)\s*(\d+)\b/i)||text.match(/第\s*(\d+)\s*页\s*(?:共|[\/／])\s*(\d+)\s*页/);
      return /^(?:\d+\s+){1,}\d+$/.test(text)||!!(pages&&Number(pages[2])>1)||/^(?:next(?:\s+page)?|last(?:\s+page)?|下一页|下页|末页|尾页|[›»])\s*[›»→]?$/i.test(text);
    });
  }
  const api={normalize,classify,reply,member,headerColumns,extract,fingerprint,searchRange,choose,rowAge,draftGuard,hasPagination,MAX_AUTOMATIC_ROW_AGE_MS,containsBackendReply};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  else globalThis.SRWithdrawalRules=api;
})();
