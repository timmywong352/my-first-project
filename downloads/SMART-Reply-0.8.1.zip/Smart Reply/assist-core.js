/* Local routing only. No AI, network, storage or backend values. */
(function(){
  function gameAccessClarification(text,lang){
    const value=String(text||'').normalize('NFKC').toLowerCase();
    const matched=/游戏.{0,12}(?:(?:不能|无法).{0,4}(?:进|打开|加载)|进不|打不开|进不了)|(?:不能|无法).{0,6}(?:进入|打开|加载)游戏|\b(?:game|games)\b.{0,25}\b(?:not (?:loading|opening|working)|won['’]?t (?:load|open)|cannot (?:load|open))\b|\b(?:can['’]?t|cannot|unable to)\b.{0,15}\b(?:enter|open|load|access)\b.{0,15}\b(?:game|games)\b|\b(?:tak|tidak)\s+(?:boleh|dapat)\s+(?:masuk|buka)\s+game\b/.test(value);
    if(!matched)return '';
    return lang==='zh'?'请问您无法进入哪一款游戏？页面有显示什么错误提示吗？方便的话，请提供截图，以便我们进一步了解问题。':lang==='ms'?'Permainan mana yang tidak dapat anda buka? Adakah sebarang mesej ralat dipaparkan? Jika boleh, sila berikan tangkap layar supaya kami dapat memahami masalah tersebut.':'Which game are you unable to open? Do you see an error message? If possible, please share a screenshot so we can understand the problem.';
  }
  function route(text){
    const value=String(text||'').normalize('NFKC').toLowerCase();
    if(/\b(?:credited|received|missing|already\s+claimed|claim\s+status)\b|到账|没收到|是否领取/.test(value))return {kind:'manual',reason:'Account-specific receipt or claim status needs a manual tool choice.'};
    const kinds=[];
    if(/\b(?:withdraw(?:al)?|cash\s*out|payout|pengeluaran|keluar\s+duit|wd)\b|提款|提现|出款/.test(value))kinds.push('withdrawal');
    if(/\b(?:promo(?:tion)?|bonus|free\s*spins?|deposit\s*bonus)\b|优惠|活动详情|红利|免费旋转|\b\d{1,3}%/.test(value))kinds.push('promotion');
    if(/\b(?:balance|account\s*(?:overview|summary)|baki)\b|余额|账户概况/.test(value))kinds.push('account');
    if(/\b(?:rebate|cashback|turnover|winover)\b|返水|流水/.test(value))return {kind:'manual',reason:'Rebate/turnover needs an explicit tool choice and current rules.'};
    if(!kinds.length&&gameAccessClarification(value,'en'))return {kind:'clarification',reason:'Game access question: ask for the game and error details.'};
    if(kinds.length!==1)return {kind:'manual',reason:kinds.length?'Several enquiry types were found. Choose one.':'Choose a supported enquiry type or use the existing Reply tools.'};
    return {kind:kinds[0],reason:'Suggested from the latest customer message. Confirm the intended enquiry.'};
  }
  function deposit(text){
    const matches=[...String(text||'').matchAll(/(?:\b(?:deposit|depo|top\s*up)\b|存款|充值)\s*(?:of\s*)?(?:rm|myr)?\s*(\d+(?:,\d{3})*(?:\.\d{1,2})?)(?![\d.])/gi)];
    if(matches.length!==1)return null;
    const value=Number(matches[0][1].replace(/,/g,''));return Number.isFinite(value)&&value>0?value:null;
  }
  function members(candidates){
    const out=[];
    for(const item of candidates||[]){if(item.source==='Chat display name — unverified login'||!/^[a-zA-Z0-9_.-]{1,255}$/.test(item.username||''))continue;if(!out.some(other=>other.username.toLowerCase()===item.username.toLowerCase()))out.push(item);}
    return out;
  }
  const api={route,deposit,members,gameAccessClarification};if(typeof module!=='undefined'&&module.exports)module.exports=api;else globalThis.SRAssistCore=api;
})();
