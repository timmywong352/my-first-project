/* IndexedDB v2 preserves the v0.4.0 transcript and knowledge stores. */
const HubStore={
  open(){return new Promise((resolve,reject)=>{let blocked=false;const req=indexedDB.open('smart-reply-archives',2);req.onupgradeneeded=()=>{for(const name of ['threads','meta','knowledge','annotations'])if(!req.result.objectStoreNames.contains(name))req.result.createObjectStore(name,{keyPath:name==='meta'?'id':'key'});};req.onsuccess=()=>{if(blocked){req.result.close();return;}req.result.onversionchange=()=>req.result.close();resolve(req.result);};req.onerror=()=>reject(req.error);req.onblocked=()=>{blocked=true;reject(new Error('Close old Archive Insights tabs, then reload Knowledge Hub.'));};});},
  read(db,store,key){return new Promise((resolve,reject)=>{const req=db.transaction(store).objectStore(store)[key===undefined?'getAll':'get'](key);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});},
  write(db,changes){return new Promise((resolve,reject)=>{const tx=db.transaction(Object.keys(changes),'readwrite');for(const [name,rows]of Object.entries(changes))for(const row of rows)tx.objectStore(name).put(row);tx.oncomplete=resolve;tx.onabort=()=>reject(tx.error||new Error('Local storage failed; the batch was not saved.'));tx.onerror=()=>{};});},
  remove(db,store,key){return new Promise((resolve,reject)=>{const tx=db.transaction(store,'readwrite');tx.objectStore(store).delete(key);tx.oncomplete=resolve;tx.onabort=()=>reject(tx.error);});}
};
if(typeof module!=='undefined'&&module.exports)module.exports=HubStore;
