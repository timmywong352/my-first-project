/* Search-only automation for the exact withdrawal report form. */
(function () {
  const allowed=()=>location.origin==='https://mcd88.kg8.co'&&location.pathname==='/website/withdraw/withdraw_report.php';
  const clean=value=>String(value||'').toLowerCase().replace(/[^a-z0-9]/g,'');
  const visible=element=>element.getClientRects().length>0&&!element.disabled;
  function label(element){const cell=element.closest('td');return [element.getAttribute('aria-label'),...(Array.from(element.labels||[]).map(l=>l.textContent)),cell?.previousElementSibling?.textContent].filter(Boolean).join(' ');}
  function unique(elements,pattern,namePattern){const byLabel=elements.filter(e=>pattern.test(clean(label(e))));if(byLabel.length===1)return byLabel[0];if(byLabel.length>1)return null;const byName=elements.filter(e=>namePattern.test(clean(e.name||e.id)));return byName.length===1?byName[0]:null;}
  function locate(){
    if(!allowed())return {error:'Not the authorized withdrawal report page.'};
    if(document.querySelector('input[type="password"]'))return {error:'Log in yourself and open the withdrawal report.'};
    const matches=[];
    for(const form of Array.from(document.forms)){
      const action=new URL(form.getAttribute('action')||location.href,document.baseURI||location.href);
      if(action.origin!==location.origin||action.pathname!==location.pathname)continue;
      if(form.target&&!['_self',window.name].includes(form.target))continue;
      const controls=Array.from(form.elements).filter(visible);
      const fields=controls.filter(e=>e.tagName==='INPUT'&&!['hidden','password','submit','button','reset','checkbox','radio','image','file'].includes(e.type));
      const member=unique(fields,/^(?:memberaccount|memberusername|username|loginusername)$/,/^(?:memberaccount|memberusername|username|loginusername|smember|susername|member)$/);
      const from=unique(fields,/^(?:datestart|startdate|fromdate|datefrom)$/,/^(?:datestart|startdate|fromdate|datefrom|sdate)$/);
      const to=unique(fields,/^(?:dateend|enddate|todate|dateto)$/,/^(?:dateend|enddate|todate|dateto|edate)$/);
      const buttons=controls.filter(e=>['INPUT','BUTTON'].includes(e.tagName)&&['submit','button','image'].includes(e.type));
      const submits=buttons.filter(e=>e.type==='submit'&&/^(?:submit|search|查询|提交|搜索)$/i.test(String(e.value||e.textContent||e.alt||'').trim()));
      if(!member||!from||!to||submits.length!==1)continue;
      if(buttons.some(e=>/^(?:approve|reject|pay|payout|cancel withdrawal|delete|resubmit|confirm payment|批准|拒绝|付款|出款|取消|删除|重新提交|确认付款)$/i.test(String(e.value||e.textContent||'').trim())))continue;
      const selects=controls.filter(e=>e.tagName==='SELECT');
      matches.push({form,member,from,to,button:submits[0],currency:unique(selects,/^currency$/,/^(?:currency|scurrency|currencytype)$/),status:unique(selects,/^status$/,/^(?:status|sstatus)$/)});
    }
    if(matches.length!==1)return {error:matches.length?'Several search forms match. Open the intended report in a separate tab.':'Could not identify one report search form. Use manual search and share the field labels or sanitized form HTML for adjustment.'};
    return matches[0];
  }
  function documentId(){return globalThis.__SRWithdrawalDocumentId||(globalThis.__SRWithdrawalDocumentId=Date.now().toString(36)+'-'+Math.random().toString(36).slice(2));}
  function inspect(){const found=locate();return found.error?{ready:false,error:found.error}:{ready:true,documentId:documentId()};}
  function setInput(input,value){const formatted=input.type==='date'?value.slice(0,10):input.type==='datetime-local'?value.replace(' ','T'):value;Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,formatted);input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));if(input.value!==formatted)throw new Error('The report did not accept a search field. No search was submitted.');}
  function setOption(select,label){if(!select)return;const options=Array.from(select.options).filter(o=>String(o.textContent||'').trim().toLowerCase()===label.toLowerCase());if(options.length!==1)throw new Error('Could not set the report '+label+' filter. No search was submitted.');select.value=options[0].value;select.dispatchEvent(new Event('change',{bubbles:true}));}
  function run(args){
    const found=locate();if(found.error)return {scheduled:false,error:found.error};
    if(!args||!/^[a-zA-Z0-9_.-]{1,255}$/.test(args.member)||!/^\d{4}-\d{2}-\d{2} 00:00:00$/.test(args.from)||!/^\d{4}-\d{2}-\d{2} 23:59:59$/.test(args.to))return {scheduled:false,error:'Invalid report search parameters.'};
    try{setInput(found.member,args.member);setInput(found.from,args.from);setInput(found.to,args.to);setOption(found.currency,'MYR');setOption(found.status,'All');}catch(e){return {scheduled:false,error:e.message};}
    const before=documentId();
    // Return before this report's own search button navigates the document.
    setTimeout(()=>{if(!allowed()||!found.button.isConnected)return;const current=locate();if(!current.error&&current.form===found.form&&current.button===found.button)found.button.click();},150);
    return {scheduled:true,documentId:before};
  }
  globalThis.SRWithdrawalSearch={inspect,run};
})();
