/* Compact, resumable archive search index. Raw Hub threads remain untouched. */
const HubIndex = (() => {
  const VERSION=1,META_ID='answerIndex',DEFAULT_BATCH=300;
  const normalize=value=>String(value||'').toLowerCase().replace(/\s+/g,' ').trim();
  const count=(db,store)=>new Promise((resolve,reject)=>{const req=db.transaction(store).objectStore(store).count();req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});

  function reverseTime(value){const parsed=Date.parse(value),time=Number.isFinite(parsed)?Math.max(0,Math.min(9999999999999,parsed)):0;return String(9999999999999-time).padStart(13,'0');}
  function documents(record){
    const out=[];let question='',sequence=0;
    for(const message of record?.messages||[]){
      if(message.role==='customer'){question=String(message.text||'').trim();continue;}
      if(message.role!=='agent'||!question)continue;
      const text=RetrievalCore.extractReusable(message.text),terms=RetrievalCore.terms(question+' '+text);
      if(!text||!terms.length)continue;
      const at=String(message.at||record.at||''),suffix=String(sequence++).padStart(4,'0');
      out.push({key:reverseTime(at)+'|'+record.key+'|'+suffix,threadKey:record.key,chatId:record.chatId,threadId:record.threadId,at,question:question.slice(0,1000),text,terms:[...new Set(terms.map(normalize).filter(Boolean))]});
    }
    return out;
  }

  function reset(db,total){return new Promise((resolve,reject)=>{const tx=db.transaction(['answerDocs','meta'],'readwrite'),state={id:META_ID,version:VERSION,processed:0,total,complete:total===0,lastKey:null,updatedAt:new Date().toISOString()};tx.objectStore('answerDocs').clear();tx.objectStore('meta').put(state);tx.oncomplete=()=>resolve(state);tx.onabort=()=>reject(tx.error||new Error('Could not initialize the fast archive index.'));});}
  function threadBatch(db,lastKey,limit){return new Promise((resolve,reject)=>{const rows=[],range=lastKey==null?undefined:IDBKeyRange.lowerBound(lastKey,true),req=db.transaction('threads').objectStore('threads').openCursor(range);req.onsuccess=()=>{const cursor=req.result;if(!cursor){resolve({rows,done:true});return;}rows.push(cursor.value);if(rows.length>=limit){resolve({rows,done:false});return;}cursor.continue();};req.onerror=()=>reject(req.error);});}
  function writeBatch(db,rows,state){
    const docs=rows.flatMap(documents);
    return new Promise((resolve,reject)=>{const tx=db.transaction(['answerDocs','meta'],'readwrite'),store=tx.objectStore('answerDocs');for(const doc of docs)store.put(doc);tx.objectStore('meta').put(state);tx.oncomplete=()=>resolve(docs.length);tx.onabort=()=>reject(tx.error||new Error('Could not save the fast archive index batch.'));});
  }
  async function status(db){
    const total=await count(db,'threads'),docs=await count(db,'answerDocs');let state=await HubStore.read(db,'meta',META_ID);
    if(!state||state.version!==VERSION)state={id:META_ID,version:VERSION,processed:0,total,complete:total===0,lastKey:null,updatedAt:''};
    return {...state,total,docs,processed:Math.min(total,Number(state.processed)||0),complete:!!state.complete&&Number(state.processed)>=total};
  }
  async function buildBatch(db,limit=DEFAULT_BATCH){
    const total=await count(db,'threads');let state=await HubStore.read(db,'meta',META_ID);
    if(!state||state.version!==VERSION)state=await reset(db,total);
    if(state.complete&&Number(state.processed)>=total)return {...await status(db),added:0};
    const page=await threadBatch(db,state.lastKey,Math.max(25,Math.min(1000,Number(limit)||DEFAULT_BATCH))),processed=Math.min(total,(Number(state.processed)||0)+page.rows.length);
    const next={...state,version:VERSION,processed,total,complete:page.done||processed>=total,lastKey:page.rows.length?page.rows.at(-1).key:state.lastKey,updatedAt:new Date().toISOString()};
    const added=await writeBatch(db,page.rows,next);
    return {...next,docs:await count(db,'answerDocs'),added};
  }
  async function indexRecords(db,records){
    const rows=Array.isArray(records)?records:[];if(!rows.length)return 0;let added=0;
    for(let offset=0;offset<rows.length;offset+=250){const docs=rows.slice(offset,offset+250).flatMap(documents);await new Promise((resolve,reject)=>{const tx=db.transaction('answerDocs','readwrite'),store=tx.objectStore('answerDocs');for(const doc of docs)store.put(doc);tx.oncomplete=resolve;tx.onabort=()=>reject(tx.error||new Error('Could not update the fast archive index.'));});added+=docs.length;}
    const state=await HubStore.read(db,'meta',META_ID);if(state?.complete){const total=await count(db,'threads');await HubStore.write(db,{meta:[{...state,total,processed:total,updatedAt:new Date().toISOString()}]});}
    return added;
  }
  async function search(db,query){
    const terms=RetrievalCore.terms(query).map(normalize).filter(Boolean).slice(0,12);if(!terms.length)return [];
    const batches=await new Promise((resolve,reject)=>{const tx=db.transaction('answerDocs'),index=tx.objectStore('answerDocs').index('terms'),requests=terms.map(term=>index.getAll(IDBKeyRange.only(term),100)),results=new Array(requests.length);let pending=requests.length;requests.forEach((request,i)=>{request.onsuccess=()=>{results[i]=request.result;if(!--pending)resolve(results);};request.onerror=()=>reject(request.error);});});
    const unique=new Map();for(const doc of batches.flat())if(!unique.has(doc.key))unique.set(doc.key,doc);
    const matches=[...unique.values()].map(doc=>({...doc,n:RetrievalCore.score(doc.question,query)*2+RetrievalCore.score(doc.text,query)})).filter(row=>row.n>0);
    return RetrievalCore.dedupe(matches);
  }
  return {VERSION,documents,status,buildBatch,indexRecords,search};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=HubIndex;
