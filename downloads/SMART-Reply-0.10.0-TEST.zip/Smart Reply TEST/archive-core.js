/* Local archive preparation and keyword analysis. No external AI calls. */
const ArchiveCore = (() => {
  const TOPICS = [
    {id:'promotion',name:'Promotions & bonuses',words:['promo','promotion','bonus','free spin','freespin','turnover','winover','优惠','红利','奖金','流水','免费旋转','promosi']},
    {id:'withdrawal',name:'Withdrawals',words:['withdraw','cash out','cashout','payout','pengeluaran','keluar duit','提款','提现','出款']},
    {id:'deposit',name:'Deposits & payments',words:['deposit','topup','top up','payment','transfer','bank in','bayaran','存款','充值','入款','转账']},
    {id:'access',name:'Login & account access',words:['login','log in','password','reset','otp','log masuk','kata laluan','登录','密码','验证码']},
    {id:'technical',name:'Game & technical issues',words:['error','disconnect','loading','cannot play','tak boleh main','stuck','lag','维护','无法进入','卡住','故障','maintenance']},
    {id:'verification',name:'Verification & identity',words:['verify','verification','identity','kyc','pengesahan','身份证','验证','实名']}
  ];
  const literal = s => s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  function mask(text, users=[]) {
    let value = String(text || '');
    for (const user of users) for (const field of ['name','email','id','loginUsername']) {
      const v=String(user[field]||'').trim();
      if (v.length>=(field==='loginUsername'?1:3)) value=value.replace(new RegExp('(?<![\\p{L}\\p{N}_])'+literal(v)+'(?![\\p{L}\\p{N}_])','giu'),'[PERSON]');
    }
    // Require a labelled, mixed letter/digit login. Plain words and uppercase promo codes stay.
    value=value.replace(/((?:\b(?:username|user|id|account|akaun|member)\b|用户名|账号|会员)\s*(?:(?:is|ialah|是)\s*|[:：=#]\s*)?)([A-Za-z0-9_][A-Za-z0-9_.-]{2,79})(?![A-Za-z0-9_.-])/gi,(all,prefix,word)=>{
      const promo=/^(?:100PPU|NEWFS288|88MYWLB)$/i.test(word)||/^(?:[A-Z0-9]*\d[A-Z0-9]*)$/.test(word)&&/[A-Z]/.test(word);
      return /[a-z]/i.test(word)&&/\d/.test(word)&&!promo?prefix+'[PERSON]':all;
    });
    return value.replace(/[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}/g,'[EMAIL]')
      .replace(/(?:\+?\d[\d ()-]{6,}\d)/g,'[NUMBER]')
      .replace(/\b(?:https?:\/\/|www\.)\S+/gi,'[LINK]')
      .replace(/((?:password|kata laluan|密码|otp|api[ _-]?key|token)\s*[:=]\s*)\S+/gi,'$1[SECRET]');
  }
  function topics(text) {
    const lower=String(text).toLowerCase();
    const found=TOPICS.filter(t=>t.words.some(w=>/[\u3400-\u9fff]/.test(w)?lower.includes(w):new RegExp('(?:^|[^a-z])'+literal(w)+'(?:$|[^a-z])','i').test(lower))).map(t=>t.id);
    return found.length?found:['other'];
  }
  function prepareChat(chat, customerKey) {
    const thread=chat && chat.thread;
    if (!chat || !thread || !chat.id || !thread.id || thread.active!==false) return null;
    const users=Array.isArray(chat.users)?chat.users:[], roles=new Map(users.map(u=>[u.id,u.type]));
    const maskingUsers=users.slice();
    for(const event of thread.events||[])if(event.type==='filled_form')for(const field of event.fields||[]){
      if(!/^login\s+username(?:\s*[:：]|$)/i.test(String(field.label||'').normalize('NFKC').replace(/<[^>]*>/g,' ').replace(/&nbsp;|&#160;/gi,' ').replace(/\s+/g,' ').trim()))continue;
      const answers=field.answer!=null?[field.answer]:Array.isArray(field.answers)?field.answers:[];
      for(const answer of answers){const value=typeof answer==='string'?answer:answer&&answer.label;if(typeof value==='string'&&value.trim())maskingUsers.push({loginUsername:value.trim()});}
    }
    const seen=new Set(),messages=[]; let omitted=0;
    for (const e of thread.events||[]) {
      if(e.type!=='message'||e.visibility!=='all'||typeof e.text!=='string'||!['customer','agent'].includes(roles.get(e.author_id))) {omitted++;continue;}
      const key=e.id||JSON.stringify([e.author_id,e.created_at,e.text]);if(seen.has(key))continue;seen.add(key);
      messages.push({id:String(e.id||JSON.stringify([e.author_id,e.created_at,mask(e.text,maskingUsers)])),role:roles.get(e.author_id),at:String(e.created_at||''),text:mask(e.text,maskingUsers)});
    }
    messages.sort((a,b)=>a.at.localeCompare(b.at));
    const customerText=messages.filter(m=>m.role==='customer').map(m=>m.text).join('\n');
    const question=messages.find(m=>m.role==='customer' && topics(m.text)[0]!=='other') || messages.find(m=>m.role==='customer');
    return {key:JSON.stringify([String(chat.id),String(thread.id)]),chatId:String(chat.id),threadId:String(thread.id),at:String(thread.created_at||''),customerKey:customerKey||'',messages,omitted,topics:topics(customerText),question:question?question.text:'No public customer text returned',restricted:!!thread.restricted_access};
  }
  function summarize(records) {
    const counts=new Map(),daily=new Map(),customers=new Map();let messages=0,omitted=0,unanswered=0,restricted=0;
    for(const r of records){
      for(const t of r.topics||['other'])counts.set(t,(counts.get(t)||0)+1);
      const date=Number.isNaN(Date.parse(r.at))?'Unknown':new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kuala_Lumpur',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(r.at));daily.set(date,(daily.get(date)||0)+1);
      if(r.customerKey)customers.set(r.customerKey,(customers.get(r.customerKey)||0)+1);
      messages+=r.messages.length;omitted+=r.omitted||0;if(r.restricted)restricted++;
      if(r.messages.some(m=>m.role==='customer')&&!r.messages.some(m=>m.role==='agent'))unanswered++;
    }
    return {threads:records.length,chats:new Set(records.map(r=>r.chatId)).size,messages,omitted,restricted,unanswered,returningCustomers:[...customers.values()].filter(v=>v>1).length,
      topics:[...counts].sort((a,b)=>b[1]-a[1]).map(([id,count])=>({id,name:(TOPICS.find(t=>t.id===id)||{name:'Other / unclassified'}).name,count})),daily:[...daily].sort((a,b)=>a[0].localeCompare(b[0]))};
  }
  function csv(rows) {
    return '\uFEFF'+rows.map(row=>row.map(v=>{let s=String(v==null?'':v);if(/^[\s]*[=+@-]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';}).join(',')).join('\r\n');
  }
  function knowledgeCSV(entries) {
    return csv([['TOPIC','KEYWORDS','ENGLISH','MALAY','CHINESE','NOTES'],...entries.map(e=>[e.topic,e.keywords,e.lang==='en'?e.answer:'',e.lang==='ms'?e.answer:'',e.lang==='zh'?e.answer:'','Manually reviewed '+e.reviewedAt+'; source chat '+e.chatId+', thread '+e.threadId])]);
  }
  function range(from,to,all=false) {
    const valid=s=>/^\d{4}-\d{2}-\d{2}$/.test(s)&&!Number.isNaN(Date.parse(s+'T00:00:00Z'))&&new Date(s+'T00:00:00Z').toISOString().slice(0,10)===s;
    if(!valid(to)||(!all&&!valid(from))||(!all&&from>to))throw new Error('Choose a valid date range.');
    return {...(!all?{from:from+'T00:00:00.000000+08:00'}:{}),to:to+'T23:59:59.999999+08:00'};
  }
  return {TOPICS,mask,topics,prepareChat,summarize,csv,knowledgeCSV,range};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=ArchiveCore;
