/* Receipt extraction and comparison: pure local rules, not proof from timestamps alone. */
(function(){
  const NEAR_SECONDS=300;
  const QUICK_MATCH_SECONDS=120;
  function money(s){s=String(s||'').trim();if(!/^(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d{1,2})?$/.test(s))return null;const n=Number(s.replace(/,/g,''));return n>0&&n<1e9?n:null;}
  function stamp(y,m,d,h,min,sec){
    [y,m,d,h,min,sec]=[y,m,d,h,min,sec].map(Number);const t=Date.UTC(y,m-1,d,h,min,sec),v=new Date(t);
    if(y<2000||y>2100||v.getUTCFullYear()!==y||v.getUTCMonth()!==m-1||v.getUTCDate()!==d||h>23||min>59||sec>59)return null;
    return t-8*3600000;
  }
  function backendTime(s){const m=String(s||'').match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})$/);return m?stamp(...m.slice(1)):null;}
  function formatTime(at){return Number.isFinite(at)?new Date(at+8*3600000).toISOString().slice(0,19).replace('T',' '):'Not read';}
  function extract(text){
    const lines=String(text||'').slice(0,30000).split(/\r?\n/).map(s=>s.replace(/\s+/g,' ').trim()).filter(Boolean),all=lines.join('\n'),amounts=[];
    for(let i=0;i<lines.length;i++){
      let line=lines[i].replace(/\b0\s+points\b/gi,'');if(/(?:charge|chg|fee|gst|balance|baki|points|%)/i.test(line))continue;
      if(/(?:tran\s*amt|amount|jumlah|amaun)/i.test(line)&&!/[\d]/.test(line))line+=' '+(lines[i+1]||'');
      let m=line.match(/(?:-?RM|MYR)\s*([\d,]+\.\d{2})(?!\d)/i)||line.match(/(?:tran\s*amt|amount|jumlah|amaun)\s*[:：]?\s*(?:RM)?\s*([\d,]+(?:\.\d{2})?)(?![\d.])/i);
      if(m){const raw=m[1],n=money(/^\d+,\d{2}$/.test(raw)?raw.replace(',','.'):raw);if(n!==null)amounts.push(n);}
    }
    const unique=[...new Set(amounts)];
    // Normalize explicit month names. Do not repair OCR digits or guess missing dates.
    const months={jan:1,january:1,januari:1,feb:2,february:2,februari:2,mar:3,march:3,mac:3,apr:4,april:4,may:5,mei:5,jun:6,june:6,jul:7,july:7,julai:7,aug:8,august:8,ogos:8,sep:9,sept:9,september:9,oct:10,october:10,okt:10,oktober:10,nov:11,november:11,dec:12,december:12,dis:12,disember:12};
    const monthNames=Object.keys(months).sort((a,b)=>b.length-a.length).join('|');
    const normalized=lines.map(l=>l.replace(new RegExp('\\b(\\d{1,2})[ -]+('+monthNames+')\\.?[ ,/-]+(20\\d{2})\\b','gi'),(_,d,m,y)=>y+'-'+String(months[m.toLowerCase()]).padStart(2,'0')+'-'+d.padStart(2,'0'))
      .replace(new RegExp('\\b('+monthNames+')\\.?[ -]+(\\d{1,2})[ ,/-]+(20\\d{2})\\b','gi'),(_,m,d,y)=>y+'-'+String(months[m.toLowerCase()]).padStart(2,'0')+'-'+d.padStart(2,'0')));
    const dateText=normalized.join('\n');
    // Preserve the existing Malaysia day/month/year convention for numeric dates.
    const dates=[...dateText.matchAll(/\b(\d{1,2})[/-](\d{1,2})[/-](20\d{2})\b/g)].map(m=>[m[3],m[2],m[1]]);
    for(const m of dateText.matchAll(/\b(20\d{2})-(\d{2})-(\d{2})\b/g))dates.push([m[1],m[2],m[3]]);
    const timeText=normalized.filter(l=>/\b(?:\d{1,2}[/-]\d{1,2}[/-]20\d{2}|20\d{2}-\d{2}-\d{2})\b/.test(l)&&/\d{1,2}:\d{2}/.test(l)).join('\n')||dateText;
    const times=[...timeText.matchAll(/\b(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?\b/gi)].map(m=>({h:m[4]?(Number(m[1])%12+(m[4].toUpperCase()==='PM'?12:0)):Number(m[1]),min:m[2],sec:m[3]||'00',precision:m[3]?'second':'minute',valid:!m[4]||(Number(m[1])>=1&&Number(m[1])<=12)}));
    const ds=[...new Map(dates.map(d=>[d.join('-'),d])).values()],tt=[...new Map(times.filter(t=>t.valid).map(t=>[[t.h,t.min,t.sec].join(':'),t])).values()];
    const at=ds.length===1&&tt.length===1?stamp(...ds[0],tt[0].h,tt[0].min,tt[0].sec):null;
    const refs=[];
    for(let i=0;i<lines.length;i++){
      const m=lines[i].match(/(?:duitnow\s*(?:ref(?:erence)?\s*(?:no\.?)?)|reference\s*(?:id|no\.?)?|transaction\s*(?:no\.?|id)|no\.?\s*transaksi|ruj\s*wallet|ewallet\s*ref\s*no\.?)\s*[:：]?\s*(.*)$/i);
      if(m){let value=m[1]||lines[i+1]||'';value=value.trim();if(/^[a-z0-9-]{6,100}$/i.test(value))refs.push(value.toUpperCase());}
    }
    const warnings=[];if(unique.length!==1)warnings.push('Amount unreadable or ambiguous.');if(at===null)warnings.push('Transaction date/time unreadable or ambiguous (a phone clock may also be visible).');if(!refs.length)warnings.push('No reliable bank/wallet reference read.');
    return {amount:unique.length===1?unique[0]:null,at,precision:tt.length===1?tt[0].precision:null,references:[...new Set(refs)],warnings};
  }
  function evaluate(receipt,report,member){
    if(!report||report.error)throw new Error(report?.error||'Deposit report unavailable.');
    if(report.kind!=='deposit'||report.member!==member||report.currency!=='MYR'||!Array.isArray(report.rows))throw new Error('Report identity or currency could not be verified.');
    if(!Number.isFinite(receipt.amount)||!Number.isFinite(receipt.at))return {state:'unresolved',label:'Scan incomplete — do not confirm payment',rows:[]};
    const same=report.rows.filter(r=>r.member===member&&r.currency==='MYR'&&Number.isFinite(r.amount)&&Math.round(r.amount*100)===Math.round(receipt.amount*100));
    const refs=receipt.references||[];
    const exact=same.filter(r=>typeof r.transferReference==='string'&&/^[a-z0-9-]{6,100}$/i.test(r.transferReference)&&refs.includes(r.transferReference.toUpperCase()));
    const later=r=>{const t=backendTime(r.confirmedAt);return t!==null&&t>=receipt.at;};
    // Loaded-page uniqueness is not global uniqueness when pagination is present.
    if(exact.length===1&&!report.pagination&&/^finish$/i.test(exact[0].status)&&later(exact[0]))return {state:'matched',label:'Matching successful record — review OCR/reference before Send',rows:exact};
    if(exact.length)return {state:'review',label:'Reference candidate needs review: status, chronology, duplicates or pagination',rows:exact.slice(0,10)};
    const near=same.filter(r=>{const t=backendTime(r.confirmedAt);return t!==null&&t>=receipt.at&&t-receipt.at<=NEAR_SECONDS*1000;});
    const quick=near.filter(r=>backendTime(r.confirmedAt)-receipt.at<=QUICK_MATCH_SECONDS*1000);
    if(near.length===1&&quick.length===1&&!report.pagination&&/^finish$/i.test(quick[0].status))return {state:'matched',label:'Likely credited — successful record within 2 minutes; reference not verified',rows:quick};
    return {state:near.length?'likely':'unresolved',label:near.length?'Possible time/amount match — NOT confirmed':'No matching successful deposit found yet in the loaded report',rows:near.slice(0,10)};
  }
  const api={NEAR_SECONDS,QUICK_MATCH_SECONDS,money,backendTime,formatTime,extract,evaluate};if(typeof module!=='undefined'&&module.exports)module.exports=api;else globalThis.SRReceiptCore=api;
})();
