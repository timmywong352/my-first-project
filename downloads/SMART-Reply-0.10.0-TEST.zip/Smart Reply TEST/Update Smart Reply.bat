@echo off
title Update Smart Reply
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0update-smart-reply.ps1"
echo.
pause
