/* One-shot read of the report DOM. Never clicks, fills, submits, or fetches. */
(function () {
  if(location.origin!=='https://mcd88.kg8.co'||location.pathname!=='/website/withdraw/withdraw_report.php')return {notReport:true};
  if(document.querySelector('input[type="password"]'))return {error:'Log in yourself, then open the withdrawal report.'};
  if(!globalThis.SRWithdrawalRules)return {error:'Reader rules were not loaded.'};
  const candidates=[];
  for(const table of document.querySelectorAll('table')) {
    if(!table.getClientRects().length||getComputedStyle(table).visibility==='hidden')continue;
    const rows=Array.from(table.rows).filter(row=>row.closest('table')===table&&row.getClientRects().length);
    let header=-1,columns=null,labels=[];
    for(let i=0;i<Math.min(rows.length,30);i++){labels=Array.from(rows[i].cells).map(cell=>cell.innerText);columns=globalThis.SRWithdrawalRules.headerColumns(labels);if(columns){header=i;break;}}
    if(header<0)continue;
    const allowed=new Set(Object.values(columns).filter(index=>index>=0));
    const matrix=[labels,...rows.slice(header+1).map(row=>Array.from(row.cells).map((cell,index)=>allowed.has(index)?cell.innerText:''))];
    candidates.push(...globalThis.SRWithdrawalRules.extract(matrix));
  }
  const rows=[...new Map(candidates.map(row=>[row.id,row])).values()];
  const dates=Array.from(document.querySelectorAll('input:not([type="password"]):not([type="hidden"])')).map(input=>input.value).filter(value=>/^\d{4}-\d{2}-\d{2}(?:\s+\d{2}:\d{2}:\d{2})?$/.test(value));
  const pagingTexts=[];
  for(const control of document.querySelectorAll('a,button,input[type="button"],input[type="submit"],nav,[role="navigation"],select')) {
    if(control.getClientRects().length&&getComputedStyle(control).visibility!=='hidden')pagingTexts.push(control.getAttribute('aria-label')||control.textContent||control.value||'');
  }
  // Read only standalone page-count text nodes outside report tables, never table data cells.
  if(document.body&&document.createTreeWalker){const walker=document.createTreeWalker(document.body,4);let node;while((node=walker.nextNode())){const parent=node.parentElement;if(parent&&!parent.closest('table,script,style')&&parent.getClientRects().length&&getComputedStyle(parent).visibility!=='hidden'&&/(?:page\s*\d+\s*(?:of|\/)\s*\d+|第\s*\d+\s*页)/i.test(node.nodeValue||''))pagingTexts.push(node.nodeValue);}}
  const pagination=globalThis.SRWithdrawalRules.hasPagination(pagingTexts);
  const documentId=globalThis.__SRWithdrawalDocumentId||(globalThis.__SRWithdrawalDocumentId=Date.now().toString(36)+'-'+Math.random().toString(36).slice(2));
  return {notReport:false,documentId,readAt:new Date().toISOString(),dateRange:dates.slice(0,2),pagination,rows};
})();
