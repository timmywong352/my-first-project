(async()=>{
  let worker;
  try{
    const result=await chrome.runtime.sendMessage({action:'receiptOCRClaim'});if(!result?.ok)throw new Error('No pending receipt.');
    const base=chrome.runtime.getURL('lib/tesseract/');
    worker=await Tesseract.createWorker('eng',1,{workerPath:base+'worker.min.js',corePath:base+'tesseract-core-simd-lstm.wasm.js',langPath:base+'lang',workerBlobURL:false,cacheMethod:'none',gzip:true});
    // Sparse layout preserves isolated large currency headings on mobile receipts.
    await worker.setParameters({tessedit_pageseg_mode:'11'});
    const {data}=await worker.recognize(result.data.image);result.data.image='';
    await worker.terminate();worker=null;
    await chrome.runtime.sendMessage({action:'receiptOCRResult',text:String(data.text||'').slice(0,30000),confidence:Number(data.confidence)});
  }catch(e){if(worker)await worker.terminate().catch(()=>{});await chrome.runtime.sendMessage({action:'receiptOCRResult',failed:true}).catch(()=>{});document.body.textContent='Local scan could not complete. Close this tab and retry from LiveChat.';}
})();
