/* Compact operator summary. Full turnover evidence remains local under Details. */
(function(){
  function renderQuick(box,username,reports,core,doc=document){
    box.textContent='';
    const add=(parent,tag,text,cls)=>{const e=doc.createElement(tag);if(text)e.textContent=text;if(cls)e.className=cls;parent.append(e);return e;};
    const summary=core.quickSummary(username,reports),header=add(box,'div','','account-heading');
    add(header,'strong','Username: '+username);add(header,'span','5-report summary','account-tag');
    const missing=['balance','deposit','promotion','turnover','withdrawal'].filter(kind=>!reports[kind]||reports[kind].error).length;
    if(missing)add(box,'div',missing+' report(s) unavailable. Missing information is shown as Not verified.','account-alert');
    if(Object.values(reports).some(report=>report?.pagination))add(box,'div','Loaded pages only. The latest record across every page is not verified.','account-alert');
    const card=(label,item,state='')=>{const row=add(box,'div','','account-card'+(state?' account-'+state:''));add(row,'div',label,'account-label');add(row,'strong',item.value,'account-value');add(row,'div',item.note,'account-sub');};
    card('Current balance',summary.balance);
    const turnover=summary.turnover;
    if(turnover.verified)card('Latest deposit · turnover duration',{value:turnover.deposit===null?'Amount not shown':core.money(turnover.deposit),note:'Deposit time '+turnover.depositAt+' · Period ends '+turnover.periodEnd+(turnover.totalBet===null?'':' · Recorded turnover '+core.turnoverNumber(turnover.totalBet))});
    else card('Latest deposit in selected period',summary.deposit);
    const depositCheck=summary.depositCheck;
    card('Deposit cross-check',{value:depositCheck.badge,note:depositCheck.note},depositCheck.state==='matched'?'match':depositCheck.state==='mismatch'?'danger':'warning');
    card('Played providers since latest deposit',turnover.verified&&turnover.providers.length?{value:turnover.providers.map(row=>row.provider+' · '+core.turnoverNumber(row.bet)).join(' | '),note:'Only providers above 0.000 in Checking Turnover are listed.'}:{value:'None shown',note:turnover.verified?'No provider above 0.000 was shown in the loaded turnover table.':turnover.interpretation});
    card('Latest promotion report entry',summary.promotion);
    const promotionState=turnover.promotionState||{badge:'NOT VERIFIED',explanation:turnover.interpretation,recentPromotion:null};
    card('Promotion turnover status',{value:promotionState.badge,note:(promotionState.recentPromotion?promotionState.recentPromotion.code+' · Confirmed '+promotionState.recentPromotion.confirmedAt+' · ':'')+promotionState.explanation},'warning');
    card('Latest withdrawal status in selected period',summary.withdrawal);
    if(summary.withdrawal.verified)add(box,'div','Withdrawal remark: '+(summary.withdrawal.remark||'No remark shown. No reason inferred.'),'account-remark');
    add(box,'div','Operator only. This summary does not approve a withdrawal, infer a missing reason, or send a customer message.','account-footer');
    const details=add(box,'details','','account-details');add(details,'summary','Coverage & source times');
    const lines=['Username: '+username,'Latest means the unique latest exact-member row in the selected loaded period.'];
    for(const kind of ['balance','deposit','promotion','turnover','withdrawal']){
      const source=summary.source[kind];
      lines.push(kind.charAt(0).toUpperCase()+kind.slice(1)+': '+(source?'Read '+(source.readAt||'time unavailable')+(source.dateRange.length?' · Range '+source.dateRange.join(' — '):'')+(source.pagination?' · Pagination detected':''):'Not available'));
    }
    if(summary.warnings.length)lines.push('Warnings:\n'+summary.warnings.join('\n'));
    lines.push('Backend timestamps are shown verbatim; backend timezone is not verified.');
    add(details,'div',lines.join('\n'),'account-detail-text');
  }
  function render(box,username,reports,promos,ruleError,core,doc=document,options={}){
    box.textContent='';
    const add=(parent,tag,text,cls)=>{const e=doc.createElement(tag);if(text)e.textContent=text;if(cls)e.className=cls;parent.append(e);return e;};
    const detail=core.summarize(username,reports,promos,ruleError,options);
    const header=add(box,'div','','account-heading');add(header,'strong','Username: '+username);add(header,'span','Operator view','account-tag');
    const missing=['balance','deposit','promotion','turnover','withdrawal'].filter(k=>!reports[k]||reports[k].error).length;
    if(missing)add(box,'div',missing+' report(s) unavailable. Some details are not verified.','account-alert');
    if(Object.values(reports).some(r=>r?.pagination))add(box,'div','Loaded pages only. Latest records are not verified across all pages.','account-alert');
    if(Object.values(reports).some(r=>r?.manual))add(box,'div','Manual report search confirmed by the operator.','account-alert');
    const card=(label,value,sub)=>{const row=add(box,'div','','account-card');add(row,'div',label,'account-label');add(row,'strong',value,'account-value');if(sub)add(row,'div',sub,'account-sub');};
    const report=k=>reports[k]&&!reports[k].error?reports[k]:null;
    const reset=core.depositReset(username,reports,!!options.resetConfirmed);
    let r=report('balance'),matches=r?.rows.filter(x=>x.member===username&&x.currency==='MYR')||[];
    card('Current balance',matches.length===1?core.money(matches[0].amount):'Not verified',matches.length===1?'Current member-list snapshot. Wallet coverage/history is not verified.':'A unique matching MYR balance was not found.');
    const turnover=report('turnover'),matched=turnover?.member===username;
    r=report('deposit');let rows=r?.rows.filter(x=>x.member===username&&x.currency==='MYR'&&/^finish$/i.test(x.status))||[],last=core.latest(rows,'confirmedAt')||core.latest(rows);
    const fallback=!last&&matched&&Number.isFinite(turnover.deposit)&&turnover.duration?.length===2;
    card(fallback?'Last deposit · turnover reference':'Last deposit'+(r?.pagination?' · candidate':''),last?core.money(last.amount):fallback?core.money(turnover.deposit):'Not verified',last?(last.confirmedAt?'Confirmed '+last.confirmedAt:'Requested '+last.requestedAt)+' · Backend status: '+last.status:fallback?turnover.duration[0]+' · Latest successful deposit is not independently verified.':'No unique latest successful deposit in the loaded range.');
    const depositCheck=core.depositReconciliation(username,reports);
    card('Deposit cross-check',depositCheck.badge,depositCheck.note);
    r=report('promotion');rows=r?.rows.filter(x=>x.member===username&&/^confirmed$/i.test(x.status))||[];last=core.latest(rows,'confirmedAt')||core.latest(rows);
    const historical=matched?core.latest(turnover.promotionRows.filter(x=>x.member===username),'confirmedAt')||core.latest(turnover.promotionRows.filter(x=>x.member===username)):null,claim=last||historical;
    if(reset.applied)card('Promotion','No new promotion for this deposit',claim?'Previous '+claim.code+' · '+(claim.confirmedAt||claim.requestedAt)+' is historical under the operator-confirmed reset.':'Previous promotion ended under the operator-confirmed reset.');
    else card(!last&&historical?'Promotion · turnover record':'Promotion',claim?claim.code+(core.promotionName(claim.code)!==claim.code?' · '+core.promotionName(claim.code):''):'Not verified',claim?(claim.confirmedAt?'Confirmed '+claim.confirmedAt:'Claimed '+claim.requestedAt)+(!last?' · Latest loaded turnover record; full claim history is not verified.':''):'No unique confirmed promotion in the loaded range.');
    r=report('withdrawal');rows=r?.rows.filter(x=>x.member===username&&x.currency==='MYR')||[];last=core.latest(rows);
    card('WD status'+(r?.pagination?' · candidate':''),last?last.status:'Not verified',last?'Ref '+last.id+' · '+core.money(last.amount)+' · '+last.requestedAt:'No unique latest withdrawal in the loaded range.');
    if(last)add(box,'div','Remark: '+(last.remarks||'No remark shown. No reason inferred.'),'account-remark');
    let summary=reset.applied?{value:reset.value,note:reset.reason}:core.turnoverSummary(turnover,username);
    const calculation=detail.match(/^Deposit turnover \(owner rule, no promotion shown\):[^\n]*→ (Finished|Unfinished)\./m);
    if(summary.value==='Not verified'&&turnover&&!turnover.baseStatus&&calculation)summary.value=calculation[1];
    add(box,'div','Turnover: '+summary.value+(reset.applied?' · Previous-promotion reset confirmed by operator.':''),'account-alert');
    const unfinishedRebates=turnover?.rebateRows.filter(x=>x.member===username&&/^unfinished$/i.test(x.status)).length||0;
    if(reset.applied&&unfinishedRebates)add(box,'div','Rebate turnover: '+unfinishedRebates+' unfinished record(s). The deposit reset does not clear these.','account-alert');
    if(options.resetConfirmed&&!reset.applied)add(box,'div','New-deposit reset not applied: '+reset.reason,'account-alert');
    if(ruleError)add(box,'div','Live promotion rules unavailable. Game validation is not verified.','account-alert');
    if(detail.includes('Potential mismatch:'))add(box,'div','Potential wrong-game activity. Review details before deciding the cause.','account-alert');
    if(detail.includes('snapshots differ')||detail.includes('contains a claim in this turnover duration'))add(box,'div','Report snapshots conflict. Review details.','account-alert');
    add(box,'div','Operator only. Withdrawal approval/payment is not inferred.','account-footer');
    const details=add(box,'details','','account-details');add(details,'summary','Details & sources');add(details,'div',detail,'account-detail-text');
  }
  if(typeof module!=='undefined'&&module.exports)module.exports={render,renderQuick};else globalThis.SRAccountView={render,renderQuick};
})();
