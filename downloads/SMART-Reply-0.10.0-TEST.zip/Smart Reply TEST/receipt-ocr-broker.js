/* Temporary local OCR tab; no offscreen permission, remote OCR, storage or URL fetch. */
(function(){
  let job=null;
  const page=chrome.runtime.getURL('receipt-ocr.html');
  function finish(error,data){const old=job;if(!old)return;job=null;clearTimeout(old.timer);old.image='';old.reply(error?{ok:false,error}:{ok:true,data});if(Number.isInteger(old.tabId))chrome.tabs.remove(old.tabId).catch(()=>{});}
  chrome.runtime.onMessage.addListener((req,sender,reply)=>{
    if(!['receiptOCR','receiptOCRClaim','receiptOCRResult','receiptOCRCancel'].includes(req?.action))return false;
    if(sender?.id!==chrome.runtime.id)return false;
    if(req.action==='receiptOCR'){
      let origin='';try{origin=new URL(sender.url).origin;}catch(e){}
      if(origin!=='https://my.livechatinc.com'||!Number.isInteger(sender.tab?.id)){reply({ok:false,error:'Start scanning from the main LiveChat tab.'});return false;}
      if(job){reply({ok:false,error:'Another receipt scan is running. Wait or clear it first.'});return false;}
      if(typeof req.image!=='string'||req.image.length>12*1024*1024||!/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(req.image)||!/^[-a-z0-9]{20,80}$/i.test(req.requestId||'')){reply({ok:false,error:'Invalid or oversized receipt image.'});return false;}
      const token=crypto.randomUUID(),record={token,requestId:req.requestId,owner:sender.tab.id,image:req.image,tabId:null,reply};job=record;
      record.timer=setTimeout(()=>{if(job===record)finish('Local OCR timed out. Try a clearer receipt.');},55000);
      chrome.tabs.create({url:page+'#'+token,active:false}).then(tab=>{if(job===record)record.tabId=tab.id;else chrome.tabs.remove(tab.id).catch(()=>{});}).catch(()=>{if(job===record)finish('Could not open the local OCR page.');});
      return true;
    }
    if(req.action==='receiptOCRCancel'){
      if(job&&sender.tab?.id===job.owner&&req.requestId===job.requestId)finish('Receipt scan cancelled.');reply({ok:true,data:true});return false;
    }
    if(!job||sender.url!==page+'#'+job.token||!Number.isInteger(sender.tab?.id)||(job.tabId!==null&&job.tabId!==sender.tab.id)){reply({ok:false,error:'Invalid OCR worker context.'});return false;}
    job.tabId=sender.tab.id;
    if(req.action==='receiptOCRClaim'){if(!job.image){reply({ok:false,error:'Receipt already claimed.'});return false;}const image=job.image;job.image='';reply({ok:true,data:{image}});return false;}
    if(req.action==='receiptOCRResult'){
      reply({ok:true,data:true});
      if(typeof req.text==='string'&&req.text.length<=30000&&Number.isFinite(req.confidence))finish(null,{text:req.text,confidence:req.confidence});else finish('Local OCR failed. Try a clearer image.');return false;
    }
    return false;
  });
  chrome.tabs.onRemoved.addListener(id=>{if(job&&(id===job.tabId||id===job.owner))finish('Receipt scan tab was closed.');});
})();
