/* Decision labels and anonymous quality metrics for the guarded Copilot. */
(function(){
  const LEVELS={
    safe:{level:'safe',label:'SAFE DRAFT',title:'Approved direct answer'},
    review:{level:'review',label:'REVIEW',title:'Review before using'},
    operator:{level:'operator',label:'OPERATOR',title:'Operator check required'}
  };
  const clean=value=>String(value||'').normalize('NFKC').replace(/\s+/g,' ').trim();
  function hash(value){
    let number=2166136261;
    for(const char of clean(value)){number^=char.charCodeAt(0);number=Math.imul(number,16777619);}
    return (number>>>0).toString(36).toUpperCase().padStart(7,'0').slice(-7);
  }
  function caseId(chatId,messageKey=''){return 'SR-'+hash((clean(chatId)||'chat')+'|'+(clean(messageKey)||'enquiry'));}
  function classify(input={}){
    const reason=clean(input.reason),sourceTypes=(Array.isArray(input.sourceTypes)?input.sourceTypes:[]).map(clean).filter(Boolean);
    if(input.route==='operator'||input.manual||input.conflict||input.missing){
      return {...LEVELS.operator,reason:reason||'The answer depends on missing, conflicting, or customer-specific facts.'};
    }
    const direct=new Set(['local-template','current-promotion','verified-backend','approved-rule']);
    if(input.route==='direct'&&sourceTypes.length&&sourceTypes.every(source=>direct.has(source))){
      return {...LEVELS.safe,reason:reason||'The reply comes directly from an approved local rule or current verified source.'};
    }
    if(input.historyUsed||sourceTypes.includes('historical')){
      return {...LEVELS.review,reason:reason||'A historical conversation helped produce this draft. Confirm that the policy is still current.'};
    }
    return {...LEVELS.review,reason:reason||'Approved knowledge supported this draft, but its final wording still needs a human check.'};
  }
  function feedbackStats(rows){
    const list=Array.isArray(rows)?rows:[],stats={total:0,good:0,edited:0,wrong:0,safe:0,review:0,operator:0,acceptance:0};
    for(const row of list){
      if(!row||!['good','edited','wrong'].includes(row.outcome)||!LEVELS[row.decision])continue;
      stats.total++;stats[row.outcome]++;stats[row.decision]++;
    }
    stats.acceptance=stats.total?Math.round(stats.good/stats.total*100):0;
    return stats;
  }
  const api={LEVELS,clean,caseId,classify,feedbackStats};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else globalThis.SRCopilotDecision=api;
})();
