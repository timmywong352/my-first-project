/* Conservative Copilot matching helpers. The extension only inserts editable drafts. */
(function(){
  const clean=value=>String(value||'').normalize('NFKC').replace(/\s+/g,' ').trim();
  const language=value=>/^zh(?:[-_]|$)/i.test(String(value||''))?'zh':/^ms(?:[-_]|$)/i.test(String(value||''))?'ms':'en';
  function messageKey(message){
    if(!message||!clean(message.text))return '';
    const id=clean(message.id),createdAt=clean(message.createdAt||message.created_at);
    if(id)return 'id:'+id;
    if(createdAt)return 'time:'+createdAt+'|'+clean(message.text);
    return '';
  }
  function sensitive(query){
    const text=clean(query).toLowerCase();
    if(!text)return 'No customer message was found.';
    if(/\b(?:otp|password|passcode|pin|verification\s*code)\b|密码|验证码|动态码/.test(text))return 'Credentials or verification codes require manual handling.';
    const subject='(?:withdraw(?:al)?|cash\\s*out|payout|wd|pengeluaran|deposit|depo|top\\s*up|payment|balance|baki|transaction|account|akaun|rebate|rebat|cashback|turnover|winover|promo[a-z0-9_-]*|promotion|promosi|bonus|claim)';
    const result='(?:status|progress|pending|failed?|failure|rejected?|missing|not\\s+(?:received|credited)|closed|resubmit|limit\\s+reached|remaining|how\\s+much|berapa|gagal|belum\\s+(?:terima|masuk)|check|semak)';
    if(new RegExp('\\b'+subject+'\\b.{0,35}\\b'+result+'\\b|\\b'+result+'\\b.{0,35}\\b'+subject+'\\b','i').test(text))return 'This asks for a customer-specific account or transaction result. Check the backend or ask an operator.';
    if(/\b(?:my|mine|saya|akaun\s+saya)\b.{0,35}\b(?:withdraw(?:al)?|deposit|payment|balance|transaction|rebate|turnover|bonus|account)\b|\b(?:check|semak)\b.{0,20}\b(?:my|saya)\b/i.test(text))return 'This asks for a customer-specific account or transaction result. Check the backend or ask an operator.';
    if(/(?:我的|本人|帮我|替我|给我|查询|查一下|查下).{0,20}(?:提款|提现|出款|存款|充值|余额|账户|交易|到账|返水|回扣|流水|优惠|活动|红利|领取)|(?:提款|提现|出款|存款|充值|余额|账户|交易|到账|返水|回扣|流水|优惠|活动|红利|领取).{0,20}(?:状态|进度|失败|没收到|未到账|拒绝|关闭|重提|剩余|还需|多少)/.test(text))return 'This asks for a customer-specific account or transaction result. Check the backend or ask an operator.';
    return '';
  }
  function unsafeAnswer(answer){
    const text=clean(answer);
    if(!text)return 'The approved answer is empty.';
    if(text.length>1200)return 'The approved answer is too long for automatic drafting.';
    if(/^NEED_INFO\b/i.test(text))return 'More information is required.';
    if(/\{\{[^}]+\}\}|\[[A-Z][A-Z0-9_ -]{2,}\]|<[^>]{1,80}>|_{3,}/.test(text))return 'The approved answer still contains a placeholder.';
    if(/\b(?:your|this)\s+(?:account|balance|deposit|withdrawal|transaction|rebate|bonus)\b|(?:has|have)\s+been\s+(?:approved|completed|processed|credited|paid)|您的?(?:账户|余额|存款|提款|交易|返水|红利)|已(?:经)?(?:到账|批准|完成|处理|付款)|(?:akaun|baki|deposit|pengeluaran|transaksi|rebat)\s+anda/i.test(text))return 'The answer appears to claim a customer-specific account result.';
    return '';
  }
  const ascii=value=>/^[\x00-\x7f]+$/.test(value);
  function hit(text,keyword){
    const hay=clean(text).toLowerCase(),word=clean(keyword).toLowerCase();
    if(!word)return false;
    if(!ascii(word))return hay.includes(word);
    const escaped=word.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    return new RegExp('(^|[^a-z0-9])'+escaped+'($|[^a-z0-9])').test(hay);
  }
  function sheetCandidate(entries,query,lang){
    const code=language(lang),ranked=[];
    for(const entry of Array.isArray(entries)?entries:[]){
      if(!entry||entry.always||!entry.topic)continue;
      const keywords=(Array.isArray(entry.keywords)?entry.keywords:[]).filter(keyword=>hit(query,keyword));
      if(!keywords.length)continue;
      const answer=clean(entry[code]);
      ranked.push({entry,score:keywords.length,strong:keywords.some(keyword=>clean(keyword).length>=4),answer});
    }
    ranked.sort((a,b)=>b.score-a.score||Number(b.strong)-Number(a.strong));
    const top=ranked[0],next=ranked[1];
    if(!top)return {ok:false,reason:'No exact approved knowledge row matched.'};
    if(!top.strong)return {ok:false,reason:'The knowledge match is too broad for automatic drafting.'};
    if(next&&next.score===top.score&&next.strong===top.strong)return {ok:false,reason:'Several approved knowledge rows match equally.'};
    const blocked=unsafeAnswer(top.answer);if(blocked)return {ok:false,reason:blocked};
    return {ok:true,text:top.answer,source:'current-sheet',topic:top.entry.topic};
  }
  function approvedCandidate(rows,lang){
    const list=Array.isArray(rows)?rows:[],code=language(lang);
    if(list.length!==1)return {ok:false,reason:list.length?'Several reviewed answers matched.':'No reviewed Hub answer matched.'};
    const answer=clean(list[0]?.[code]),blocked=unsafeAnswer(answer);
    if(blocked)return {ok:false,reason:blocked};
    return {ok:true,text:answer,source:'approved',topic:list[0].topic||'Reviewed Hub answer'};
  }
  function localCandidate(text,topic='Local clarification'){
    const answer=clean(text),blocked=unsafeAnswer(answer);
    return blocked?{ok:false,reason:blocked}:{ok:true,text:answer,source:'local-clarification',topic};
  }
  const api={clean,language,messageKey,sensitive,unsafeAnswer,hit,sheetCandidate,approvedCandidate,localCandidate};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else globalThis.SRCopilotCore=api;
})();
