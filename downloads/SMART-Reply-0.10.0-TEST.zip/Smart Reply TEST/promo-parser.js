// Promo sheet reader (used by background.js).
// Reads the .xlsx that Google Sheets exports (a zip of XML files) and turns every
// tab into a list: tab, promo code or name, English, Malay, Chinese.
//
// The rule, same as your team's promo sheet:
//   On every tab, find the header row that holds ENG | MALAY | CHINESE.
//   Every row under it with something in the first (code) column is a promo.
//   Hidden tabs are skipped.

const PromoParser = (() => {
  async function inflateRaw(bytes) {
    const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  async function unzip(arrayBuffer, wanted) {
    const view = new DataView(arrayBuffer), bytes = new Uint8Array(arrayBuffer);
    let eocd = -1;
    for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 22 - 65536); i--) {
      if (view.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('Google did not send the sheet. Is it shared as Anyone with the link?');
    const count = view.getUint16(eocd + 10, true);
    let p = view.getUint32(eocd + 16, true);
    const dec = new TextDecoder('utf-8'), files = {};
    for (let i = 0; i < count; i++) {
      if (view.getUint32(p, true) !== 0x02014b50) break;
      const method = view.getUint16(p + 10, true), compSize = view.getUint32(p + 20, true);
      const nameLen = view.getUint16(p + 28, true), extraLen = view.getUint16(p + 30, true), commentLen = view.getUint16(p + 32, true);
      const localOff = view.getUint32(p + 42, true);
      const name = dec.decode(bytes.subarray(p + 46, p + 46 + nameLen));
      p += 46 + nameLen + extraLen + commentLen;
      if (!wanted(name) || view.getUint32(localOff, true) !== 0x04034b50) continue;
      const start = localOff + 30 + view.getUint16(localOff + 26, true) + view.getUint16(localOff + 28, true);
      const data = bytes.subarray(start, start + compSize);
      files[name] = dec.decode(method === 0 ? data : method === 8 ? await inflateRaw(data) : new Uint8Array());
    }
    return files;
  }

  const unxml = s => String(s)
    .replace(/&#x([0-9a-fA-F]+);/g, (m, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (m, d) => String.fromCodePoint(parseInt(d, 10)))
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
  const textOf = xml => { let s = '', t; const re = /<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g; while ((t = re.exec(xml))) s += unxml(t[1]); return s; };

  function sharedStrings(xml) {
    const out = [], re = /<si>([\s\S]*?)<\/si>|<si\/>/g; let m;
    while ((m = re.exec(xml || ''))) out.push(m[1] ? textOf(m[1].replace(/<rPh[\s\S]*?<\/rPh>/g, '')) : '');
    return out;
  }

  // Numbers and dates are stored as plain numbers; show them the way the sheet shows them.
  const BUILTIN_FMT = { 9: '0%', 10: '0.00%' };
  function cellFormats(xml) {
    const custom = {}; let m;
    const nf = /<numFmt\b[^>]*>/g;
    while ((m = nf.exec(xml || ''))) {
      const id = (m[0].match(/\bnumFmtId="(\d+)"/) || [])[1], code = (m[0].match(/\bformatCode="([^"]*)"/) || [])[1];
      if (id) custom[id] = unxml(code || '');
    }
    const block = ((xml || '').match(/<cellXfs[^>]*>([\s\S]*?)<\/cellXfs>/) || [])[1] || '';
    const out = [], xf = /<xf\b[^>]*>/g;
    while ((m = xf.exec(block))) {
      const id = (m[0].match(/\bnumFmtId="(\d+)"/) || [])[1];
      out.push(custom[id] || BUILTIN_FMT[id] || '');
    }
    return out;
  }
  function showNumber(raw, fmt) {
    const n = Number(raw);
    if (raw === '' || !isFinite(n)) return unxml(raw);
    const f = String(fmt || '').replace(/"[^"]*"|\[[^\]]*\]|\\./g, '');
    if (f.includes('%')) {
      const dec = ((f.match(/\.(0+)/) || [])[1] || '').length;
      return (n * 100).toFixed(dec) + '%';
    }
    return String(n);
  }

  const colIndex = letters => { let n = 0; for (let i = 0; i < letters.length; i++) n = n * 26 + (letters.charCodeAt(i) - 64); return n - 1; };

  function sheetRows(xml, strings, formats) {
    const rows = [], rowRe = /<row[^>]*>([\s\S]*?)<\/row>/g; let rm;
    while ((rm = rowRe.exec(xml))) {
      const cells = [], cellRe = /<c\s+([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g; let cm;
      while ((cm = cellRe.exec(rm[1]))) {
        if (!cm[2]) continue;
        const ref = cm[1].match(/\br="([A-Z]+)\d+"/); if (!ref) continue;
        const col = colIndex(ref[1]); if (col > 11) continue;
        const type = (cm[1].match(/\bt="([^"]+)"/) || [])[1] || 'n';
        const v = cm[2].match(/<v[^>]*>([\s\S]*?)<\/v>/);
        let val = '';
        if (v) {
          if (type === 's') val = strings[parseInt(v[1], 10)] || '';
          else if (type === 'n') val = showNumber(v[1], formats[parseInt((cm[1].match(/\bs="(\d+)"/) || [])[1], 10)]);
          else val = unxml(v[1]);
        } else if (/<is>/.test(cm[2])) val = textOf(cm[2]);
        cells[col] = val;
      }
      rows.push(cells);
    }
    return rows;
  }

  const isEng = s => /^(ENG|ENGLISH)$/i.test(s), isMs = s => /^(MALAY|MELAYU|BM)$/i.test(s), isZh = s => /^(CHINESE|中文)$/i.test(s);
  const isCodeHead = s => /^(PROMO\s*CODE|PROMOTION|PROMO)$/i.test(s);

  function promosOf(tab, rows) {
    const out = []; let cols = null;
    for (const raw of rows) {
      const cell = i => (i >= 0 && raw[i] != null) ? String(raw[i]) : '';
      const trimmed = []; for (let i = 0; i < 12; i++) trimmed[i] = cell(i).trim();
      const en = trimmed.findIndex(isEng), ms = trimmed.findIndex(isMs), zh = trimmed.findIndex(isZh);
      if (en >= 0 && ms >= 0 && zh >= 0) {                      // a header row
        const named = trimmed.findIndex(isCodeHead);
        cols = { code: named >= 0 ? named : en - 1, en, ms, zh };
        continue;
      }
      if (!cols || cols.code < 0) continue;
      const code = trimmed[cols.code].replace(/\s+/g, ' ').trim();
      if (!code) continue;                                      // no code: not a promo row
      if (isCodeHead(code) && isEng(trimmed[cols.en])) continue;
      const t = { en: cell(cols.en).trim(), ms: cell(cols.ms).trim(), zh: cell(cols.zh).trim() };
      if (!t.en && !t.ms && !t.zh) continue;
      out.push({ tab, code, en: t.en, ms: t.ms, zh: t.zh });
    }
    return out;
  }

  async function parseWorkbook(arrayBuffer) {
    const files = await unzip(arrayBuffer, n => /^xl\/(workbook\.xml|_rels\/workbook\.xml\.rels|sharedStrings\.xml|styles\.xml|worksheets\/[^/]+\.xml)$/.test(n));
    if (!files['xl/workbook.xml']) throw new Error('That file is not a spreadsheet.');
    const rels = {}; let m;
    const relRe = /<Relationship\b[^>]*>/g;
    while ((m = relRe.exec(files['xl/_rels/workbook.xml.rels'] || ''))) {
      const id = (m[0].match(/\bId="([^"]+)"/) || [])[1], target = (m[0].match(/\bTarget="([^"]+)"/) || [])[1];
      if (id && target) rels[id] = 'xl/' + target.replace(/^\/?xl\//, '').replace(/^\//, '');
    }
    const strings = sharedStrings(files['xl/sharedStrings.xml']);
    const formats = cellFormats(files['xl/styles.xml']);
    const tabs = [], promos = [];
    const sheetRe = /<sheet\b[^>]*>/g;
    while ((m = sheetRe.exec(files['xl/workbook.xml']))) {
      const name = unxml((m[0].match(/\bname="([^"]*)"/) || [])[1] || '').trim();
      const rid = (m[0].match(/\br:id="([^"]+)"/) || [])[1];
      if (/\bstate="(hidden|veryHidden)"/.test(m[0]) || !name || !files[rels[rid]]) continue;
      const list = promosOf(name, sheetRows(files[rels[rid]], strings, formats));
      if (list.length) { tabs.push(name); promos.push(...list); }
    }
    return { tabs, promos };
  }

  return { parseWorkbook, promosOf };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = PromoParser;
