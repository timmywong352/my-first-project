/* Retrieval ranks reusable text; it never treats historical account results as policy. */
const RetrievalCore = (() => {
  const ALIASES=[['rebate','rebates','rebat','返水','回扣','回水','洗码'],['turnover','wagering','流水'],['withdraw','withdrawal','pengeluaran','提款','提现'],['deposit','topup','存款','充值'],['bonus','promotion','promo','promosi','优惠','红利']];
  const STOP=new Set('i me my we you your hi hello hey see can could would want know about details detail the a an and or is are it this that to for of please pls may what how when do does did tell get give on in as more much'.split(' '));
  const key=s=>String(s||'').toLowerCase().replace(/\s+/g,' ').trim();
  function terms(query){const lower=key(query),out=new Set();for(const group of ALIASES)if(group.some(w=>lower.includes(w)))group.forEach(w=>out.add(w));for(const w of lower.match(/[a-z0-9%]+|[\u3400-\u9fff]{2,}/g)||[])if(w.length>=3&&!STOP.has(w))out.add(w);return [...out].slice(0,30);}
  function score(text,query){const lower=key(text);return terms(query).reduce((n,w)=>n+(lower.includes(w)?1:0),0);}
  function accountQuestion(query){if(/(?:how\s*much|berapa|多少).{0,35}(?:rebate|rebat|返水)|(?:rebate|rebat)\s+amount|my\s+rebate\b/i.test(query))return true;return /(?:my|own|我的|本人|saya|akaun).{0,30}(?:rebate\s*(?:amount|balance)|balance|withdrawal\s*status|deposit\s*status|transaction|返水(?:金额|多少)|余额|到账|提款(?:进度|状态))|(?:how\s*much|berapa|多少).{0,25}(?:my\s+rebate|my\s+balance|返水|余额)|(?:rebate\s*amount).{0,25}(?:claim\s*tomorrow|today|my)|(?:check|semak|查).{0,20}(?:my\s+(?:rebate|deposit|withdrawal|balance)|余额|订单|交易)/i.test(query);}
  function privateLine(line){return /\[PERSON\]|\[EMAIL\]|\[NUMBER\]|\[SECRET\]|\bSGD\s*\d|(?:rebate\s+amount).{0,25}(?:RM|MYR)\s*\d|approximately\s*(?:RM|MYR)\s*\d|your\s+(?:rebate\s+(?:amount|is|for\s+today)|(?:current\s+)?balance|withdrawal\s+(?:amount|status)|deposit\s+(?:amount|status))|this\s+(?:rebate|withdrawal|deposit)|(?:has|have)\s+been\s+(?:approved|completed|processed|credited)|您的?(?:返水金额|余额|提款金额)|已(?:经)?(?:到账|成功|批准|完成)|(?:jumlah\s+rebat\s+anda|baki\s+anda|telah\s+dikreditkan)/i.test(line);}
  function generalMarker(text){return /automatically|eligible|eligibility|minimum|maximum|not\s+applicable|exclud|except|terms|daily\s+rebate|credited\s+(?:before|by)|turnover\s+(?:exceeds|above)|secara\s+automatik|layak|syarat|每日返水|自动|不适用|超过|至少|领取条件/i.test(text);}
  function extractPolicy(text){const lines=String(text||'').split(/\n|(?<=[.!?。！？])\s+/).map(s=>s.trim()).filter(Boolean);const safe=lines.filter(l=>!privateLine(l));const out=safe.join('\n');return generalMarker(out)?out.slice(0,2400):'';}
  function extractReusable(text){
    const lines=String(text||'').split(/\n|(?<=[.!?。！？])\s+/).map(s=>s.trim()).filter(Boolean).filter(line=>!privateLine(line));
    const out=lines.join('\n').trim();
    if(!out||out.length<12)return '';
    if(/^(?:hi|hello|您好|你好|please\s+wait|kindly\s+wait|one\s+moment|稍等|请稍候|请稍等|sila\s+tunggu)[\s~.!。！]*$/i.test(out))return '';
    if(out.length<180&&/please\s+wait|kindly\s+wait|one\s+moment|let\s+me\s+check|we(?:'ll|\s+will)\s+check|稍等|请稍候|请稍等|正在查询|帮您查询|sila\s+tunggu|kami\s+akan\s+semak/i.test(out))return '';
    if(/(?:ask|check\s+with|refer\s+to|contact)\s+(?:the\s+)?operator|operator\s+(?:will|needs?\s+to)|请联系(?:客服|专员)|需要专员|交给专员|rujuk\s+operator/i.test(out))return '';
    return out.slice(0,2400);
  }
  function approved(entries,query){return (entries||[]).filter(e=>!e.reviewRequired&&e.answer&&e.topic).map(e=>({e,n:score([e.topic,e.keywords,e.answer].join(' '),query)})).filter(x=>x.n>0).sort((a,b)=>b.n-a.n).slice(0,4).map(({e})=>({topic:'Hub: '+e.topic,keywords:[],en:e.lang==='en'?e.answer:'',ms:e.lang==='ms'?e.answer:'',zh:e.lang==='zh'?e.answer:'',sourceType:'approved',source:{chatId:e.chatId,threadId:e.threadId,at:e.reviewedAt},notes:'Reviewed Knowledge Hub answer. Current promotion-sheet terms take priority.'}));}
  function candidates(record,query){
    const out=[];let customer='';
    for(const m of record.messages||[]){
      if(m.role==='customer'){customer=m.text;continue;}
      if(m.role!=='agent'||!customer)continue;
      const text=extractReusable(m.text),questionScore=score(customer,query),answerScore=score(text,query),n=questionScore*2+answerScore;
      if(text&&n>0)out.push({text,n,question:customer.slice(0,1000),chatId:record.chatId,threadId:record.threadId,at:m.at||record.at});
    }
    return out;
  }
  function dedupe(rows){const seen=new Map();for(const row of rows){const k=key(row.text).replace(/[^\p{L}\p{N}%]+/gu,' ');const old=seen.get(k);if(!old||String(row.at)>String(old.at))seen.set(k,{...row,support:(old?.support||0)+1});else old.support++;}return [...seen.values()].sort((a,b)=>b.n-a.n||String(b.at).localeCompare(String(a.at))).slice(0,8);}
  function facts(text){const clocks=[...String(text).matchAll(/(?:before|by|no\s+later\s+than)\s*(\d{1,2})(?::(\d{2}))?\s*(AM|PM)/gi)].map(m=>((Number(m[1])%12)+(m[3].toUpperCase()==='PM'?12:0))*60+Number(m[2]||0));const min=(String(text).match(/(?:eligible[^\n]{0,35}?|turnover\s+)(?:exceeds|above|at\s+least|minimum(?:\s+of)?)\s*(?:RM|MYR)\s*([\d,]+(?:\.\d+)?)/i)||[])[1];return {clocks,min:min?Number(min.replace(/,/g,'')):null};}
  function conflict(rows,query){if(!terms(query).includes('rebate'))return '';const times=new Set(),minimums=new Set();for(const row of rows){const f=facts(row.text);f.clocks.forEach(v=>times.add(v));if(f.min!=null)minimums.add(f.min);}return times.size>1||minimums.size>1?'Historical rebate replies contain different crediting times or eligibility thresholds. Ask an operator to confirm the current rule.':'';}
  function historyRows(rows){return rows.slice(0,4).map(r=>({topic:'Archive answer '+r.chatId+'/'+r.threadId,keywords:[],en:r.text,ms:'',zh:'',sourceType:'historical',source:{chatId:r.chatId,threadId:r.threadId,at:r.at},notes:'Category-independent historical answer matched from the old customer question and agent reply; date '+r.at+'. Never reuse an account amount/status. Draft only, operator reviews before sending.'}));}
  function searchQuery(query){const lower=key(query);const group=ALIASES.find(g=>g.some(w=>lower.includes(w)));if(group)return group[0];return terms(query).filter(w=>/^[a-z0-9%]+$/.test(w)).slice(0,3).join(' ')||terms(query)[0]||'';}
  function parseExpansion(raw){
    let text=String(raw||'').trim().replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'');
    const start=text.indexOf('{'),end=text.lastIndexOf('}');if(start>=0&&end>start)text=text.slice(start,end+1);
    let data;try{data=JSON.parse(text);}catch(e){return [];}
    const seen=new Set(),out=[];
    for(const item of Array.isArray(data?.terms)?data.terms:[]){
      const value=key(item).replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim();
      if(value.length<2||value.length>80||seen.has(value))continue;
      seen.add(value);out.push(value);if(out.length>=24)break;
    }
    return out;
  }
  function combineQuery(query,expanded){const values=[String(query||'').trim(),...(expanded||[])].filter(Boolean),seen=new Set(),out=[];for(const value of values){const normalized=key(value);if(!normalized||seen.has(normalized))continue;seen.add(normalized);out.push(value);}return out.join(' ').slice(0,1800);}
  return {terms,score,accountQuestion,privateLine,generalMarker,extractPolicy,extractReusable,approved,candidates,dedupe,facts,conflict,historyRows,searchQuery,parseExpansion,combineQuery};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=RetrievalCore;
