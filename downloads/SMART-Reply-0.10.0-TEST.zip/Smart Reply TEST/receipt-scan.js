/* Hover-to-scan adaptation of supplied PG scanner. Local OCR only; no key access. */
(function(){
  function mount(root,hooks){
    const doc=root.ownerDocument,core=globalThis.SRReceiptCore;let seq=0,scanId='',receipt=null,member='',working=false,hover=null,hideTimer;
    const add=(tag,text,parent=root)=>{const n=doc.createElement(tag);n.textContent=text||'';parent.appendChild(n);return n;};
    add('h4','Scan deposit');
    const note=add('div','Hover a customer receipt in the chat and click Scan deposit. The image is read on this PC.');note.className='note';note.setAttribute('role','status');
    const facts=add('div'),choices=add('div'),result=add('div');facts.style.whiteSpace=result.style.whiteSpace='pre-wrap';result.style.padding='10px';result.setAttribute('role','status');
    const search=add('button','Search deposit');search.type='button';search.disabled=true;
    const clear=add('button','Clear scan');clear.type='button';
    add('div','Times are compared as Malaysia time (UTC+8). Green can mean Likely credited: one same-member/amount Finish record within 2 minutes, with no other nearby candidate or pagination. An exact reference match is shown separately. Review OCR before relying on it.').className='note';
    const hoverButton=doc.createElement('button');hoverButton.type='button';hoverButton.textContent='Scan deposit';hoverButton.style.cssText='position:fixed;display:none;z-index:2147483647;background:#1764a5;color:white;border:1px solid #b8d9ff;border-radius:8px;padding:8px 12px;cursor:pointer';doc.body.appendChild(hoverButton);
    function reset(){seq++;if(scanId)hooks.cancel(scanId);scanId='';receipt=null;member='';facts.textContent=choices.textContent=result.textContent='';result.style.background='';search.disabled=true;note.textContent='Hover a receipt in this chat to scan it.';hover=null;hoverButton.style.display='none';}
    clear.addEventListener('click',reset);
    function valid(token,stamp){return token===seq&&stamp===hooks.context();}
    const imageData=async img=>{
      if(img.tagName!=='IMG')throw new Error('Open the receipt as an image in the chat first.');
      let drawable=img;
      const canvas=doc.createElement('canvas');
      const draw=picture=>{const w=picture.naturalWidth,h=picture.naturalHeight;if(!w||!h||w*h>24000000)throw new Error('Receipt image is unreadable or too large.');const scale=Math.min(1,2000/Math.max(w,h));canvas.width=Math.round(w*scale);canvas.height=Math.round(h*scale);canvas.getContext('2d').drawImage(picture,0,0,canvas.width,canvas.height);return canvas.toDataURL('image/jpeg',0.92);};
      try{return draw(drawable);}catch(e){}
      const src=img.currentSrc||img.src;let u;try{u=new URL(src);}catch(e){throw new Error('Receipt image URL is unavailable.');}
      const allowed=u.protocol==='blob:'&&u.origin===location.origin||u.protocol==='https:'&&(u.hostname==='my.livechatinc.com'||/(^|\.)(livechat-files\.com|files-text\.com|livechatinc\.com)$/.test(u.hostname));
      if(!allowed)throw new Error('This image source is not supported. No new host access was added.');
      const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),12000);let blob;
      try{const response=await fetch(src,{mode:'cors',credentials:'omit',redirect:'error',signal:abort.signal});if(!response.ok)throw new Error('Image unavailable');blob=await response.blob();}catch(e){throw new Error('Chrome blocked receipt image access under the existing permissions. The image was not scanned.');}finally{clearTimeout(timer);}
      if(blob.size>8*1024*1024||!/^image\/(png|jpeg|webp)$/.test(blob.type))throw new Error('Unsupported receipt image format or size.');
      const url=URL.createObjectURL(blob);try{drawable=doc.createElement('img');await new Promise((resolve,reject)=>{drawable.onload=resolve;drawable.onerror=()=>reject(new Error('Receipt could not be decoded.'));drawable.src=url;});return draw(drawable);}finally{URL.revokeObjectURL(url);}
    };
    async function scan(img){
      if(working||hooks.isBusy()){note.textContent='Wait for the current task to finish.';return;}
      reset();const token=seq,stamp=hooks.context();working=true;hooks.lock(true);hooks.open();hooks.protect();note.textContent='Reading receipt locally…';
      try{
        const image=await imageData(img);if(!valid(token,stamp))return;
        scanId=crypto.randomUUID();const read=await hooks.ocr(image,scanId);scanId='';if(!valid(token,stamp))return;
        receipt=core.extract(read.text);receipt.confidence=read.confidence;
        if(read.confidence<65)receipt.warnings.push('Low OCR confidence: no green confirmation will be shown.');
        facts.textContent='Amount: '+(receipt.amount===null?'Not read':'RM'+receipt.amount.toFixed(2))+'\nReceipt time (Malaysia): '+(receipt.at===null?'Not read':core.formatTime(receipt.at)+(receipt.precision==='minute'?' (seconds not shown on receipt)':''))+'\nReference(s): '+(receipt.references.join(', ')||'Not read')+'\n'+receipt.warnings.join('\n');
        if(receipt.amount===null||receipt.at===null||read.confidence<65){note.textContent='Scan incomplete or low confidence. Use a clearer receipt; backend search is blocked to avoid using misread details.';return;}
        note.textContent='Finding usernames from this conversation…';const candidates=await hooks.members();if(!valid(token,stamp))return;
        const select=name=>{if(!valid(token,stamp))return;member=name;search.disabled=false;note.textContent='Account: '+name+'. Review the scanned details, then click Search deposit.';};
        if(candidates.length===1)select(candidates[0]);
        else if(candidates.length>1){note.textContent='Several usernames were found. Choose the account for this receipt.';for(const name of candidates){const b=add('button',name,choices);b.type='button';b.addEventListener('click',()=>{result.textContent='';select(name);});}}
        else note.textContent='No unambiguous username found. Ask the customer to provide it, then scan again.';
      }catch(e){if(valid(token,stamp))note.textContent=e.message||'Receipt scan failed.';}
      finally{working=false;hooks.lock(false);}
    }
    search.addEventListener('click',async()=>{
      if(working||hooks.isBusy()||!receipt||!member)return;
      const token=seq,stamp=hooks.context(),selected=member;working=true;hooks.lock(true);search.disabled=true;result.textContent='';note.textContent='Searching deposit report for '+member+'…';
      try{
        const report=await hooks.report(member,receipt.at,()=>valid(token,stamp)&&member===selected);if(!valid(token,stamp)||member!==selected)return;
        const outcome=core.evaluate(receipt,report,member);if(receipt.confidence<65&&outcome.state==='matched'){outcome.state='review';outcome.label='Matching record — low OCR confidence, verify manually';}
        result.style.background=outcome.state==='matched'?'#153e2a':outcome.state==='likely'||outcome.state==='review'?'#493919':'#42282b';
        result.textContent=(outcome.state==='matched'?'🟢 ':outcome.state==='likely'||outcome.state==='review'?'🟡 ':'🔴 ')+outcome.label+'\n'+outcome.rows.map(r=>'Member: '+r.member+' · RM'+r.amount.toFixed(2)+'\nStatus: '+r.status+'\nTransfer ID: '+(r.transferReference||'not available')+'\nConfirmed: '+(r.confirmedAt||'unknown')).join('\n\n');
        note.textContent='Read-only search complete. No customer message was sent. '+(report.pagination?'Only loaded rows were checked.':'');
      }catch(e){if(valid(token,stamp))note.textContent=e.message||'Deposit search failed.';}
      finally{working=false;hooks.lock(false);if(valid(token,stamp)&&member)search.disabled=false;}
    });
    // Reuse the supplied scanner's pointer-stack approach without copying its broad selectors or HTML rendering.
    doc.addEventListener('pointermove',e=>{
      if(e.target===hoverButton)return;
      const stack=doc.elementsFromPoint(e.clientX,e.clientY),img=stack.find(n=>n.tagName==='IMG'&&n.naturalWidth>1&&n.getBoundingClientRect().width>=80&&n.getBoundingClientRect().height>=80);
      if(img&&!root.getRootNode().host?.contains(img)&&!root.contains(img)){
        clearTimeout(hideTimer);hover=img;const rect=img.getBoundingClientRect();hoverButton.style.left=Math.max(4,Math.min(innerWidth-135,rect.right+4))+'px';hoverButton.style.top=Math.max(4,rect.top+4)+'px';hoverButton.style.display='block';
      }else{clearTimeout(hideTimer);hideTimer=setTimeout(()=>{hover=null;hoverButton.style.display='none';},300);}
    },{passive:true});
    hoverButton.addEventListener('pointerenter',()=>clearTimeout(hideTimer));
    hoverButton.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();const img=hover;hover=null;hoverButton.style.display='none';if(img)return scan(img);});
    window.addEventListener('scroll',()=>{hover=null;hoverButton.style.display='none';},true);
    return {clear:reset};
  }
  globalThis.SRReceiptScan={mount};
})();
