/* Selected-chat IDs only. Exact widget origin/frame, bounded request, no storage/network. */
(function(){
  const ORIGIN='https://golden-seahorse-ddf151.netlify.app';
  function create(win,doc,onChange=()=>{}){
    let selected='',pending=null;
    const frames=()=>Array.from(doc.querySelectorAll('iframe')).filter(frame=>{
      try{const url=new URL(frame.src);return url.origin===ORIGIN&&['/','/index.html'].includes(url.pathname)&&[...url.searchParams.keys()].every(key=>['theme','plugin_id'].includes(key)&&url.searchParams.getAll(key).length===1)&&!url.hash;}catch(e){return false;}
    });
    const valid=value=>typeof value==='string'&&/^[a-zA-Z0-9_-]{1,255}$/.test(value);
    function receive(event){
      const data=event.data;
      if(event.origin!==ORIGIN||!frames().some(frame=>frame.contentWindow===event.source)||!data||data.type!=='SR_SDK_CONTEXT'||data.version!==1)return;
      if(!['chats','archives','customers',''].includes(data.source)||!(data.chatId===''||valid(data.chatId))||!(data.threadId===''||valid(data.threadId)))return;
      const key=data.chatId+'|'+data.threadId;
      if(key!==selected){const changed=selected!=='';selected=key;if(changed)onChange();}
      if(pending&&data.requestId===pending.id&&event.source===pending.source){
        const request=pending;pending=null;win.clearTimeout(request.timer);
        request.resolve({chatId:data.chatId,threadId:data.threadId,source:data.source});
      }
    }
    win.addEventListener('message',receive);
    return {diagnostics(){
      const all=Array.from(doc.querySelectorAll('iframe'));
      const entries=all.map(frame=>{try{const url=new URL(frame.src);return url.origin===ORIGIN?'Widget origin; path='+url.pathname+'; query keys='+[...url.searchParams.keys()].join(',')+'; hash present='+!!url.hash:'Other frame origin: '+url.origin;}catch(e){return 'Frame URL unavailable';}});
      return 'Direct iframes: '+all.length+'; accepted widget frames: '+frames().length+'\n'+entries.join('\n');
    },read(){
      if(pending)return Promise.reject(new Error('SDK context request already running.'));
      const matches=frames();
      if(matches.length!==1)return Promise.reject(new Error('Open the Smart Reply SDK widget in this chat. One matching widget frame is required.'));
      return new Promise((resolve,reject)=>{
        const id=win.crypto.randomUUID(),source=matches[0].contentWindow;
        const timer=win.setTimeout(()=>{pending=null;reject(new Error('SDK widget did not answer. Upload the updated widget files and refresh LiveChat.'));},2500);
        pending={id,source,timer,resolve,reject};
        source.postMessage({type:'SR_SDK_GET_CONTEXT',version:1,requestId:id},ORIGIN);
      });
    },close(){win.removeEventListener('message',receive);if(pending){win.clearTimeout(pending.timer);pending.reject(new Error('SDK bridge closed.'));pending=null;}}};
  }
  const api={create};if(typeof module!=='undefined'&&module.exports)module.exports=api;else globalThis.SRSDKBridge=api;
})();
