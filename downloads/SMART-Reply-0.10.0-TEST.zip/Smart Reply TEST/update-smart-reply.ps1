# Smart Reply updater. Run it by double-clicking "Update Smart Reply.bat".
# It downloads the latest version and copies the files into this folder.
# Your keys and settings are NOT in these files, so they are kept.

$ErrorActionPreference = 'Stop'

function Read-Text($raw) {
    if ($raw -is [byte[]]) { $raw = [Text.Encoding]::UTF8.GetString($raw) }
    return ([string]$raw).TrimStart([char]0xFEFF)
}

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $root = Split-Path -Parent $MyInvocation.MyCommand.Path
    $cfgPath = Join-Path $root 'update-config.json'
    $manPath = Join-Path $root 'manifest.json'
    if (-not (Test-Path $manPath)) { throw 'manifest.json was not found. Keep this script inside the Smart Reply folder.' }
    if (-not (Test-Path $cfgPath)) { throw 'update-config.json was not found in this folder.' }

    $cfg = (Read-Text (Get-Content $cfgPath -Raw -Encoding UTF8)) | ConvertFrom-Json
    if (-not $cfg.versionUrl -or -not $cfg.zipUrl) { throw 'update-config.json has no versionUrl or zipUrl. Ask the owner of the extension.' }

    $localMan = (Read-Text (Get-Content $manPath -Raw -Encoding UTF8)) | ConvertFrom-Json
    $local = $localMan.version
    Write-Host ''
    Write-Host "Installed version : $local"

    Write-Host 'Checking for a new version...'
    $r = Invoke-WebRequest -Uri $cfg.versionUrl -UseBasicParsing
    $info = (Read-Text $r.Content) | ConvertFrom-Json
    Write-Host "Latest version    : $($info.version)"

    if ([version]$info.version -le [version]$local) {
        Write-Host ''
        Write-Host 'You are already up to date. Nothing to do.' -ForegroundColor Green
        exit 0
    }

    if ($info.notes) {
        Write-Host ''
        Write-Host "What's new in $($info.version):"
        $info.notes | ForEach-Object { Write-Host "  - $_" }
    }

    $tmp = Join-Path $env:TEMP ('smart-reply-update-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tmp | Out-Null
    $zip = Join-Path $tmp 'update.zip'

    Write-Host ''
    Write-Host 'Downloading...'
    Invoke-WebRequest -Uri $cfg.zipUrl -OutFile $zip -UseBasicParsing

    if ($info.sha256) {
        $hash = (Get-FileHash $zip -Algorithm SHA256).Hash
        if ($hash -ne ([string]$info.sha256).ToUpper()) {
            throw 'The downloaded file does not match the expected checksum. It may be damaged or changed. Nothing was installed.'
        }
        Write-Host 'Checksum OK.'
    }

    $ex = Join-Path $tmp 'files'
    Expand-Archive -Path $zip -DestinationPath $ex -Force
    $newMan = Get-ChildItem -Path $ex -Recurse -Filter manifest.json | Select-Object -First 1
    if (-not $newMan) { throw 'The downloaded file has no manifest.json. Nothing was installed.' }
    $src = $newMan.Directory.FullName
    $newInfo = (Read-Text (Get-Content $newMan.FullName -Raw -Encoding UTF8)) | ConvertFrom-Json
    if ($newInfo.name -ne $localMan.name) { throw 'The downloaded file is not Smart Reply. Nothing was installed.' }
    if ([string]$newInfo.version -ne [string]$info.version) { throw 'The downloaded version does not match the version file. Nothing was installed.' }

    # Backup of the current files (kept in your temp folder)
    $backup = Join-Path $env:TEMP ('smart-reply-backup-' + $local)
    if (Test-Path $backup) { Remove-Item $backup -Recurse -Force }
    Copy-Item -Path $root -Destination $backup -Recurse -Force

    # Copy the new files in. These stay as they are.
    $keep = @('update-config.json', 'update-smart-reply.ps1', 'Update Smart Reply.bat')
    $count = 0
    Get-ChildItem -Path $src -Recurse -File | ForEach-Object {
        $rel = $_.FullName.Substring($src.Length).TrimStart('\')
        if ($keep -contains $rel) { return }
        $dest = Join-Path $root $rel
        $dir = Split-Path -Parent $dest
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
        Copy-Item -Path $_.FullName -Destination $dest -Force
        $count++
    }

    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host ''
    Write-Host "Done. $count files updated to version $($info.version)." -ForegroundColor Green
    Write-Host "A backup of the old version is in: $backup"
    Write-Host ''
    Write-Host 'Last step: go back to Brave, click the SR button, and click Reload now. Then press F5 on LiveChat.' -ForegroundColor Yellow
}
catch {
    Write-Host ''
    Write-Host ('Update failed: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Nothing was changed, or the old version is in the backup folder shown above.'
    exit 1
}
