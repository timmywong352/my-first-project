/* Owner-approved general FAQs. Exact answers only; no account facts or AI. */
(function(){
  'use strict';
  const clean=value=>String(value||'').normalize('NFKC').replace(/[’]/g,"'").replace(/\s+/g,' ').trim();
  const language=value=>/^zh(?:[-_]|$)/i.test(String(value||''))?'zh':/(?:^ms(?:[-_]|$)|^(?:malay|bahasa))/i.test(String(value||''))?'ms':'en';
  const entries=[
    {
      id:'daily-rebate',topic:'Daily Rebate',
      match:text=>/(?:daily\s*(?:rebate|cashback)|(?:rebate|cashback)\s*daily|rebat\s*harian|(?:每日|每天).{0,8}返水|返水.{0,8}(?:每日|每天))/.test(text),
      en:'🎁 Daily Rebates 🎁\n\n• Rebate will be credited automatically before 3:00 AM the next day.\n• You are eligible if your daily turnover exceeds RM200.\n• The amount is based on your turnover, game type, and VIP level.\n• Pussy888, Mega88, 918Kiss, and all Blackjack 21 games are not eligible.',
      ms:'🎁 Rebat Harian 🎁\n\n• Rebat akan dikreditkan secara automatik sebelum jam 3:00 pagi pada hari berikutnya.\n• Anda layak jika turnover harian anda melebihi RM200.\n• Jumlah rebat bergantung pada turnover, jenis permainan dan tahap VIP anda.\n• Pussy888, Mega88, 918Kiss dan semua permainan Blackjack 21 tidak layak.',
      zh:'🎁 每日返水 🎁\n\n• 返水将在隔天凌晨 3:00 前自动派发。\n• 每日流水超过 RM200 即符合资格。\n• 返水金额将根据流水、游戏类型和 VIP 等级计算。\n• Pussy888、Mega88、918Kiss 以及所有 Blackjack 21 游戏不适用于每日返水。'
    },
    {
      id:'weekly-rescue',topic:'Weekly Rescue Bonus',
      match:text=>/(?:weekly\s*rescue|rescue\s*(?:bonus|promotion)|bonus\s*rescue|bonus\s*mingguan\s*rescue|救援.{0,6}(?:奖金|红利|优惠)|(?:每周|星期).{0,6}救援)/.test(text),
      en:'📢 Weekly Rescue Bonus\n\nIf your weekly net loss reaches RM1,000 or more, please visit our Promotion page every Monday and click “Apply” to claim your bonus.\n\n📌 Notes:\n• Applications are accepted only on Mondays.\n• The bonus is not eligible if you apply after Monday.\n• Net Loss = Gross Loss − Bonus − Rebate.\n• Poker, Allbet, and Lottery games are not eligible.\n• The bonus amount depends on your member tier and net loss, up to RM6,888.\n\nNeed help? Contact our customer service anytime! 💬',
      ms:'📢 Bonus Rescue Mingguan\n\nJika kerugian bersih mingguan anda mencecah RM1,000 atau lebih, sila kunjungi halaman Promosi kami pada setiap hari Isnin dan klik “Apply” untuk menuntut bonus anda.\n\n📌 Nota:\n• Permohonan hanya diterima pada hari Isnin.\n• Bonus tidak layak jika permohonan dibuat selepas hari Isnin.\n• Kerugian Bersih = Kerugian Kasar − Bonus − Rebat.\n• Permainan Poker, Allbet dan Lottery tidak layak.\n• Jumlah bonus bergantung pada tahap ahli dan kerugian bersih anda, sehingga RM6,888.\n\nPerlukan bantuan? Hubungi khidmat pelanggan kami pada bila-bila masa! 💬',
      zh:'📢 每周救援奖金\n\n如果您每周的净亏损达到 RM1,000 或以上，请在每个星期一前往我们的优惠页面，并点击“Apply”申请奖金。\n\n📌 注意事项：\n• 只接受星期一提交的申请。\n• 星期一之后提交申请将不符合资格。\n• 净亏损 = 总亏损 − 奖金 − 返水。\n• Poker、Allbet 和 Lottery 游戏不符合资格。\n• 奖金金额将根据会员等级和净亏损计算，最高可达 RM6,888。\n\n需要帮助？欢迎随时联系我们的客服！💬'
    },
    {
      id:'turnover-definition',topic:'Turnover Definition',
      match:text=>{
        if(/(?:my|saya|我的).{0,18}(?:turnover|流水)|(?:remaining|still\s*need|left|baki|还需|剩余).{0,18}(?:turnover|流水)|(?:check|semak|查询).{0,12}(?:turnover|流水)/.test(text))return false;
        return /(?:what\s+is|meaning\s+of|define)\s+(?:the\s+)?turnover|turnover\s+(?:meaning|definition)|how\s+(?:does\s+)?turnover\s+(?:work|count)|apa\s+(?:itu\s+)?turnover|turnover\s+(?:itu\s+)?apa|cara\s+(?:kira|pengiraan)\s+turnover|流水(?:是什么|是指什么|怎么算|如何计算)|(?:什么是|如何计算)流水/.test(text);
      },
      en:'Turnover refers to the total amount of bets placed on all matches. 💰\n\n• Win or lose — ✅ Both count towards turnover.\n• Tie or draw — ❌ Not included in the calculation.\n\n👉 Every eligible bet you place contributes to your total turnover! 📊',
      ms:'Turnover merujuk kepada jumlah keseluruhan pertaruhan yang dibuat untuk semua perlawanan. 💰\n\n• Menang atau kalah — ✅ Kedua-duanya dikira sebagai turnover.\n• Seri — ❌ Tidak termasuk dalam pengiraan.\n\n👉 Setiap pertaruhan yang layak akan menyumbang kepada jumlah turnover anda! 📊',
      zh:'流水是指您在所有赛事中所投注的总金额。💰\n\n• 无论输赢 — ✅ 都会计算为流水。\n• 和局 — ❌ 不计入流水。\n\n👉 您所下的每一笔有效投注都会计入总流水！📊'
    },
    {
      id:'transaction-limits',topic:'Deposit and Withdrawal Limits',
      match:text=>/(?:min(?:imum)?|max(?:imum)?|limit|had\s*(?:minimum|maksimum)?|最低|最高|上限).{0,24}(?:deposit|depo|withdraw(?:al)?|bank\s*transfer|存款|充值|提款|转账)|(?:deposit|depo|withdraw(?:al)?|bank\s*transfer|存款|充值|提款|转账).{0,24}(?:min(?:imum)?|max(?:imum)?|limit|had|最低|最高|上限)/.test(text),
      en:'The minimum deposit is RM30, and the minimum withdrawal is RM50. The maximum withdrawal limit is 10 times per day, with a daily bank transfer limit of RM60,000. Thank you.',
      ms:'Deposit minimum ialah RM30 dan pengeluaran minimum ialah RM50. Had maksimum pengeluaran ialah 10 kali sehari, dengan had pindahan bank harian sebanyak RM60,000. Terima kasih.',
      zh:'最低存款金额为 RM30，最低提款金额为 RM50。每天最多可提款 10 次，每日银行转账限额为 RM60,000。谢谢。'
    },
    {
      id:'appslot-id',topic:'MEGA888 / 918KISS / Pussy888 ID',
      match:text=>/(?:mega\s*888|mega88|918\s*kiss|918kiss|pussy\s*888|pussy888).{0,45}(?:\bid\b|account|login|display|show|appear|账号|账户|显示)|(?:\bid\b|account|login|display|show|appear|账号|账户|显示).{0,45}(?:mega\s*888|mega88|918\s*kiss|918kiss|pussy\s*888|pussy888)/.test(text),
      en:'MEGA888 / 918KISS / Pussy888 ID Not Displaying?\n\n1️⃣ Open MEGA888, 918KISS, or Pussy888.\n2️⃣ Enter the amount and tap “Buy in”.\n3️⃣ Tap “Play Now”, then return to the page.\n4️⃣ Your ID will appear after these steps.\n\nOnce you deposit and transfer the credit, you will receive the ID and password. Download the APK, then log in using that ID and password. Thank you.',
      ms:'ID MEGA888 / 918KISS / Pussy888 tidak dipaparkan?\n\n1️⃣ Buka MEGA888, 918KISS atau Pussy888.\n2️⃣ Masukkan jumlah dan tekan “Buy in”.\n3️⃣ Tekan “Play Now”, kemudian kembali ke halaman tersebut.\n4️⃣ ID anda akan dipaparkan selepas langkah-langkah ini.\n\nSelepas anda membuat deposit dan memindahkan kredit, anda akan menerima ID dan kata laluan. Muat turun APK, kemudian log masuk menggunakan ID dan kata laluan tersebut. Terima kasih.',
      zh:'MEGA888 / 918KISS / Pussy888 ID 没有显示？\n\n1️⃣ 打开 MEGA888、918KISS 或 Pussy888。\n2️⃣ 输入金额并点击“Buy in”。\n3️⃣ 点击“Play Now”，然后返回该页面。\n4️⃣ 完成以上步骤后，您的 ID 就会显示。\n\n存款并转入游戏额度后，您将获得 ID 和密码。请下载 APK，然后使用该 ID 和密码登录。谢谢。'
    },
    {
      id:'password-reset',topic:'Forgot Password',
      match:text=>/(?:forgot|forget|reset|recover|lost|lupa|terlupa|忘记|忘了|重置|找回).{0,24}(?:password|passowrd|pass\b|kata\s*laluan|密码)|(?:password|passowrd|kata\s*laluan|密码).{0,24}(?:forgot|forget|reset|recover|lost|lupa|terlupa|忘记|忘了|重置|找回)/.test(text),
      en:'Kindly retrieve your password through the link below:\nhttps://m.md88-safe.com/my/forget\n\nPlease follow the instructions on the page to reset your password. If you still have not received it, kindly let us know again. Sorry for the inconvenience.\n\n✨ Thank you! ✨',
      ms:'Sila dapatkan semula kata laluan anda melalui pautan di bawah:\nhttps://m.md88-safe.com/my/forget\n\nSila ikuti arahan pada halaman tersebut untuk menetapkan semula kata laluan anda. Jika anda masih belum menerimanya, sila maklumkan kepada kami sekali lagi. Maaf atas kesulitan yang berlaku.\n\n✨ Terima kasih! ✨',
      zh:'请通过以下链接找回您的密码：\nhttps://m.md88-safe.com/my/forget\n\n请按照页面上的说明重置密码。如果您仍未收到密码，请再次联系我们。对于给您带来的不便，我们深感抱歉。\n\n✨ 谢谢！✨'
    }
  ];
  const usernameRecovery=text=>/(?:forgot|forget|recover|lost|lupa|terlupa|忘记|忘了|找回).{0,24}(?:user\s*name|username|login\s*id|nama\s*pengguna|用户名|账号)|(?:user\s*name|username|login\s*id|nama\s*pengguna|用户名|账号).{0,24}(?:forgot|forget|recover|lost|lupa|terlupa|忘记|忘了|找回)/.test(text);
  const credentialDisclosure=text=>/\b(?:my\s+)?(?:password|passowrd|passcode|pin)\s*(?:is|[:=])\s*\S+|\b(?:kata\s*laluan|pin)\s+saya\s*(?:ialah|adalah|[:=])\s*\S+|我的?(?:密码|验证码|动态码)(?:是|[:：=])\S+/.test(text);
  function find(query,lang='en'){
    const text=clean(query).toLowerCase();if(!text)return {ok:false,reason:'No customer question was provided.'};
    if(credentialDisclosure(text))return {ok:false,operator:true,reason:'A credential or verification secret may be present. Do not copy, store, or reuse it in an automatic reply.'};
    if(usernameRecovery(text))return {ok:false,operator:true,reason:'The approved recovery procedure covers passwords only. Forgotten usernames require operator confirmation.'};
    const matches=entries.filter(entry=>entry.match(text));
    if(matches.length!==1)return {ok:false,...(matches.length>1?{operator:true,reason:'Several approved FAQ topics matched. Confirm the intended question.'}:{reason:'No approved FAQ matched.'})};
    const entry=matches[0],code=language(lang),answer=entry[code]||entry.en;
    return {ok:true,id:entry.id,topic:entry.topic,text:answer,lang:code,sourceType:'approved-rule'};
  }
  const api={clean,language,entries,find};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else globalThis.SRApprovedFAQ=api;
})();
