/* One-shot report snapshot. Reads whitelisted columns; never clicks or fetches. */
(function(){
  const core=globalThis.SRAccountCore,rules=globalThis.SRWithdrawalRules;
  if(!core||!rules||location.origin!=='https://mcd88.kg8.co')return {notReport:true};
  const kind=Object.keys(core.paths).find(k=>core.paths[k]===location.pathname);if(!kind)return {notReport:true};
  if(document.querySelector('input[type="password"]'))return {error:'Log in yourself and reopen the report.'};
  const output={notReport:false,kind,readAt:new Date().toISOString(),rows:[],promotionRows:[],rebateRows:[],providers:[],deposit:null,totalBet:null,duration:[],baseStatus:'',promotionTable:false,member:''};
  let found=false,balanceTables=0,balanceMalformed=false;
  for(const table of document.querySelectorAll('table')){
    if(!table.getClientRects().length||getComputedStyle(table).visibility==='hidden')continue;
    const rows=Array.from(table.rows).filter(row=>row.closest('table')===table&&row.getClientRects().length);
    const types=kind==='turnover'?['providers','promotionTurnover','rebate']:[kind];
    for(const type of types){
      let header=-1,cols,labels;
      for(let i=0;i<Math.min(rows.length,30);i++){labels=Array.from(rows[i].cells).map(cell=>cell.innerText);cols=core.columns(type,labels);if(cols){header=i;break;}}
      if(header<0)continue;found=true;
      if(type==='balance'){
        balanceTables++;
        for(const row of rows.slice(header+1)){
          const cells=Array.from(row.cells),values=cells.map((cell,index)=>Object.values(cols).includes(index)?String(cell.innerText||'').trim():'');
          if(!values.some(Boolean))continue;
          if(cells.length===1&&/^(?:no (?:records?|results?|data|members?)(?: found)?[.!]?|没有记录|无记录)$/i.test(values[0]))continue;
          const member=core.who(values[cols.member]),amount=core.number(values[cols.amount]),currency=core.clean(values[cols.currency]);
          if(!/^[a-z0-9_.-]{1,255}$/.test(member)||amount===null||!/^[A-Z]{3}$/.test(currency||''))balanceMalformed=true;
        }
      }
      const allowed=new Set(Object.values(cols).filter(i=>i>=0));
      const matrix=[labels,...rows.slice(header+1).map(row=>Array.from(row.cells).map((cell,index)=>allowed.has(index)?cell.innerText:''))];
      const parsed=core.parse(type,matrix)||[];
      if(type==='providers'){
        output.providers.push(...parsed);
        for(const row of rows){const cells=Array.from(row.cells);if(!cells.length)continue;const label=core.clean(cells[0].innerText);
          if(/^duration$/i.test(label)){output.duration=cells.slice(1).map(c=>core.clean(c.innerText)).filter(t=>/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(t)).slice(0,2);}
          if(/^all turnover(?:\(|\s|$)/i.test(label)){output.totalBet=core.number(cells[1]?.innerText);output.deposit=core.number(cells[2]?.innerText);}
          if(cells[2]&&/^(?:finish turnover|unfinished)$/i.test(core.clean(cells[2].innerText)))output.baseStatus=core.clean(cells[2].innerText);
        }
      }else if(type==='promotionTurnover'){output.promotionTable=true;output.promotionRows.push(...parsed);}
      else if(type==='rebate')output.rebateRows.push(...parsed);else output.rows.push(...parsed);
    }
  }
  if(!found)return {error:'Expected report headers were not found. No account status inferred.'};
  const inputs=Array.from(document.querySelectorAll('input:not([type="password"]):not([type="hidden"])')).filter(e=>e.getClientRects().length);
  const members=inputs.filter(e=>(kind==='balance'?['membername','memberaccount','username']:['memberaccount','memberusername','username','loginusername']).includes(globalThis.SRAccountSearch?.label(e)));
  if(members.length===1)output.member=core.who(members[0].value);
  const currencies=Array.from(document.querySelectorAll('select')).filter(e=>globalThis.SRAccountSearch?.label(e)==='currency');
  const statuses=Array.from(document.querySelectorAll('select')).filter(e=>globalThis.SRAccountSearch?.label(e)==='status');
  output.filterControls={currency:currencies.length,status:statuses.length};
  output.statusFilter=statuses.length===1?core.clean(statuses[0].options[statuses[0].selectedIndex]?.textContent):'';
  output.currency=currencies.length===1?core.clean(currencies[0].options[currencies[0].selectedIndex]?.textContent):'';
  output.dateRange=inputs.map(e=>e.value).filter(v=>/^\d{4}-\d{2}-\d{2}(?:[ T]\d{2}:\d{2}(?::\d{2})?)?$/.test(v)).slice(0,2);
  const pageTexts=[];
  for(const e of document.querySelectorAll('a,button,input[type="button"],input[type="submit"],nav,[role="navigation"],select'))if(e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden')pageTexts.push(e.getAttribute('aria-label')||e.textContent||e.value||'');
  if(document.body&&document.createTreeWalker){const walker=document.createTreeWalker(document.body,4);let node;while((node=walker.nextNode())){const p=node.parentElement;if(p&&!p.closest('table,script,style')&&p.getClientRects().length&&getComputedStyle(p).visibility!=='hidden'&&/(?:page\s*\d+\s*(?:of|\/)\s*\d+|第\s*\d+\s*页)/i.test(node.nodeValue||''))pageTexts.push(node.nodeValue);}}
  output.pagination=rules.hasPagination(pageTexts);
  if(kind==='balance')output.memberEvidence={...globalThis.SRAccountSearch?.inspect(),tableCount:balanceTables,malformed:balanceMalformed};
  output.documentId=globalThis.__SRWithdrawalDocumentId||(globalThis.__SRWithdrawalDocumentId=Date.now().toString(36)+'-'+Math.random().toString(36).slice(2));
  return output;
})();
