/* Owner-confirmed wording. No backend writes and no AI/network calls. */
(function () {
  const MAX_AUTOMATIC_ROW_AGE_MS = 24 * 60 * 60 * 1000;
  const normalize = value => String(value || '').replace(/\s+/g,' ').trim();
  const language = value => /^zh(?:[-_]|$)/i.test(String(value||''))?'zh':/(?:^ms(?:[-_]|$)|^(?:malay|bahasa))/i.test(String(value||''))?'ms':'en';
  const fixedReplies={
    en:{
      processing:'We are currently handling a large number of withdrawal requests, and our team is working through them as quickly as possible. Your withdrawal is also in the process and will be credited to your bank account once it is completed. We truly appreciate your patience and understanding during this time.',
      'payment-closed':'Kindly resubmit your withdrawal request again. We truly appreciate your patience and cooperation.',
      'withdrawal-limit':'Your withdrawal has failed because you have reached the daily withdrawal limit of 10 times. Please resubmit your withdrawal request tomorrow. Thank you for your understanding.',
      'bank-account-required':'Kindly use a bank account to submit your withdrawal. E-wallet accounts cannot currently be used to submit a withdrawal.',
      'holder-name-mismatch':'Your withdrawal has failed because the bank account holder name you submitted does not match. Kindly use a bank account with a holder name that matches your registered name to submit the withdrawal. Other names will be rejected. We appreciate your cooperation. Thank you.',
      'full-name-required':'Please provide your full name. We will update it in the system, and once done, you can resubmit your withdrawal request. Thank you.',
      'free-spins-unused':'Your withdrawal has failed because you have not used your free spins yet. Kindly check and make sure you finish all your free spins, and after that, resubmit your withdrawal request. Thank you.',
      wait:'Kindly wait a moment.',
      closing:'Thank you so much for your patience. If you have any questions, don’t hesitate to reach out to me~ I’m always here to assist you.'
    },
    ms:{
      processing:'Kami sedang mengendalikan jumlah permohonan pengeluaran yang tinggi, dan pasukan kami sedang memprosesnya secepat mungkin. Pengeluaran anda juga sedang diproses dan akan dikreditkan ke akaun bank anda setelah selesai. Kami amat menghargai kesabaran dan pemahaman anda.',
      'payment-closed':'Sila hantar semula permohonan pengeluaran anda. Kami amat menghargai kesabaran dan kerjasama anda.',
      'withdrawal-limit':'Pengeluaran anda gagal kerana anda telah mencapai had pengeluaran harian sebanyak 10 kali. Sila hantar semula permohonan pengeluaran anda esok. Terima kasih atas pemahaman anda.',
      'bank-account-required':'Sila gunakan akaun bank untuk menghantar permohonan pengeluaran. Buat masa ini, akaun e-dompet tidak boleh digunakan untuk membuat pengeluaran.',
      'holder-name-mismatch':'Pengeluaran anda gagal kerana nama pemegang akaun bank yang anda berikan tidak sepadan. Sila gunakan akaun bank dengan nama pemegang yang sepadan dengan nama berdaftar anda untuk membuat pengeluaran. Nama lain akan ditolak. Kami menghargai kerjasama anda. Terima kasih.',
      'full-name-required':'Sila berikan nama penuh anda. Kami akan mengemas kininya dalam sistem dan, setelah selesai, anda boleh menghantar semula permohonan pengeluaran anda. Terima kasih.',
      'free-spins-unused':'Pengeluaran anda gagal kerana anda belum menggunakan putaran percuma anda. Sila semak dan pastikan anda menghabiskan semua putaran percuma, kemudian hantar semula permohonan pengeluaran anda. Terima kasih.',
      wait:'Sila tunggu sebentar.',
      closing:'Terima kasih atas kesabaran anda. Jika anda mempunyai sebarang pertanyaan, jangan teragak-agak untuk menghubungi saya~ Saya sentiasa di sini untuk membantu anda.'
    },
    zh:{
      processing:'目前提款申请数量较多，我们的团队正在尽快处理。您的提款也正在处理中，完成后款项将汇入您的银行账户。非常感谢您的耐心与理解。',
      'payment-closed':'请您重新提交提款申请。非常感谢您的耐心与配合。',
      'withdrawal-limit':'您的提款失败，因为您已达到每日10次的提款上限。请您明天重新提交提款申请。感谢您的理解。',
      'bank-account-required':'请使用银行账户提交提款申请。目前无法使用电子钱包账户提交提款。',
      'holder-name-mismatch':'您的提款失败，因为您提交的银行账户持有人姓名不一致。请使用持有人姓名与您注册姓名一致的银行账户提交提款申请，其他姓名将被拒绝。感谢您的配合。',
      'full-name-required':'请提供您的全名。我们会在系统中为您更新，完成后您即可重新提交提款申请。谢谢。',
      'free-spins-unused':'您的提款失败，因为您尚未使用完免费旋转。请检查并完成所有免费旋转，之后再重新提交提款申请。谢谢。',
      wait:'请稍等片刻。',
      closing:'非常感谢您的耐心等待。如有任何疑问，请随时联系我们～我会一直在这里为您提供协助。'
    }
  };
  const amountText=value=>Number(value).toLocaleString('en-US',{maximumFractionDigits:2});
  function classify(status,remarks='') {
    const raw=normalize(status),remark=normalize(remarks),text=normalize(raw+' '+remark),fields=[remark,raw].filter(Boolean);
    if(/(?:contact|ask).{0,12}live\s*chat|live\s*chat|(?:contact|ask|check\s+with).{0,12}operator|operator\s+(?:check|review|required|only)/i.test(text))return {kind:'manual',reason:'The backend asks for an operator or LiveChat check. An operator must confirm the cause.'};
    if(/\b(?:do\s+not|don't|not)\s+(?:(?:please|kindly)\s+)?(?:submit|use)\s+(?:a\s+)?bank(?:\s+account)?\b/i.test(text))return {kind:'manual',reason:'The bank-account instruction is negated or unclear. Ask an operator before replying.'};
    const causes=[];
    const add=(cause,result)=>causes.push({cause,result});
    for(const value of fields){
      if(/^limit\s+wd(?:\s*\.\s*be\s+closed)?\s*[.!]?$/i.test(value))add('withdrawal-limit',{kind:'withdrawal-limit'});
      if(/\b(?:please|kindly)\s+(?:submit(?:\s+(?:using|with))?|use)\s+(?:a\s+)?bank(?:\s+account)?\b/i.test(value))add('bank-account-required',{kind:'bank-account-required'});
      if(/\b(?:bank\s+account\s+)?holder(?:\s+name)?\s+(?:(?:is|was)\s+)?(?:not\s+(?:the\s+)?same|does(?:n't|\s+not)\s+match|mismatch(?:ed)?)\b/i.test(value))add('holder-name-mismatch',{kind:'holder-name-mismatch'});
      if(/\b(?:(?:get|provide|need|update)\s+(?:the\s+|your\s+|member\s+)?full\s+name|full\s+name\s+(?:is\s+)?required)\b/i.test(value))add('full-name-required',{kind:'full-name-required'});
      if(/\b(?:belum|tak|tidak)\s+(?:main|guna|gunakan|habis(?:kan)?)\s+(?:fs|free\s*spins?)\b/i.test(value)||/\b(?:have\s+not|haven't|has\s+not|hasn't|not)\s+(?:used|played|completed|finished)\s+(?:the\s+|all\s+)?free\s*spins?\b/i.test(value)||/\bfree\s*spins?\s+(?:not\s+(?:used|played|completed|finished)|unused|unfinished)\b/i.test(value))add('free-spins-unused',{kind:'free-spins-unused'});
      if(/(?:unfinish(?:ed)?|unfished|incomplete|remaining|未完成).{0,24}(?:turnover|流水)|(?:turnover|流水).{0,24}(?:unfinish(?:ed)?|unfished|incomplete|remaining|未完成)/i.test(value)){
        const matches=[
          ...value.matchAll(/(?:turnover|流水).{0,30}(?:still\s+need|need|shortfall|remaining|balance).{0,12}(?:RM|MYR)\s*[-:：=]?\s*(\d+(?:,\d{3})*(?:\.\d{1,2})?)(?![\d.,])/ig),
          ...value.matchAll(/(?:turnover|流水)\s*(?:shortfall|remaining|balance)?\s*[:：=\-]?\s*(?:RM|MYR)?\s*(-?\d+(?:,\d{3})*(?:\.\d{1,2})?)(?![\d.,])/ig),
          ...value.matchAll(/(?:RM|MYR)?\s*(-?\d+(?:,\d{3})*(?:\.\d{1,2})?)(?![\d.,])\s*(?:unfinish(?:ed)?|unfished|incomplete|remaining|未完成).{0,12}(?:turnover|流水)/ig)
        ];
        if(!matches.length)add('turnover',{kind:'manual',candidate:'turnover',reason:'Turnover shortfall is not explicit. Confirm the remaining amount manually.'});
        for(const match of matches){const amount=Number(match[1].replace(/,/g,''));add('turnover',Number.isFinite(amount)&&amount>0&&amount<=1e9?{kind:'turnover',remaining:amount}:{kind:'manual',reason:'Turnover amount needs confirmation.'});}
      }
    }
    const kinds=[...new Set(causes.map(item=>item.cause))];
    if(kinds.length>1)return {kind:'manual',reason:'The withdrawal status and remark contain conflicting recognized reasons. Ask an operator before replying.'};
    if(kinds.length===1){
      const matches=causes.filter(item=>item.cause===kinds[0]).map(item=>item.result);
      if(kinds[0]==='turnover'){
        const amounts=[...new Set(matches.filter(item=>item.kind==='turnover').map(item=>item.remaining))];
        if(amounts.length>1)return {kind:'manual',reason:'Different remaining-turnover amounts are shown. Confirm the correct amount with an operator.'};
        if(amounts.length===1)return {kind:'turnover',remaining:amounts[0]};
      }
      return matches[0];
    }
    const paymentClosed=value=>/^payment\s*(?:is\s*)?closed[.!]?$/i.test(value);
    if(fields.some(paymentClosed)){
      const unknown=fields.some(value=>!paymentClosed(value)&&!/^(?:(?:please|kindly)\s+)?resubmit(?:\s+(?:the\s+)?withdrawal(?:\s+request)?)?(?:\s+again)?[.!]?$/i.test(value));
      return unknown?{kind:'manual',reason:'Payment closed has an unrecognized backend remark. Ask an operator before replying.'}:{kind:'payment-closed'};
    }
    const processing=value=>/^(?:processing|submitting|in\s*(?:process|progress)|pending\s*processing)[.!]?$/i.test(value);
    if(fields.some(processing)){
      return fields.every(processing)?{kind:'processing'}:{kind:'manual',reason:'Processing has an unrecognized backend remark. Ask an operator before replying.'};
    }
    return {kind:'manual',reason:'This status has no confirmed mapping. Ask an operator; do not infer its meaning.'};
  }
  function reply(result,lang='en') {
    const code=language(lang),fixed=fixedReplies[code];
    if(result&&fixed[result.kind])return fixed[result.kind];
    if(result?.kind==='turnover'&&Number.isFinite(result.remaining)&&result.remaining>0){
      const amount=amountText(result.remaining);
      if(code==='zh')return '经查询，您还需要完成 RM'+amount+' 的投注额，才能达到提款所需的流水要求。';
      if(code==='ms')return 'Selepas semakan, anda masih perlu membuat pertaruhan sebanyak RM'+amount+' lagi untuk memenuhi syarat turnover bagi pengeluaran.';
      return 'Upon checking, you still need to bet RM'+amount+' more to meet the turnover requirement for withdrawal.';
    }
    return '';
  }
  function quickReply(kind,lang='en'){
    return fixedReplies[language(lang)][kind]||'';
  }
  function compose(result,lang='en',options={}){
    const primary=reply(result,lang);if(!primary)return '';
    return options&&options.includeClosing?primary+'\n\n'+quickReply('closing',lang):primary;
  }
  const member=value=>(String(value||'').split(/\r?\n/).map(line=>line.trim().replace(/^\+\s*/,'')) .find(line=>line&&!/^\([^)]*\)$/.test(line))||'').replace(/\s*\([^)]*\)\s*$/,'').toLowerCase();
  function headerColumns(cells) {
    const labels=cells.map(value=>normalize(value).toLowerCase().replace(/[^a-z]/g,''));
    const index=(...names)=>labels.findIndex(x=>names.includes(x));
    const cols={id:index('noid','id','no','transactionid','withdrawalid'),status:index('status','withdrawstatus','withdrawalstatus'),member:index('useragent','user','member','memberaccount','username'),currency:index('currency'),amount:index('amount','withdrawamount','withdrawalamount'),time:index('timeconfirmtime','time','requesttime','createdat'),remarks:index('remarks','remark','reason','rejectreason')};
    return ['id','status','member','currency','amount'].every(key=>cols[key]>=0)?cols:null;
  }
  function extract(matrix) {
    const rows=matrix.map(row=>row.map(value=>String(value||'').trim()));let header=-1,cols;
    for(let i=0;i<Math.min(rows.length,30);i++){const found=headerColumns(rows[i]);if(found){header=i;cols=found;break;}}
    if(header<0)return [];
    const out=[],seen=new Set();
    for(const cells of rows.slice(header+1)) {
      const at=name=>cols[name]>=0?cells[cols[name]]||'':'';
      const ids=at('id').match(/\d{4,}/g),id=ids?.at(-1);if(!id||seen.has(id))continue;
      const who=member(at('member')),currency=normalize(at('currency')).toUpperCase(),amountText=at('amount').replace(/,/g,'').trim();
      if(!who||!/^\d+(?:\.\d{1,2})?$/.test(amountText))continue;
      const status=at('status'),result=classify(status,at('remarks'));
      const times=at('time').match(/\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}/g)||[];
      out.push({id,member:who,currency,amount:Number(amountText),status:normalize(status).slice(0,400),requestedAt:times[0]||'',confirmedAt:times[1]||'',result});seen.add(id);
    }
    return out;
  }
  function fingerprint(row){return JSON.stringify([row.id,row.member,row.currency,row.amount,row.status,row.requestedAt,row.confirmedAt,row.result]);}
  function searchRange(days,now=new Date()) {
    if(![1,7,30].includes(days))throw new Error('Choose a 1, 7 or 30 day search window.');
    const format=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kuala_Lumpur',year:'numeric',month:'2-digit',day:'2-digit'});
    const today=format.format(now),start=new Date(today+'T00:00:00+08:00');start.setTime(start.getTime()-(days-1)*86400000);
    return {from:format.format(start)+' 00:00:00',to:today+' 23:59:59'};
  }
  function choose(rows,username,reference='') {
    const matches=rows.filter(row=>row.member===member(username)&&(reference?row.id===String(reference).trim():true));
    if(!matches.length)return {error:'No matching withdrawal in this report range. Widen the date range or check manually.'};
    if(matches.length>1)return {error:'Several withdrawals match. Select the exact reference below before drafting.'};
    if(matches[0].currency!=='MYR')return {error:'This is not a MYR withdrawal; an operator must check it.'};
    if(!reply(matches[0].result))return {error:matches[0].result.reason||'This status needs an operator check.'};
    return {row:matches[0]};
  }
  function containsBackendReply(text) {
    const value=normalize(text).toLowerCase();
    const fixed=['processing','payment-closed','withdrawal-limit','bank-account-required','holder-name-mismatch','full-name-required','free-spins-unused'].some(kind=>['en','ms','zh'].some(lang=>value.includes(normalize(reply({kind},lang)).toLowerCase())));
    const checkedFact=/upon checking, your deposit of rm[\d,.]+ was successfully credited at \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} \(backend time\)[.]/i.test(value)||/upon checking, your [a-z0-9_.-]+ promotion bonus was successfully credited at \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} \(backend time\)[.]/i.test(value)||/selepas semakan, deposit anda sebanyak rm[\d,.]+ telah berjaya dikreditkan pada \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} \(waktu backend\)[.]/i.test(value)||/selepas semakan, bonus promosi [a-z0-9_.-]+ anda telah berjaya dikreditkan pada \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} \(waktu backend\)[.]/i.test(value)||/经查询，您的\s*rm[\d,.]+\s*存款已于\s*\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\s*成功到账（后台时间）。?/i.test(value)||/经查询，您的\s*[a-z0-9_.-]+\s*优惠奖金已于\s*\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\s*成功派发（后台时间）。?/i.test(value);
    return fixed||checkedFact||/upon checking, you still need to bet rm[\d,.]+ more to meet the turnover requirement for withdrawal[.]/i.test(value)||/selepas semakan, anda masih perlu membuat pertaruhan sebanyak rm[\d,.]+ lagi untuk memenuhi syarat turnover bagi pengeluaran[.]/i.test(value)||/经查询，您还需要完成\s*rm[\d,.]+\s*的投注额，才能达到提款所需的流水要求。?/i.test(value);
  }
  function rowAge(row,now=Date.now()) {
    const raw=String(row.requestedAt||'').trim();
    const explicit=/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:Z|[+-]\d{2}:\d{2})$/.test(raw);
    const plain=/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(raw);
    if(!explicit&&!plain)return {safe:false,label:'Age unknown (requested time missing or invalid)'};
    const parts=raw.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})/);
    if(!parts||Number(parts[4])>23||Number(parts[5])>59||Number(parts[6])>59||new Date(Date.UTC(Number(parts[1]),Number(parts[2])-1,Number(parts[3]))).toISOString().slice(0,10)!==raw.slice(0,10))return {safe:false,label:'Age unknown (invalid time)'};
    const base=Date.parse(raw.replace(' ','T')+(plain?'Z':''));
    if(!Number.isFinite(base)||new Date(base).toISOString().slice(0,10)!==raw.slice(0,10)&&plain)return {safe:false,label:'Age unknown (invalid time)'};
    // No report timezone is known. Bound a naive time across UTC-12 through UTC+14.
    const youngest=now-base-(plain?12*3600000:0),oldest=now-base+(plain?14*3600000:0);
    const days=Math.floor(youngest/86400000),hours=Math.floor(youngest/3600000);
    const label=youngest<0?'Time may be in the future':days>=1?days+' day'+(days===1?'':'s')+' ago':hours>=1?hours+' hour'+(hours===1?'':'s')+' ago':'Less than an hour ago';
    return {safe:youngest>=0&&oldest<=MAX_AUTOMATIC_ROW_AGE_MS,label:youngest<0?'Age unverified (requested time or timezone needs checking)':(plain?'At least ':'')+label+(plain?' (timezone unverified)':'')};
  }
  function draftGuard({row,reference='',confirmed=false,pagination=false,manual=false,now=Date.now()}) {
    if(reference&&String(reference).trim()!==row.id)return 'The entered withdrawal reference does not match this row.';
    if(!rowAge(row,now).safe&&!reference&&!confirmed)return 'The requested time is older than 24 hours or its age is unverified. Enter the exact reference or confirm this is the withdrawal the customer asked about.';
    if(pagination&&!reference&&!manual)return 'More than one report page may exist. Enter the exact withdrawal reference or use the manual check.';
    return '';
  }
  function hasPagination(texts) {
    if(texts.filter(value=>/^\s*\d+\s*$/.test(value)).length>1)return true;
    return texts.some(value=>{
      const text=normalize(value);
      const pages=text.match(/\bpage\s*(\d+)\s*(?:of|\/)\s*(\d+)\b/i)||text.match(/第\s*(\d+)\s*页\s*(?:共|[\/／])\s*(\d+)\s*页/);
      return /^(?:\d+\s+){1,}\d+$/.test(text)||!!(pages&&Number(pages[2])>1)||/^(?:next(?:\s+page)?|last(?:\s+page)?|下一页|下页|末页|尾页|[›»])\s*[›»→]?$/i.test(text);
    });
  }
  const api={normalize,classify,reply,quickReply,compose,language,member,headerColumns,extract,fingerprint,searchRange,choose,rowAge,draftGuard,hasPagination,MAX_AUTOMATIC_ROW_AGE_MS,containsBackendReply};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  else globalThis.SRWithdrawalRules=api;
})();
