/* FIFO account-check scheduling. Backend reports and customer replies stay outside this module. */
(function(root,factory){
  'use strict';
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.SRCheckQueue=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const DEFAULT_TIMEOUT_MS=60000;
  const MAX_JOBS=100;
  const statuses=Object.freeze(['waiting','checking','completed','not-found','failed','cancelled']);
  const labels=Object.freeze({waiting:'Waiting',checking:'Checking',completed:'Completed','not-found':'No username found',failed:'Loading failed',cancelled:'Cancelled'});
  const interruptedDetail='This check was interrupted. Confirm the backend is available, then retry or resume the queue.';
  const text=value=>String(value==null?'':value);
  const finiteTime=(value,fallback)=>Number.isFinite(Number(value))&&Number(value)>=0?Number(value):fallback;

  function create(options={}){
    if(typeof options.execute!=='function')throw new TypeError('Queue execute callback is required.');
    const now=typeof options.now==='function'?options.now:Date.now;
    const schedule=typeof queueMicrotask==='function'?queueMicrotask:callback=>Promise.resolve().then(callback);
    let jobs=[],waiting=[],active=null,paused=false,pauseReason='',sequence=0,scheduled=false,disposed=false;
    let timeoutMs=Number(options.timeoutMs)>0?Number(options.timeoutMs):DEFAULT_TIMEOUT_MS;
    const prefix='qc-'+now().toString(36)+'-'+Math.random().toString(36).slice(2,9)+'-';
    const copy=job=>({...job,position:job.status==='waiting'?Math.max(0,waiting.indexOf(job.id)+1):0,sourceTabs:{...job.sourceTabs}});
    const get=id=>jobs.find(job=>job.id===String(id));
    const hasActiveChat=(chatId,except)=>jobs.some(job=>job!==except&&job.chatId===chatId&&(job.status==='waiting'||job.status==='checking'));
    const snapshot=()=>({jobs:jobs.map(copy),paused,pauseReason,blocked:!!active&&active.invalid,runningId:active?.job.id||'',timeoutMs});
    function emit(){
      if(typeof options.onChange==='function')options.onChange(snapshot());
    }
    function normalize(meta={},existing={}){
      const value={...existing,...meta},chatId=text(value.chatId).trim(),username=text(value.username).trim().toLowerCase();
      if(!chatId||!/^[a-z0-9_.-]{1,255}$/.test(username)||!['deposit','promotion','withdrawal'].includes(value.category))throw new Error('A chat ID, exact username and valid check category are required.');
      const sourceTabs={};
      for(const [kind,id] of Object.entries(value.sourceTabs||{}))if(['balance','deposit','promotion','withdrawal','turnover'].includes(kind)&&Number.isSafeInteger(Number(id))&&Number(id)>0)sourceTabs[kind]=Number(id);
      return {chatId,startUrl:text(value.startUrl||value.url),username,category:value.category,days:Number(value.days)===7?7:1,lang:['auto','en','ms','zh'].includes(value.lang)?value.lang:'auto',detectedLang:['en','ms','zh'].includes(value.detectedLang)?value.detectedLang:'en',promoCode:text(value.promoCode),sourceTabs};
    }
    function requestPump(){
      if(scheduled||disposed)return;scheduled=true;
      schedule(()=>{scheduled=false;void pump();});
    }
    function invalidate(attempt){
      attempt.invalid=true;
      if(attempt.timer)clearTimeout(attempt.timer);
      attempt.controller?.abort();
    }
    function fail(job,detail){
      job.status='failed';job.detail=detail||'The backend check could not finish. Please retry.';job.finishedAt=now();paused=true;pauseReason=job.detail;
    }
    function supersede(chatId){
      for(const job of jobs)if(job.chatId===chatId&&['failed','not-found'].includes(job.status)){
        job.status='cancelled';job.superseded=true;job.attempt++;job.detail='Replaced by a newer check in this chat.';job.finishedAt=now();
      }
    }
    function makeRoom(){
      while(jobs.length>=MAX_JOBS){
        const removable=jobs.find(job=>['completed','cancelled'].includes(job.status)&&active?.job!==job);
        if(!removable)return false;jobs=jobs.filter(job=>job!==removable);
      }
      return true;
    }
    async function pump(){
      if(active||paused||disposed)return;
      let job;
      while(waiting.length&&!job){const candidate=get(waiting.shift());if(candidate?.status==='waiting')job=candidate;}
      if(!job)return;
      job.status='checking';job.startedAt=now();job.finishedAt=0;job.detail='Checking this customer…';
      const attempt={job,revision:job.attempt,invalid:false,controller:typeof AbortController==='function'?new AbortController():null,timer:null};
      active=attempt;
      const current=()=>!disposed&&active===attempt&&!attempt.invalid&&job.attempt===attempt.revision&&job.status==='checking';
      const token=Object.freeze({
        current,
        signal:attempt.controller?.signal,
        attempt:attempt.revision,
        setDetail(detail){if(current()){job.detail=text(detail);emit();}},
        setSourceTab(kind,id){if(current()&&['balance','deposit','promotion','withdrawal','turnover'].includes(kind)&&Number.isSafeInteger(Number(id))&&Number(id)>0){job.sourceTabs[kind]=Number(id);emit();}}
      });
      attempt.timer=setTimeout(()=>{if(current()){invalidate(attempt);fail(job,'The check timed out. Confirm the backend has finished loading or log in again, then retry.');emit();}},timeoutMs);
      emit();
      try{
        if(!current())return;
        const result=await options.execute(copy(job),token);
        if(current()){
          if(result?.status==='not-found'){job.status='not-found';job.detail=text(result.detail)||'Member “'+job.username+'” was not found. Confirm or edit the username, then retry.';}
          else if(result?.status==='completed'){job.status='completed';job.detail=text(result.detail)||'Result available in its original chat.';}
          else fail(job,text(result?.detail)||'The backend returned an incomplete or invalid result. Please retry.');
          job.finishedAt=now();
        }
      }catch(error){if(current())fail(job,text(error?.message)||'The backend could not be loaded. Please retry.');}
      finally{
        // Keep the execution slot until the actual promise settles, even after timeout.
        // An uncancellable old browser search must not race the next username.
        if(attempt.timer)clearTimeout(attempt.timer);
        attempt.invalid=true;
        if(active===attempt)active=null;
        if(!disposed){emit();requestPump();}
      }
    }
    function enqueue(meta){
      if(disposed)return null;
      const value=normalize(meta);
      if(hasActiveChat(value.chatId))return null;
      if(!makeRoom())return null;
      supersede(value.chatId);
      const job={...value,id:prefix+(++sequence),attempt:1,submittedAt:now(),startedAt:0,finishedAt:0,status:'waiting',detail:paused?'Queue paused. Resume when the backend is available.':'Waiting for earlier checks.'};
      jobs.push(job);waiting.push(job.id);emit();requestPump();return copy(job);
    }
    function cancel(id){
      const job=get(id);if(!job||job.status!=='waiting')return false;
      waiting=waiting.filter(item=>item!==job.id);job.attempt++;job.status='cancelled';job.detail='Cancelled before the check started.';job.finishedAt=now();emit();return true;
    }
    function retry(id,meta={}){
      const job=get(id);if(!job||job.superseded||!['failed','not-found','cancelled'].includes(job.status)||disposed)return null;
      const value=normalize(meta,job);if(hasActiveChat(value.chatId,job))return null;
      const wasFailed=job.status==='failed';Object.assign(job,value,{attempt:job.attempt+1,status:'waiting',detail:'Waiting to retry.',submittedAt:now(),startedAt:0,finishedAt:0});
      waiting=waiting.filter(item=>item!==job.id);if(wasFailed)waiting.unshift(job.id);else waiting.push(job.id);
      if(wasFailed){paused=false;pauseReason='';}emit();requestPump();return copy(job);
    }
    function skip(id){
      const job=get(id);if(!job||job.status!=='failed')return false;
      job.attempt++;job.status='cancelled';job.detail='Skipped. Resume the queue when ready.';job.finishedAt=now();emit();return true;
    }
    function resume(){
      if(disposed)return false;
      const interrupted=jobs.filter(job=>job.status==='failed');
      for(const job of interrupted){
        if(hasActiveChat(job.chatId,job))continue;
        job.attempt++;job.status='waiting';job.detail='Waiting to retry after resume.';job.startedAt=0;job.finishedAt=0;
      }
      waiting=[...interrupted.filter(job=>job.status==='waiting').map(job=>job.id),...waiting];
      waiting=[...new Set(waiting)];paused=false;pauseReason='';emit();requestPump();return true;
    }
    function remove(id){
      const job=get(id);if(!job||['waiting','checking'].includes(job.status)||active?.job===job)return false;
      jobs=jobs.filter(item=>item!==job);emit();return true;
    }
    function serialize(){
      // No report, draft, diagnostic detail, promotion text or source-tab data is persisted.
      return jobs.map(job=>({id:job.id,chatId:job.chatId,startUrl:job.startUrl,username:job.username,category:job.category,days:job.days,lang:job.lang,detectedLang:job.detectedLang,submittedAt:job.submittedAt,startedAt:job.startedAt,finishedAt:job.finishedAt,status:job.status}));
    }
    function restore(records){
      if(active||jobs.length||disposed)throw new Error('Restore is only allowed before new queue work starts.');
      const ids=new Set();
      for(const record of Array.isArray(records)?records.slice(-MAX_JOBS):[]){
        try{
          if(!statuses.includes(record.status))continue;
          const value=normalize(record),id=text(record.id)||prefix+(++sequence);if(ids.has(id))continue;ids.add(id);
          const interrupted=['waiting','checking','failed'].includes(record.status),status=interrupted?'failed':record.status;
          jobs.push({...value,id,attempt:1,submittedAt:finiteTime(record.submittedAt,now()),startedAt:finiteTime(record.startedAt,0),finishedAt:finiteTime(record.finishedAt,0),status,detail:interrupted?interruptedDetail:status==='completed'?'This check completed before reload. Run a fresh check to view its result.':status==='not-found'?'Member “'+value.username+'” was not found. Confirm or edit the username, then retry.':'Cancelled.'});
          if(interrupted)paused=true;
        }catch(error){/* Ignore invalid stored metadata; it must never trigger a search. */}
      }
      // Older persisted failures must not replay after a newer check in that chat.
      const latest=new Map();for(const job of jobs)latest.set(job.chatId,job);
      for(const job of jobs)if(job.status==='failed'&&latest.get(job.chatId)!==job){job.status='cancelled';job.superseded=true;job.detail='Replaced by a newer check in this chat.';}
      paused=jobs.some(job=>job.status==='failed');
      pauseReason=paused?interruptedDetail:'';
      emit();return snapshot();
    }
    function dispose(){disposed=true;if(active)invalidate(active);}
    return Object.freeze({enqueue,cancel,retry,skip,resume,remove,restore,serialize,dispose,snapshot,get:id=>{const job=get(id);return job?copy(job):null;},setTimeoutMs(value){if(Number(value)>0&&Number.isFinite(Number(value)))timeoutMs=Number(value);},get jobs(){return jobs.map(copy);},get paused(){return paused;},get blocked(){return !!active&&active.invalid;},get runningId(){return active?.job.id||'';},get timeoutMs(){return timeoutMs;}});
  }
  return Object.freeze({create,statuses,labels,DEFAULT_TIMEOUT_MS,MAX_JOBS});
});
