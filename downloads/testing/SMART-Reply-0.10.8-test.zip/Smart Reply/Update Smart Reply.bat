@echo off
title Update Smart Reply
cd /d "%~dp0"
powershell -NoProfile -File "%~dp0update-smart-reply.ps1"
if errorlevel 1 echo Update did not complete. Keep Windows protection enabled and ask the maintainer for help.
echo.
pause
