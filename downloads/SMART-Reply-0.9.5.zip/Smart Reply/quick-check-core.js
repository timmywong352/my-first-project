/* Quick Check: pure, read-only result modelling. No DOM, storage, or network. */
(function(){
  'use strict';

  const categories=Object.freeze(['deposit','promotion','withdrawal']);
  const kindMap=Object.freeze({
    deposit:Object.freeze(['deposit','turnover']),
    promotion:Object.freeze(['promotion','turnover']),
    withdrawal:Object.freeze(['withdrawal','deposit','turnover'])
  });
  const titles=Object.freeze({deposit:'Deposit result',promotion:'Promotion result',withdrawal:'Withdrawal result'});
  const labels=Object.freeze({deposit:'Deposit',promotion:'Promotion',withdrawal:'Withdrawal'});

  function reportKinds(category){
    return [...(kindMap[category]||[])];
  }

  function createState(chatId=''){
    return {
      chatId:String(chatId||''),
      username:'',
      usernameEdited:false,
      lang:'auto',
      detectedLang:'en',
      category:'deposit',
      days:1,
      promoCode:'',
      result:null,
      draft:'',
      checkedAt:'',
      requestId:0
    };
  }

  const validTime=value=>{
    const text=String(value||''),match=text.match(/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/);if(!match)return false;
    const [,year,month,day,hour,minute,second]=match.map(Number);if(hour>23||minute>59||second>59)return false;
    const parsed=new Date(Date.UTC(year,month-1,day,hour,minute,second));return parsed.getUTCFullYear()===year&&parsed.getUTCMonth()===month-1&&parsed.getUTCDate()===day;
  };
  const backendTime=value=>validTime(value)?String(value)+' · Backend time':'Not shown';
  const row=(label,value,note='')=>({label,value:String(value==null||value===''?'Not shown':value),...(note?{note}:{})});
  const manualOutcome=reason=>({ok:false,kind:'manual',source:'quick-check',reason:String(reason||'Operator review is required.'),reply:''});
  const replyLanguage=value=>/^zh(?:[-_]|$)/i.test(String(value||''))?'zh':/(?:^ms(?:[-_]|$)|^(?:malay|bahasa))/i.test(String(value||''))?'ms':'en';
  const replyMoney=value=>'RM'+Number(value).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
  function customerReply(outcome,lang='en',withdrawalRules){
    if(!outcome||!outcome.ok)return '';
    const language=replyLanguage(lang);
    if(outcome.kind==='deposit-credited'){
      if(outcome.currency!=='MYR'||!Number.isFinite(outcome.amount)||outcome.amount<=0||!validTime(outcome.confirmedAt))return '';
      const amount=replyMoney(outcome.amount),time=outcome.confirmedAt;
      if(language==='zh')return '经查询，您的 '+amount+' 存款已于 '+time+' 成功到账（后台时间）。';
      if(language==='ms')return 'Selepas semakan, deposit anda sebanyak '+amount+' telah berjaya dikreditkan pada '+time+' (waktu backend).';
      return 'Upon checking, your deposit of '+amount+' was successfully credited at '+time+' (backend time).';
    }
    if(outcome.kind==='promotion-credited'){
      const code=String(outcome.code||'').trim();if(!code||!validTime(outcome.confirmedAt))return '';
      const time=outcome.confirmedAt;
      if(language==='zh')return '经查询，您的 '+code+' 优惠奖金已于 '+time+' 成功派发（后台时间）。';
      if(language==='ms')return 'Selepas semakan, bonus promosi '+code+' anda telah berjaya dikreditkan pada '+time+' (waktu backend).';
      return 'Upon checking, your '+code+' promotion bonus was successfully credited at '+time+' (backend time).';
    }
    const rules=withdrawalRules||globalThis.SRWithdrawalRules;
    if(!rules)return '';
    if(typeof rules.compose==='function')return rules.compose(outcome,language);
    return typeof rules.reply==='function'?rules.reply(outcome,language):'';
  }
  function factualOutcome(kind,reason,fields={}){
    const outcome={ok:true,kind,source:'quick-check',reason:String(reason||''),...fields};
    outcome.reply=customerReply(outcome,'en');
    return outcome;
  }
  const periodText=days=>Number(days)===1?'Today':'Last 7 days';
  const noRecordText=days=>Number(days)===1?'No record found in today’s loaded results.':'No record found in the last 7 days’ loaded results.';
  const money=(core,value,currency='MYR')=>Number.isFinite(value)?(currency==='MYR'&&core&&typeof core.money==='function'?core.money(value):currency+' '+Number(value).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:3})):'Not shown';
  const turnover=(core,value)=>Number.isFinite(value)?(core&&typeof core.turnoverNumber==='function'?core.turnoverNumber(value):Number(value).toLocaleString('en-US',{minimumFractionDigits:3,maximumFractionDigits:3})):'Not shown';
  const exactRows=(report,username,currency=false)=>(Array.isArray(report?.rows)?report.rows:[]).filter(item=>item&&item.member===username&&(!currency||item.currency==='MYR'));

  function basicProblem(report,username,kind){
    if(!report)return labels[kind]+' report unavailable.';
    if(report.error)return String(report.error);
    if(report.member&&report.member!==username)return labels[kind]+' report member does not match the checked username.';
    if((kind==='deposit'||kind==='withdrawal')&&report.currency&&report.currency!=='MYR')return labels[kind]+' report is not filtered to MYR.';
    if(report.statusFilter&&!/^all$/i.test(report.statusFilter))return labels[kind]+' status filter must be All.';
    if(report.pagination)return 'Pagination was detected; the latest '+kind+' is not verified across every page.';
    return '';
  }

  function baseModel(category,username,days,checkedAt){
    return {
      category,
      title:titles[category]||'Quick Check result',
      username,
      period:periodText(days),
      checkedAt:String(checkedAt||''),
      verification:'Not verified',
      status:'Not verified',
      rows:[],
      warnings:['Backend timestamps are shown verbatim; backend timezone is not verified.'],
      outcome:manualOutcome('No verified customer outcome is available.'),
      canReply:false
    };
  }

  function finish(model){
    model.warnings=[...new Set(model.warnings.filter(Boolean).map(String))];
    model.canReply=!!(model.verification==='Verified'&&model.outcome&&model.outcome.ok&&String(model.outcome.reply||'').trim());
    return model;
  }

  function missing(model,days,reason){
    const message=reason||noRecordText(days);
    model.status='No record';
    model.rows=[row('Status','No record'),row('Search period',periodText(days))];
    model.warnings.unshift(message);
    model.outcome=manualOutcome(message);
    return finish(model);
  }

  function buildDeposit(model,username,reports,days,core){
    const report=reports.deposit,problem=basicProblem(report,username,'deposit');
    if(!report||report.error)return missing(model,days,problem);
    const rows=exactRows(report,username,true),latest=core.latest(rows);
    if(!rows.length)return missing(model,days,noRecordText(days));
    if(!latest){
      model.status='Not verified';
      model.warnings.unshift(problem||'No unique latest exact-member MYR deposit was found. Missing or tied request times require operator review.');
      return finish(model);
    }
    model.status=latest.status||'Status not shown';
    model.rows=[
      row('Status',model.status),
      row('Amount',money(core,latest.amount,latest.currency)),
      row('Requested time',backendTime(latest.requestedAt)),
      row('Confirm time',backendTime(latest.confirmedAt)),
      row('Reference',latest.id||'Not shown')
    ];
    if(latest.transferReference)model.rows.push(row('Transfer reference',latest.transferReference));
    let check={state:'not-verified',badge:'NOT VERIFIED',note:'Deposit cross-check unavailable.'};
    if(typeof core.depositReconciliation==='function')check=core.depositReconciliation(username,reports);
    model.rows.push(row('Deposit cross-check',check.badge||'NOT VERIFIED',check.note||''));
    if(problem)model.warnings.unshift(problem);
    if(check.state==='matched'&&!problem)model.verification='Verified';
    else {
      model.verification=latest?'Needs review':'Not verified';
      model.warnings.unshift(check.note||'Deposit cross-check is not verified.');
    }
    const newerPending=Array.isArray(check.newerPending)?check.newerPending:[];
    if(newerPending.length)model.warnings.unshift('A newer non-Finish deposit is shown and may not yet be included in turnover.');
    const sameMatchedRow=!!(check.row&&latest.id&&String(check.row.id||'')===String(latest.id));
    if(!problem&&check.state==='matched'&&sameMatchedRow&&!newerPending.length&&/^finish$/i.test(latest.status||'')&&latest.currency==='MYR'&&Number.isFinite(latest.amount)&&latest.amount>0&&validTime(latest.confirmedAt)){
      model.outcome=factualOutcome('deposit-credited','The unique latest successful MYR deposit matches the turnover report.',{amount:latest.amount,currency:'MYR',confirmedAt:latest.confirmedAt,reference:String(latest.id||'')});
    }else model.outcome=manualOutcome('Deposit details are shown, but a uniquely matched successful credit with a valid confirmation time was not verified.');
    return finish(model);
  }

  function buildPromotion(model,username,reports,days,core){
    const report=reports.promotion,problem=basicProblem(report,username,'promotion');
    if(!report||report.error)return missing(model,days,problem);
    const claims=exactRows(report,username),claim=core.latest(claims);
    if(!claims.length)return missing(model,days,noRecordText(days));
    if(!claim){
      model.status='Not verified';
      model.warnings.unshift(problem||'No unique latest exact-member promotion was found. Missing or tied request times require operator review.');
      return finish(model);
    }
    const turn=typeof core.promotionState==='function'?core.promotionState(username,reports.turnover):{key:'not_verified',badge:'NOT VERIFIED',recentPromotion:null,explanation:'Promotion turnover is unavailable.',requiresOperator:true};
    const turnRow=turn.recentPromotion;
    model.status=claim.status||'Status not shown';
    model.rows=[
      row('Claim status',model.status),
      row('Promotion code',claim.code||'Not shown'),
      row('Remark',claim.remarks||'No remark shown'),
      row('Requested time',backendTime(claim.requestedAt)),
      row('Confirm time',backendTime(claim.confirmedAt)),
      row('Reference',claim.id||'Not shown'),
      row('Promotion turnover status',turnRow?.status||turn.badge||'Not verified'),
      row('Required turnover',turnRow?turnover(core,turnRow.required):'Not verified'),
      row('Recorded bet',turnRow?turnover(core,turnRow.bet):'Not verified'),
      row('Turnover confirm time',turnRow?backendTime(turnRow.confirmedAt):'Not verified')
    ];
    if(problem)model.warnings.unshift(problem);
    const codeConflict=!!(turnRow&&String(turnRow.code||'').toLowerCase()!==String(claim.code||'').toLowerCase());
    if(codeConflict)model.warnings.unshift('The latest claim and latest turnover record have different promotion codes. Review both records.');
    if(turn.explanation)model.warnings.unshift(turn.explanation);
    model.verification=!problem&&turnRow&&!turn.requiresOperator&&!codeConflict?'Verified':'Needs review';
    const credited=/^(?:credited|bonus (?:is )?credited|promotion bonus (?:is )?credited|successfully credited|credited successfully)[.!]?$/i.test(String(claim.remarks||'').trim());
    if(model.verification==='Verified'&&/^confirmed$/i.test(claim.status||'')&&credited&&String(claim.code||'').trim()&&validTime(claim.confirmedAt)){
      model.outcome=factualOutcome('promotion-credited','The unique latest confirmed promotion claim explicitly says the bonus was credited and matches the turnover promotion code.',{code:String(claim.code).trim(),confirmedAt:claim.confirmedAt,reference:String(claim.id||'')});
    }else model.outcome=manualOutcome('Promotion claim and turnover evidence are shown separately, but an unambiguous credited bonus was not verified.');
    return finish(model);
  }

  function buildWithdrawal(model,username,reports,days,core,rules,checkedAt,confirmed=false){
    const report=reports.withdrawal,problem=basicProblem(report,username,'withdrawal');
    if(!report||report.error)return missing(model,days,problem);
    const rows=exactRows(report,username,true),latest=core.latest(rows);
    if(!rows.length)return missing(model,days,noRecordText(days));
    if(!latest){
      model.status='Not verified';
      model.warnings.unshift(problem||'No unique latest exact-member MYR withdrawal was found. Missing or tied request times require operator review.');
      return finish(model);
    }
    model.status=latest.status||'Status not shown';
    model.rows=[
      row('Status',model.status),
      row('Amount',money(core,latest.amount,latest.currency)),
      row('Requested time',backendTime(latest.requestedAt)),
      row('Confirm time',backendTime(latest.confirmedAt)),
      row('Reference',latest.id||'Not shown'),
      row('Remark',latest.remarks||'No remark shown; no reason inferred.')
    ];
    if(problem)model.warnings.unshift(problem);
    model.verification=problem?'Needs review':'Verified';
    let outcome=manualOutcome('Withdrawal status has no approved automatic customer outcome.');
    if(typeof core.customerOutcome==='function'){
      const at=Date.parse(String(checkedAt||'')),options={...(Number.isFinite(at)?{now:at}:{}),...(confirmed?{confirmed:true}:{})};
      outcome=core.customerOutcome(username,reports,rules,options);
    }
    model.outcome=outcome||manualOutcome('Withdrawal status requires operator review.');
    if(!model.outcome.ok&&model.outcome.reason)model.warnings.unshift(model.outcome.reason);
    return finish(model);
  }

  function buildResult(input={},accountCore,withdrawalRules){
    const core=accountCore||globalThis.SRAccountCore;
    if(!core||typeof core.latest!=='function')throw new Error('Account helpers are unavailable.');
    const category=categories.includes(input.category)?input.category:'deposit';
    const username=typeof core.who==='function'?core.who(input.username):String(input.username||'').trim().toLowerCase();
    const days=Number(input.days)===7?7:1,checkedAt=input.checkedAt||new Date().toISOString(),reports=input.reports||{},model=baseModel(category,username,days,checkedAt);
    if(!/^[a-z0-9_.-]{1,255}$/.test(username)){
      model.warnings.unshift('Enter the exact backend username.');
      model.outcome=manualOutcome('The member username is missing or invalid.');
      return finish(model);
    }
    if(category==='deposit')return buildDeposit(model,username,reports,days,core);
    if(category==='promotion')return buildPromotion(model,username,reports,days,core);
    return buildWithdrawal(model,username,reports,days,core,withdrawalRules||globalThis.SRWithdrawalRules,checkedAt,!!input.confirmed);
  }

  const api={categories,reportKinds,createState,buildResult,customerReply};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  else globalThis.SRQuickCheck=api;
})();
