SMART REPLY FOR LIVECHAT  (your own extension, separate from your colleague's)

WHAT IT DOES
1. Reads the open LiveChat conversation.
2. Picks the matching rows from your knowledge sheet.
3. Writes the reply in the customer's language and puts it in the message box.
4. You check it and press Send yourself. Nothing is sent automatically.

SET UP (about 15 minutes, one time)

Step 1. Install the extension
1. Unzip this folder to your Desktop and name the folder Smart Reply.
2. Open brave://extensions and turn on Developer mode.
3. Click Load unpacked and choose the Smart Reply folder.

Step 2. Make your knowledge sheet
1. Open Google Drive and upload knowledge-starter.csv.
2. Right-click it, choose Open with, then Google Sheets.
3. Click Share, choose Anyone with the link, role Viewer, and copy the link.
Add a new row whenever you meet a question the sheet does not cover. The more rows, the better the replies.
Columns: TOPIC, KEYWORDS (words the customer may type, in any language, separated by commas), ENGLISH, MALAY, CHINESE, NOTES (when to use the row).
Keep the row named RULES. It is always sent to the AI.

Step 3. Get your keys (keep them private)
1. LiveChat: Developer Console, Settings, Authorization, Personal Access Tokens. Create a token that can read chats, then copy the Base64 encoded token.
2. Groq: create a free key at console.groq.com.

Step 3b. Your promo sheet (the one with PROMO CODE, ENG, MALAY, CHINESE)
1. Open your promo Google Sheet and click Share.
2. Choose Anyone with the link, role Viewer, and copy the link.
3. Do not change the sheet. The extension reads every tab by itself (hidden tabs are skipped).
It finds the header row with ENG, MALAY and CHINESE on each tab. The first column is the promo code or name.

Step 4. Save them in the extension
1. Open LiveChat and press F5. A green message appears at the top, and a blue SR button appears at the bottom left.
2. Click SR, then Settings. Paste the LiveChat token, the Groq key, the knowledge sheet link, and the promo sheet link. Click Save, then Back.
3. Click Refresh knowledge and Refresh promos. They show the number of rows and promos.

HOW TO USE
1. For a common question, open the Reply tab and click Create customer reply (or press Alt and R).
2. Read the draft in the message box, correct it if needed, then press Send yourself.
3. If facts or an account status need checking, open Ask an operator. Click Prepare operator question, review it, then click Copy for WeChat.
4. You can switch to another LiveChat conversation while waiting. The unfinished operator handoff is kept for that chat until the page is refreshed.
5. When the operator replies, return to the customer chat and paste the confirmed answer in Step 2.
6. Choose the customer language and click Prepare customer reply. Review the draft before using it in LiveChat.
7. If the operator says the check is still pending, tick that box so the reply does not imply completion or approval.

ACCOUNT QUICK CHECK
1. Open Account and enter the exact backend username, or choose one found from the current chat.
2. Choose Today, Last 7 days, or Last 30 days, then click Check this username.
3. The extension opens or finds five read-only backend tabs and searches them: member balance, deposit report, promotion report, withdrawal turnover, and withdrawal report.
4. The Turnover duration start is shown as the latest-deposit time. Providers above 0.000 are listed with their three-decimal turnover amount.
5. Deposit cross-check compares that Turnover amount/time with the unique latest confirmed successful MYR deposit. Reports that differ are marked REPORTS DIFFER — RECHECK; a newer pending deposit is reported separately.
6. Review the current balance, latest deposit, provider play, latest promotion and turnover status, and latest withdrawal status. "Latest" means the unique latest row inside the selected loaded period; pagination and missing records remain clearly marked Not verified.
7. Promotion badges distinguish active, carried into a new deposit, finished, conflicting, same-time and unknown states. Any other Unfinished row blocks a cleared interpretation.
8. Use Copy operator summary only when you intend to paste the operator-only result elsewhere. Copy rechecks every successful report and the selected chat; changed/reloaded reports or results over five minutes old are rejected.
9. Nothing is sent automatically, and backend data is not sent to AI. Detailed calculations and manual fallback remain under Advanced turnover & manual tools.

PROMOS
1. When a customer types a promo code or name that is in your promo sheet, Auto reply puts the exact promo text in the message box, in the customer's language. Nothing is rewritten.
2. If the customer asks a question about the promo, the AI gets the real promo text and answers from it.
3. Find promo: type a few letters of a code or name, click the result, and the text goes in the message box.
4. Calculate: type for example deposit RM50 claim 100PPU, then click Calculate. The deposit, bonus, total balance and turnover for each game type are worked out from the numbers in the promo text (percentage, Min Deposit, Max Bonus, and lines like Webslot x5). Check the numbers before you send.
5. The calculator works only when the promo text has a percentage bonus. Fixed bonuses such as RM60 get RM8 are not calculated.
6. Turnover is worked out as (deposit + bonus) x multiplier, as in your example.

UPDATES

For everyone (juniors too)
1. Open the SR panel. The bottom shows your version. A red dot on the SR button means a new version is ready.
2. Double-click Update Smart Reply.bat in your Smart Reply folder. If Windows shows a blue box, click More info, then Run anyway.
3. When it says Done, click SR, then Reload now. Then press F5 on LiveChat.
4. Click What's new in the panel to read the release notes.
Your keys and settings are saved in the browser, not in the files, so an update never removes them.
If something goes wrong, the old files are in the backup folder that the updater shows (in your Temp folder).

For the owner (you)
1. One time: put smart-reply.zip and version.json on Google Drive. Share each as Anyone with the link, role Viewer. Only you may edit them. Whoever can change these two files can change what your juniors install, so never give edit rights to anyone else.
2. Make a direct link for each file: https://drive.google.com/uc?export=download&id=FILE_ID
   FILE_ID is the long text in the share link, between /d/ and /view.
3. Open update-config.json in the Smart Reply folder. Paste the link of version.json as versionUrl, and the link of smart-reply.zip as zipUrl. Save.
4. Zip your Smart Reply folder and send it to your juniors. They unzip it to their Desktop and use Load unpacked in brave://extensions, once.
5. For every new version you receive two files: smart-reply.zip and version.json. In Drive, right-click the existing file, choose Manage versions, then Upload new version. The links stay the same. Drive can take a few minutes to show the new file.
6. Juniors then see the red dot and run Update Smart Reply.bat.
The updater checks a checksum, so a damaged or changed download is refused.

GOOD TO KNOW
1. Your keys stay only in this browser. Never paste them in chats.
2. Chat text is sent to Groq to write the reply, so only use it where your company allows this.
3. If a reply is wrong, fix the sheet row, not the code.
