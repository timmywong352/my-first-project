// Smart Reply for LiveChat: background part.
// All network calls happen here (the page itself is not allowed to make them).
// Keys are read from chrome.storage.local, which is saved by the panel's
// Settings. Nothing secret is written in these files.

importScripts('receipt-ocr-broker.js','promo-parser.js','archive-core.js','hub-store.js','retrieval-core.js','withdrawal-rules.js','copilot-core.js','assist-core.js','account-core.js');

async function timedFetch(url, options = {}, timeout = 20000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try { return await fetch(url, { ...options, signal: controller.signal }); }
  catch (e) {
    if (e.name === 'AbortError') throw new Error('Request timed out after ' + timeout / 1000 + ' seconds. Please try again.');
    throw e;
  } finally { clearTimeout(timer); }
}

const LC_API = 'https://api.livechatinc.com/v3.6/agent/action/';

function authHeader(token) {
  let t = String(token || '').trim();
  // Accept either the ready Base64 token from the Developer Console,
  // or "account_id:personal_access_token" and encode it here.
  if (t.includes(':')) t = btoa(t);
  return 'Basic ' + t;
}

async function getSettings(keys) {
  return await chrome.storage.local.get(keys);
}

async function getChat(chatId) {
  const { lcToken } = await getSettings(['lcToken']);
  if (!lcToken) throw new Error('No LiveChat token. Open Settings in the panel and save it.');
  const r = await timedFetch(LC_API + 'get_chat', {
    method: 'POST',
    headers: { 'Authorization': authHeader(lcToken), 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: chatId })
  });
  if (r.status === 401 || r.status === 403) throw new Error('LiveChat rejected the token. Check it in Settings, and check it can read chats.');
  if (!r.ok) throw new Error('LiveChat answered ' + r.status + '.');
  return await r.json();
}

function latestChatMessage(data) {
  const users=new Map((data?.users||[]).map(user=>[user.id,user.type])),threads=data?.thread?[data.thread]:(data?.threads||[]),events=[];
  let order=0;
  for(const thread of threads)for(const event of thread?.events||[]){
    if(!event||!['message','file'].includes(event.type))continue;
    const at=Date.parse(event.created_at||'');
    events.push({event,order:order++,at:Number.isFinite(at)?at:null});
  }
  events.sort((a,b)=>a.at!==null&&b.at!==null?a.at-b.at:a.order-b.order);
  const event=events.at(-1)?.event;if(!event)return null;
  return {id:String(event.id||''),createdAt:String(event.created_at||''),text:event.type==='message'?String(event.text||''):'[sent a file: '+String(event.name||'attachment')+']',type:event.type,role:users.get(event.author_id)==='customer'?'customer':'agent'};
}

const copilotSendLocks=new Set(),copilotSentMemory=new Map();
async function copilotAlreadySent(chatId,key){
  if(copilotSentMemory.get(chatId)===key)return true;
  try{const saved=await chrome.storage.session.get(['srCopilotSent']);return saved.srCopilotSent?.[chatId]?.key===key;}catch(e){return false;}
}
async function markCopilotSent(chatId,key){
  copilotSentMemory.set(chatId,key);
  try{
    const saved=await chrome.storage.session.get(['srCopilotSent']),rows=saved.srCopilotSent&&typeof saved.srCopilotSent==='object'?saved.srCopilotSent:{};
    rows[chatId]={key,at:Date.now()};
    const trimmed=Object.fromEntries(Object.entries(rows).sort((a,b)=>(b[1]?.at||0)-(a[1]?.at||0)).slice(0,100));
    await chrome.storage.session.set({srCopilotSent:trimmed});
  }catch(e){/* In-memory duplicate protection remains available. */}
}
async function recheckCopilotComposer(req,sender){
  const expectedUrl=String(req.expectedUrl||'');if(!expectedUrl.startsWith('https://my.livechatinc.com/'))throw new Error('The expected LiveChat conversation is invalid. Nothing was sent.');
  const tabId=sender.tab?.url?.startsWith('https://my.livechatinc.com/')?sender.tab.id:Number(req.targetTabId);
  if(!Number.isInteger(tabId))throw new Error('The linked LiveChat tab is unavailable. Nothing was sent.');
  const tab=await chrome.tabs.get(tabId);if(tab.url!==expectedUrl)throw new Error('The selected LiveChat conversation changed. Nothing was sent.');
  const composer=await chrome.tabs.sendMessage(tabId,{action:'readComposer',expectedUrl});
  if(!composer?.ok||!composer.found||String(composer.text||'').trim()||composer.backendProtected)throw new Error('The LiveChat message box is unavailable, contains text, or is protected. Nothing was sent.');
}
async function autoSendReply(req,sender){
  const chatId=String(req.chatId||''),lang=String(req.lang||''),expectedKey=String(req.expectedMessageKey||''),source=String(req.source||''),requested=SRCopilotCore.clean(req.text);
  if(!/^[a-zA-Z0-9_-]{1,255}$/.test(chatId)||!['en','ms','zh'].includes(lang)||!expectedKey||expectedKey.length>3000)throw new Error('Invalid Copilot send request.');
  if(!['approved','current-sheet','local-clarification'].includes(source))throw new Error('Copilot may only send an exact approved answer or local clarification.');
  if(!requested||SRCopilotCore.unsafeAnswer(requested)||SRWithdrawalRules.containsBackendReply(requested))throw new Error('This reply is not eligible for automatic sending.');
  if(copilotSendLocks.has(chatId))throw new Error('A Copilot send is already running for this chat.');
  copilotSendLocks.add(chatId);
  try{
    const current=await getChat(chatId),latest=latestChatMessage(current),currentKey=SRCopilotCore.messageKey(latest);
    if(!latest||latest.type!=='message'||latest.role!=='customer'||currentKey!==expectedKey)throw new Error('The latest LiveChat message changed. Nothing was sent.');
    const sensitive=SRCopilotCore.sensitive(latest.text);if(sensitive)throw new Error(sensitive+' Nothing was sent.');
    if(await copilotAlreadySent(chatId,currentKey))throw new Error('Copilot already handled this customer message. Nothing was sent again.');
    let candidate;
    if(source==='approved'){
      const retrieval=await retrieveHub(latest.text);
      if(retrieval.manual||retrieval.conflict||retrieval.warnings.length)throw new Error('The reviewed answer could not be reverified. Nothing was sent.');
      candidate=SRCopilotCore.approvedCandidate(retrieval.approved,lang);
    }else if(source==='current-sheet'){
      const {knowledge}=await getSettings(['knowledge']);candidate=SRCopilotCore.sheetCandidate(knowledge?.entries,latest.text,lang);
    }else{
      candidate=SRCopilotCore.localCandidate(SRAssistCore.gameAccessClarification(latest.text,lang),'Game access clarification');
    }
    if(!candidate.ok||candidate.source!==source||SRCopilotCore.clean(candidate.text)!==requested)throw new Error((candidate.reason||'The approved source changed.')+' Nothing was sent.');
    await recheckCopilotComposer(req,sender);
    const {lcToken}=await getSettings(['lcToken']);if(!lcToken)throw new Error('No LiveChat token is saved.');
    const response=await timedFetch(LC_API+'send_event',{method:'POST',headers:{Authorization:authHeader(lcToken),'Content-Type':'application/json'},body:JSON.stringify({chat_id:chatId,event:{type:'message',text:requested},attach_to_last_thread:true})},12000);
    if(response.status===401||response.status===403)throw new Error('LiveChat denied automatic sending. Create a token with chats--access:rw or administrator chats--all:rw, then save it in Settings.');
    if(response.status===429)throw new Error('LiveChat rate limited the send. Nothing was retried automatically.');
    if(!response.ok)throw new Error('LiveChat did not accept the reply (HTTP '+response.status+'). Nothing was retried automatically.');
    let result={};try{result=await response.json();}catch(e){}
    await markCopilotSent(chatId,currentKey);
    return {sent:true,eventId:String(result.event_id||result.id||''),messageKey:currentKey};
  }finally{copilotSendLocks.delete(chatId);}
}


// Bounded, read-only history for the selected chat only. Never stored or sent to AI.
async function getUsernameHistory(chatId) {
  if(typeof chatId!=='string'||!/^[a-zA-Z0-9_-]{1,255}$/.test(chatId))throw new Error('Invalid chat ID.');
  const current=await getChat(chatId);
  const {lcToken}=await getSettings(['lcToken']);
  const threads=new Map();
  if(current.thread?.id)threads.set(current.thread.id,current.thread);
  let pageId='',complete=false,warning='',pages=0;
  const cursors=new Set();
  for(let page=0;page<3;page++){
    try{
      const payload=pageId?{chat_id:chatId,page_id:pageId}:{chat_id:chatId,limit:100,sort_order:'desc'};
      const response=await timedFetch(LC_API+'list_threads',{method:'POST',headers:{Authorization:authHeader(lcToken),'Content-Type':'application/json'},body:JSON.stringify(payload)},15000);
      if(!response.ok)throw new Error(response.status===401||response.status===403?'LiveChat denied history access.':response.status===429?'LiveChat history rate limit reached.':'History request returned HTTP '+response.status+'.');
      const data=await response.json();
      if(!Array.isArray(data.threads)||data.threads.some(t=>!t||typeof t.id!=='string'||!Array.isArray(t.events)))throw new Error('Unexpected history response.');
      pages++;
      for(const thread of data.threads)if(!threads.has(thread.id))threads.set(thread.id,thread);
      if(!data.next_page_id){complete=true;break;}
      if(typeof data.next_page_id!=='string'||data.next_page_id.length>10000||cursors.has(data.next_page_id))throw new Error('History cursor was invalid or repeated.');
      pageId=data.next_page_id;cursors.add(pageId);
    }catch(e){warning=e.message;break;}
  }
  if(!complete&&!warning)warning='History limited to 300 listed threads. Older threads may remain.';
  return {users:current.users||[],threads:[...threads.values()].sort((a,b)=>String(a.created_at||'').localeCompare(String(b.created_at||''))),history:{pages,complete,warning,threads:threads.size}};
}

// The archive page requests one bounded read-only page at a time.
async function archivePage(req) {
  const {lcToken} = await getSettings(['lcToken']);
  if (!lcToken) throw new Error('No LiveChat token saved. Open Smart Reply Settings on LiveChat and save it first.');
  let body = {limit:100};
  if (req.pageId) {
    if (typeof req.pageId !== 'string' || req.pageId.length > 10000) throw new Error('Invalid archive page cursor.');
    body = {page_id:req.pageId};
  } else {
    const filters=req.filters || {};
    const valid=v=>typeof v==='string' && /^\d{4}-\d{2}-\d{2}T/.test(v) && !Number.isNaN(Date.parse(v));
    if (!valid(filters.to) || (filters.from && !valid(filters.from)) || (filters.from && Date.parse(filters.from)>Date.parse(filters.to))) throw new Error('Invalid archive date range.');
    body.filters={to:filters.to,...(filters.from?{from:filters.from}:{})};
    body.sort_order='asc';
  }
  const response=await timedFetch(LC_API+'list_archives',{method:'POST',headers:{Authorization:authHeader(lcToken),'Content-Type':'application/json'},body:JSON.stringify(body)},30000);
  if(response.status===401||response.status===403)throw new Error('LiveChat denied archive access. Check the saved token and chats--access:ro or administrator chats--all:ro scope.');
  if(response.status===429)throw new Error('LiveChat rate limit reached. Wait at least '+(response.headers.get('Retry-After')||'60')+' seconds, then Resume / retry.');
  if(!response.ok)throw await archiveRequestError(response,'LiveChat archive request');
  return await response.json();
}

// Only fixed diagnostic labels leave this function; never echo API text or data.
async function archiveRequestError(response, label) {
  let error={};
  try { const body=await response.json();error=body&&body.error||{}; } catch(e) {}
  const types=['validation','authentication','authorization','misdirected_request','unsupported_version','wrong_product_version','license_expired','license_not_found','internal','request_timeout','service_unavailable','too_many_requests'];
  const type=types.includes(error.type)?error.type:'unrecognized';
  const message=typeof error.message==='string'?error.message.slice(0,4000):'';
  const fields=['filters.query','filters.from','filters.to','page_id','sort_order','limit'].filter(field=>message.includes(field));
  const reasons=[];
  if(/too short|minimum.{0,25}(?:length|characters)|at least.{0,25}characters/i.test(message))reasons.push('minimum text length');
  if(/too long|maximum.{0,25}(?:length|characters)/i.test(message))reasons.push('maximum text length');
  if(/invalid.{0,20}(?:query|syntax)|(?:query|syntax).{0,20}invalid/i.test(message))reasons.push('query syntax');
  if(/not allowed|cannot.{0,30}(?:combine|together)|mutually exclusive/i.test(message))reasons.push('unsupported field or combination');
  if(/required|missing/i.test(message))reasons.push('required value');
  if(/region/i.test(message))reasons.push('region');
  return new Error(label+' returned HTTP '+response.status+'. API category: '+type+'.'+(fields.length?' Mentioned fields: '+fields.join(', ')+'.':'')+(reasons.length?' Message clues: '+reasons.join(', ')+'.':'')+' Lookup failed; this does not mean no matching chats exist. Share this diagnostic with support; do not share your API key.');
}

async function searchArchivePolicies(query) {
  const {lcToken}=await getSettings(['lcToken']);
  if(!lcToken)throw new Error('Archive search needs the saved LiveChat token.');
  const baseQuery=RetrievalCore.searchQuery(query);
  const filters={query:baseQuery==='rebate'?'daily rebates':baseQuery};
  if(!filters.query)return {records:[],policies:[]};
  let pageId,records=[],policies=[];
  for(let page=0;page<2;page++){
    const payload=pageId?{page_id:pageId}:{filters,sort_order:'desc',limit:30};
    const response=await timedFetch(LC_API+'list_archives',{method:'POST',headers:{Authorization:authHeader(lcToken),'Content-Type':'application/json'},body:JSON.stringify(payload)},12000);
    if(response.status===401||response.status===403)throw new Error('LiveChat denied archive search. Check archive read permissions.');
    if(response.status===429)throw new Error('Archive search rate limited; retry later.');
    if(!response.ok)throw await archiveRequestError(response,'Archive search');
    const data=await response.json();
    if(!Array.isArray(data.chats))throw new Error('Unexpected archive search response.');
    for(const chat of data.chats){const record=ArchiveCore.prepareChat(chat,'');if(!record)continue;const found=RetrievalCore.candidates(record,query);if(found.length){records.push(record);policies.push(...found);}}
    policies=RetrievalCore.dedupe(policies);
    if(policies.length>=4)break;
    if(!policies.length && filters.query!==baseQuery){filters.query=baseQuery;pageId=null;continue;}
    if(!data.next_page_id)break;
    pageId=data.next_page_id;
  }
  return {records,policies};
}

async function retrieveHub(query) {
  if(typeof query!=='string'||!query.trim()||query.length>2000)throw new Error('Invalid knowledge query.');
  const manual=RetrievalCore.accountQuestion(query), warnings=[];
  let db,approved=[],policies=[];
  try {
    db=await HubStore.open();
    approved=RetrievalCore.approved(await HubStore.read(db,'knowledge'),query);
    if(!approved.length&&!manual){
      policies=await new Promise((resolve,reject)=>{
        const matches=[],tx=db.transaction('threads'),request=tx.objectStore('threads').openCursor();
        request.onsuccess=()=>{const cursor=request.result;if(!cursor){resolve(RetrievalCore.dedupe(matches));return;}matches.push(...RetrievalCore.candidates(cursor.value,query));if(matches.length>100)matches.splice(0,matches.length,...RetrievalCore.dedupe(matches));cursor.continue();};request.onerror=()=>reject(request.error);
      });
    }
  }catch(e){warnings.push('Local Hub: '+e.message);}
  const {searchArchives}=await getSettings(['searchArchives']);
  if(!manual&&!approved.length&&searchArchives!==false){
    try{const remote=await searchArchivePolicies(query);policies=RetrievalCore.dedupe([...policies,...remote.policies]);if(db&&remote.records.length)await HubStore.write(db,{threads:remote.records});}
    catch(e){warnings.push(e.message);}
  }
  if(db)db.close();
  const conflict=RetrievalCore.conflict(approved.length?approved.map(e=>({text:e.en||e.ms||e.zh})):policies,query);
  return {approved,historical:conflict?[]:RetrievalCore.historyRows(policies),conflict,manual,warnings};
}

function validBackendURL(url) {
  try{return new URL(url).origin==='https://mcd88.kg8.co';}catch(e){return false;}
}
async function waitForTabReady(tabId,timeout=15000){
  const deadline=Date.now()+timeout;
  while(Date.now()<deadline){
    const tab=await chrome.tabs.get(tabId);
    if(tab.status==='complete')return;
    await new Promise(resolve=>setTimeout(resolve,250));
  }
  throw new Error('A backend report tab is still loading. Wait a moment, then check the username again.');
}
async function readWithdrawalReport(tabId) {
  if(!Number.isInteger(tabId))throw new Error('Choose the backend tab first.');
  const tab=await chrome.tabs.get(tabId);
  if(!validBackendURL(tab.url))throw new Error('The selected tab is not the authorized backend.');
  const results=await chrome.scripting.executeScript({target:{tabId,allFrames:true},files:['withdrawal-rules.js','withdrawal-reader.js']});
  const reports=results.map(item=>item.result).filter(result=>result&&!result.notReport&&!result.error);
  if(!reports.length)throw new Error('Open the withdrawal report in that tab, log in yourself, and submit your report search before reading it.');
  if(reports.length!==1)throw new Error('Several report frames are open. Open the intended report in a separate tab first.');
  return {...reports[0],tabId};
}

async function searchWithdrawalReport(req) {
  if(!Number.isInteger(req.tabId)||typeof req.member!=='string'||!/^[a-zA-Z0-9_.-]{1,255}$/.test(req.member))throw new Error('Choose a backend tab and an exact member username.');
  const tab=await chrome.tabs.get(req.tabId);if(!validBackendURL(tab.url))throw new Error('Only the authorized backend can be searched.');
  const dates=SRWithdrawalRules.searchRange(Number(req.days));
  await chrome.scripting.executeScript({target:{tabId:req.tabId,allFrames:true},files:['withdrawal-search.js']});
  const inspected=await chrome.scripting.executeScript({target:{tabId:req.tabId,allFrames:true},func:()=>globalThis.SRWithdrawalSearch?.inspect()||{ready:false}});
  const ready=inspected.filter(item=>item.result?.ready);
  if(ready.length!==1)throw new Error(ready.length?'Several report frames are open. Open one report tab.':inspected.map(item=>item.result?.error).filter(Boolean).join(' ')||'Open the report and log in yourself first.');
  const target={tabId:req.tabId,frameIds:[ready[0].frameId]};
  const [submitted]=await chrome.scripting.executeScript({target,func:args=>globalThis.SRWithdrawalSearch.run(args),args:[{member:req.member,...dates}]});
  if(!submitted?.result?.scheduled)throw new Error(submitted?.result?.error||'The report search could not start.');
  const previous=submitted.result.documentId,deadline=Date.now()+25000;let lastError='';
  while(Date.now()<deadline){
    await new Promise(resolve=>setTimeout(resolve,500));
    try{const current=await readWithdrawalReport(req.tabId);if(current.documentId&&current.documentId!==previous)return {...current,searchedMember:req.member,searchedRange:dates};}
    catch(e){lastError=e.message;}
  }
  throw new Error('Could not verify a fresh report after submitting the search. Use manual search/read; the page may update without navigation or need a different form mapping. '+lastError);
}

// Account reports remain transient; only the existing public promo refresh uses storage/network.
async function accountReport(req) {
  const path=SRAccountCore.paths[req.kind];if(!path||!Number.isInteger(req.tabId)||!/^[a-zA-Z0-9_.-]{1,255}$/.test(req.member||''))throw new Error('Choose an exact account-report tab and member.');
  const tab=await chrome.tabs.get(req.tabId);let url;try{url=new URL(tab.url);}catch(e){throw new Error('Report tab unavailable.');}
  if(url.origin!=='https://mcd88.kg8.co'||url.pathname!==path)throw new Error('Selected tab does not match this allowed report path.');
  const files=['withdrawal-rules.js','account-core.js','account-search.js','account-reader.js'];
  const read=async()=>{
    const result=await chrome.scripting.executeScript({target:{tabId:req.tabId,allFrames:true},files});
    const reports=result.map(item=>item.result).filter(r=>r&&!r.notReport&&!r.error&&r.kind===req.kind);
    if(reports.length!==1)throw new Error('One readable report frame was not found. Log in yourself and verify the page headers.');
    if(reports[0].member!==SRAccountCore.who(req.member))throw new Error('The report member field does not match the requested username, or its label is not verified.');
    if(req.kind!=='turnover'&&reports[0].currency!=='MYR')throw new Error('Choose MYR currency on the report before reading.');
    return {...reports[0],tabId:req.tabId};
  };
  if(!req.search)return {...await read(),manual:true};
  await chrome.scripting.executeScript({target:{tabId:req.tabId,allFrames:true},files:['account-core.js','account-search.js']});
  const inspected=await chrome.scripting.executeScript({target:{tabId:req.tabId,allFrames:true},func:()=>globalThis.SRAccountSearch?.inspect()||{ready:false}});
  const ready=inspected.filter(item=>item.result?.ready);
  if(ready.length!==1)throw new Error(inspected.map(item=>item.result?.error).filter(Boolean).join(' ')||'No unique safe search form. Use manual search/read.');
  const target={tabId:req.tabId,frameIds:[ready[0].frameId]},dates=SRWithdrawalRules.searchRange(Number(req.days));
  const [started]=await chrome.scripting.executeScript({target,func:args=>globalThis.SRAccountSearch.run(args),args:[{member:req.member,...dates}]});
  if(!started?.result?.scheduled)throw new Error(started?.result?.error||'Search could not start.');
  const deadline=Date.now()+25000;let last='';
  while(Date.now()<deadline){await new Promise(resolve=>setTimeout(resolve,500));try{const report=await read();if(report.documentId&&report.documentId!==started.result.documentId)return {...report,searchedRange:dates};}catch(e){last=e.message;}}
  throw new Error('Fresh report navigation was not verified. Search manually and use Read loaded reports. '+last);
}

async function askGroq({ system, user, models }) {
  const { groqKey } = await getSettings(['groqKey']);
  if (!groqKey) throw new Error('No Groq key. Open Settings in the panel and save it.');
  const list = (models && models.length ? models : ['openai/gpt-oss-120b', 'openai/gpt-oss-20b']);
  const errors = [];
  for (const model of list) {
    let r;
    try {
      r = await timedFetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + groqKey, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model,
          temperature: 0.2,
          max_tokens: 1200,
          messages: [{ role: 'system', content: system }, { role: 'user', content: user }]
        })
      });
    } catch (e) { errors.push(model + ': could not connect'); continue; }
    if (r.status === 401 || r.status === 403) throw new Error('Groq rejected the key. Check it in Settings.');
    if (!r.ok) { errors.push(model + ': ' + r.status); continue; }   // busy, limit or unknown model: try the next
    const j = await r.json();
    const text = j && j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content;
    if (text && text.trim()) return { text: text.trim(), model };
    errors.push(model + ': empty reply');
  }
  throw new Error('Groq did not answer. ' + errors.join('  |  '));
}

async function fetchSheet(link) {
  const m = String(link || '').match(/\/spreadsheets\/d\/([a-zA-Z0-9_-]{20,})/);
  if (!m) throw new Error('The Google Sheet link is not valid.');
  const gid = (String(link).match(/[#&?]gid=(\d+)/) || [])[1] || '0';
  const base = 'https://docs.google.com/spreadsheets/d/' + m[1];
  const urls = [base + '/export?format=csv&gid=' + gid + '&t=' + Date.now(),
    base + '/gviz/tq?tqx=out:csv&gid=' + gid];
  const errors = [];
  for (const url of urls) {
    try {
      const r = await timedFetch(url, { cache: 'no-store', credentials: 'omit' }, 12000);
      if (!r.ok) throw new Error('Google answered ' + r.status);
      const text = await r.text();
      if (!text.trim() || /<html|<!doctype/i.test(text.slice(0, 500))) throw new Error('Google returned a sign-in or error page');
      return text;
    } catch (e) { errors.push(e.message || 'Network request failed'); }
  }
  throw new Error('Knowledge sheet could not load. Check its link, tab and Viewer sharing, or whether the browser blocks Google downloads. ' + errors.join(' | '));
}


// Download the whole promo workbook (every tab) and keep it for the panel.
async function fetchPromos(link) {
  const m = String(link || '').match(/\/spreadsheets\/d\/([a-zA-Z0-9_-]{20,})/);
  if (!m) throw new Error('The promo sheet link is not valid.');
  const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 30000);
  let buf;
  try {
    const r = await fetch('https://docs.google.com/spreadsheets/d/' + m[1] + '/export?format=xlsx&t=' + Date.now(), { cache: 'no-store', credentials: 'omit', signal: ctl.signal });
    if (!r.ok) throw new Error(r.status === 404 ? 'Promo sheet not found. Check the link.' : 'Google answered ' + r.status + '. Share the promo sheet as Anyone with the link, Viewer.');
    buf = await r.arrayBuffer();
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('Google Sheets took too long to answer.');
    if (e instanceof TypeError) throw new Error('Could not reach Google Sheets. Check the internet connection.');
    throw e;
  } finally { clearTimeout(timer); }
  const head = new Uint8Array(buf.slice(0, 2));
  if (head[0] !== 0x50 || head[1] !== 0x4B) throw new Error('Could not read the promo sheet. Share it as Anyone with the link, Viewer.');
  const data = await PromoParser.parseWorkbook(buf);
  if (!data.promos.length) throw new Error('No promos found. Each tab needs a header row with ENG, MALAY and CHINESE.');
  await chrome.storage.local.set({ promos: { fetchedAt: Date.now(), tabs: data.tabs, list: data.promos } });
  return { count: data.promos.length, tabs: data.tabs.length };
}


// ── Updates: compare the loaded version, the version on disk and the published version ──
async function readJson(url) {
  const r = await timedFetch(url, { cache: 'no-store', credentials: 'omit' });
  if (!r.ok) throw new Error('answered ' + r.status);
  const t = (await r.text()).replace(/^\uFEFF/, '');
  try { return JSON.parse(t); } catch (e) { throw new Error('is not a valid version file'); }
}
async function updateInfo() {
  const loaded = chrome.runtime.getManifest().version;
  let disk = loaded, cfg = {}, notes = {};
  try { disk = (await readJson(chrome.runtime.getURL('manifest.json'))).version || loaded; } catch (e) {}
  try { cfg = await readJson(chrome.runtime.getURL('update-config.json')); } catch (e) {}
  try { notes = await readJson(chrome.runtime.getURL('release-notes.json')); } catch (e) {}
  let remote = null, remoteError = '';
  if (cfg.versionUrl) {
    try { remote = await readJson(cfg.versionUrl + (cfg.versionUrl.includes('?') ? '&' : '?') + 't=' + Date.now()); }
    catch (e) { remoteError = 'Could not check for updates (' + e.message + ').'; }
  } else remoteError = 'No update link is set. Ask the owner of the extension.';
  return { loaded, disk, remote, remoteError, notes, zipUrl: cfg.zipUrl || '' };
}

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if(['receiptOCR','receiptOCRClaim','receiptOCRResult','receiptOCRCancel'].includes(req?.action))return false;
  if (!sender || sender.id !== chrome.runtime.id) return false;
  (async () => {
    try {
      let data;
      if (req.action === 'openArchives') {
        await chrome.tabs.create({url:chrome.runtime.getURL('archives.html')+(req.chatId&&req.threadId?'?chatId='+encodeURIComponent(req.chatId)+'&threadId='+encodeURIComponent(req.threadId):'')});
        data=true;
      }
      else if (req.action === 'archivePage') {
        if (!sender.url || new URL(sender.url).pathname !== '/archives.html' || !sender.url.startsWith(chrome.runtime.getURL(''))) throw new Error('Open Archive Insights from Smart Reply.');
        data=await archivePage(req);
      }
      else if (req.action === 'popout') {
        if (!sender.tab || !sender.tab.url.startsWith('https://my.livechatinc.com/')) throw new Error('Open Pop out from LiveChat.');
        await chrome.windows.create({ type: 'popup', width: 410, height: 740,
          url: chrome.runtime.getURL('detached.html') + '?tabId=' + sender.tab.id + '&chatUrl=' + encodeURIComponent(sender.tab.url) });
        data = true;
      }
      else if (req.action === 'windowContext' || req.action === 'insertDraft' || req.action === 'readDraft') {
        if (!sender.url || !sender.url.startsWith(chrome.runtime.getURL('detached.html'))) throw new Error('Invalid popup request.');
        const tab = await chrome.tabs.get(req.tabId);
        if (!tab.url || !tab.url.startsWith('https://my.livechatinc.com/')) throw new Error('Linked LiveChat tab is unavailable.');
        if (req.action === 'windowContext') data = { url: tab.url };
        else {
          if (tab.url !== req.expectedUrl) throw new Error('The chat changed. Generate a new draft.');
          const result = await chrome.tabs.sendMessage(req.tabId, { action: req.action==='readDraft'?'readComposer':'insertComposer', text: req.text, expectedText:req.expectedText, backendProtected:!!req.backendProtected, expectedUrl: req.expectedUrl });
          if(req.action==='readDraft'){if(!result || !result.ok)throw new Error('Could not read the linked LiveChat draft.');data={found:!!result.found,text:result.text||'',backendProtected:!!result.backendProtected};}
          else data = !!(result && result.ok);
        }
      }
      else if(req.action==='accountTabs'||req.action==='openAccountReports') {
        const tabs=await chrome.tabs.query({url:'https://mcd88.kg8.co/*'}),found=[],created=[];
        const allowedKinds=Object.keys(SRAccountCore.paths),openKinds=Array.isArray(req.kinds)?[...new Set(req.kinds)].filter(kind=>allowedKinds.includes(kind)):allowedKinds;
        if(Array.isArray(req.kinds)&&openKinds.length!==req.kinds.length)throw new Error('Invalid account report selection.');
        for(const [kind,path] of Object.entries(SRAccountCore.paths)){
          const matches=tabs.filter(tab=>{try{const u=new URL(tab.url);return u.origin==='https://mcd88.kg8.co'&&u.pathname===path;}catch(e){return false;}});
          if(req.action==='openAccountReports'&&openKinds.includes(kind)&&!matches.length){const tab=await chrome.tabs.create({url:'https://mcd88.kg8.co'+path,active:false});matches.push(tab);created.push(tab.id);}
          for(const tab of matches)found.push({kind,id:tab.id,title:tab.title||kind});
        }
        if(created.length)await Promise.all(created.map(tabId=>waitForTabReady(tabId)));
        data=found;
      }
      else if(req.action==='accountReport')data=await accountReport(req);
      else if(req.action==='withdrawalTabs') {
        const tabs=await chrome.tabs.query({url:'https://mcd88.kg8.co/*'});
        data=tabs.filter(tab=>validBackendURL(tab.url)).map(tab=>({id:tab.id,title:tab.title||'Backend',path:new URL(tab.url).pathname}));
      }
      else if(req.action==='searchWithdrawalReport')data=await searchWithdrawalReport(req);
      else if(req.action==='readWithdrawalReport')data=await readWithdrawalReport(req.tabId);
      else if (req.action === 'retrieveHub') data=await retrieveHub(req.query);
      else if (req.action === 'usernameHistory') data = await getUsernameHistory(req.chatId);
      else if (req.action === 'getChat') data = await getChat(req.chatId);
      else if (req.action === 'autoSendReply') {
        const live=sender.tab?.url?.startsWith('https://my.livechatinc.com/'),popup=sender.url?.startsWith(chrome.runtime.getURL('detached.html'));
        if(!live&&!popup)throw new Error('Copilot sends are allowed only from an open LiveChat workspace.');
        data=await autoSendReply(req,sender);
      }
      else if (req.action === 'credentialStatus') { const saved=await getSettings(['lcToken','groqKey']);data={hasLiveChatToken:!!saved.lcToken,hasGroqKey:!!saved.groqKey}; }
      else if (req.action === 'groq') data = await askGroq(req);
      else if (req.action === 'sheet') data = await fetchSheet(req.link);
      else if (req.action === 'promos') data = await fetchPromos(req.link);
      else if (req.action === 'updateInfo') data = await updateInfo();
      else if (req.action === 'reload') { sendResponse({ ok: true, data: true }); setTimeout(() => chrome.runtime.reload(), 200); return; }
      else throw new Error('Unknown action');
      sendResponse({ ok: true, data });
    } catch (e) {
      sendResponse({ ok: false, error: (e && e.message) || 'Something went wrong.' });
    }
  })();
  return true;
});
