SMART REPLY FOR LIVECHAT  (your own extension, separate from your colleague's)

WHAT IT DOES
1. Reads the open LiveChat conversation.
2. Picks the matching rows from your knowledge sheet.
3. Writes the reply in the customer's language and puts it in the message box.
4. Manual tools create drafts that you check and send yourself.
5. Optional Live Copilot watches new common questions and puts an editable expected reply directly in the empty LiveChat message box. You check it and press Enter yourself; Copilot never sends.

SET UP (about 15 minutes, one time)

Step 1. Install the extension
1. Unzip this folder to your Desktop and name the folder Smart Reply.
2. Open brave://extensions and turn on Developer mode.
3. Click Load unpacked and choose the Smart Reply folder.

Step 2. Make your knowledge sheet
1. Open Google Drive and upload knowledge-starter.csv.
2. Right-click it, choose Open with, then Google Sheets.
3. Click Share, choose Anyone with the link, role Viewer, and copy the link.
Add a new row whenever you meet a question the sheet does not cover. The more rows, the better the replies.
Columns: TOPIC, KEYWORDS (words the customer may type, in any language, separated by commas), ENGLISH, MALAY, CHINESE, NOTES (when to use the row).
Keep the row named RULES. It is always sent to the AI.

Step 3. Get your keys (keep them private)
1. LiveChat: Developer Console, Settings, Authorization, Personal Access Tokens. Create a token that can read chats, then copy the Base64 encoded token. Copilot does not need write access because it never sends.
2. Groq: create a free key at console.groq.com.

Step 3b. Your promo sheet (the one with PROMO CODE, ENG, MALAY, CHINESE)
1. Open your promo Google Sheet and click Share.
2. Choose Anyone with the link, role Viewer, and copy the link.
3. Do not change the sheet. The extension reads every tab by itself (hidden tabs are skipped).
It finds the header row with ENG, MALAY and CHINESE on each tab. The first column is the promo code or name.

Step 4. Save them in the extension
1. Open LiveChat and press F5. A green message appears at the top, and a blue SR button appears at the bottom left.
2. Click SR, then Settings. Paste the LiveChat token, the Groq key, the knowledge sheet link, and the promo sheet link. Click Save, then Back.
3. Click Refresh knowledge and Refresh promos. They show the number of rows and promos.

HOW TO USE
1. For a common question, open the Reply tab and click Create customer reply (or press Alt and R).
2. Read the draft in the message box, correct it if needed, then press Send yourself.
3. If facts or an account status need checking, open Ask an operator. Click Prepare operator question, review it, then click Copy for WeChat.
4. You can switch to another LiveChat conversation while waiting. The unfinished operator handoff is kept for that chat until the page is refreshed.
5. When the operator replies, return to the customer chat and paste the confirmed answer in Step 2.
6. Choose the customer language and click Prepare customer reply. Review the draft before using it in LiveChat.
7. If the operator says the check is still pending, tick that box so the reply does not imply completion or approval.

LIVE COPILOT (OPTIONAL AUTO-DRAFT)
1. Open Reply > Live Copilot and click Turn Copilot on.
2. Copilot immediately handles the latest customer message, then watches for new customer messages every five seconds. Draft latest message now lets you intentionally retry the current message.
3. For a safe common question, it uses the same approved knowledge, current promotion rules, local clarification and reviewed AI route as Create customer reply. If no reviewed answer matches, it searches every conversation already stored in the Knowledge Hub regardless of category and compares both the old customer question and agent answer.
4. The expected reply is inserted directly into the empty LiveChat message box. Check or edit it, then press Enter yourself. Copilot never presses Enter, clicks Send, or calls the LiveChat send API.
5. Existing LiveChat text and existing panel drafts are never overwritten. Clear or send the current draft before another one can be prepared.
6. General deposit, withdrawal, promotion and rebate questions may use a reusable archived answer. Customer-specific status, balance, amount, failure, missing-payment, credential, backend-protected, conflicting, ambiguous or operator-only enquiries stop for manual checking.
7. Copilot turns off when the selected LiveChat conversation changes or the page reloads. Turn it on separately for the intended chat.
8. Knowledge Hub categories organize conversations but never limit the global local search. Retrieve or import the required archive range in Knowledge Hub first; on-demand LiveChat archive lookup remains a bounded keyword fallback to avoid slow replies and API rate limits.

ACCOUNT QUICK CHECK
1. Open Account and enter the exact backend username, or choose one found from the current chat.
2. Choose Today, Last 7 days, or Last 30 days, then click Check this username.
3. The extension opens or finds five read-only backend tabs and searches them: member balance, deposit report, promotion report, withdrawal turnover, and withdrawal report.
4. The Turnover duration start is shown as the latest-deposit time. Providers above 0.000 are listed with their three-decimal turnover amount.
5. Deposit cross-check compares that Turnover amount/time with the unique latest confirmed successful MYR deposit. Reports that differ are marked REPORTS DIFFER — RECHECK; a newer pending deposit is reported separately.
6. Review the current balance, latest deposit, provider play, latest promotion and turnover status, and latest withdrawal status. "Latest" means the unique latest row inside the selected loaded period; pagination and missing records remain clearly marked Not verified.
7. Promotion badges distinguish active, carried into a new deposit, finished, conflicting, same-time and unknown states. Any other Unfinished row blocks a cleared interpretation.
8. When an exact supported result is verified, Customer reply prepares the full sentence in the detected English, Malay or Chinese language. Supported results are the exact daily withdrawal-limit marker, Payment closed, Processing, an explicit positive turnover shortfall, or the tightly verified SPOTUN10 remaining amount. A newer pending deposit blocks a calculated turnover reply.
9. If the withdrawal time is older than 24 hours or its timezone/age cannot be verified, first confirm that the displayed reference and requested time are the transaction the customer means. Then choose Verified account result, Kindly wait a moment, or Polite closing. You can optionally add the polite closing after a verified result, edit the sentence, then use Copy full reply or Use in LiveChat.
10. Copy operator summary, Copy full reply, and Use in LiveChat recheck every successful report and the selected chat. Changed/reloaded reports, changed auto-language input, or results over five minutes old are rejected or refreshed for review.
11. Use in LiveChat only fills an empty message box as a draft. It never presses Send and never overwrites existing Draft or composer text. Unknown, ambiguous, paginated, negative and unsupported statuses remain operator-only.
12. Backend data is not sent to AI. Detailed calculations and manual fallback remain under Advanced turnover & manual tools.

PROMOS
1. When a customer types a promo code or name that is in your promo sheet, Auto reply puts the exact promo text in the message box, in the customer's language. Nothing is rewritten.
2. If the customer asks a question about the promo, the AI gets the real promo text and answers from it.
3. Find promo: type a few letters of a code or name, click the result, and the text goes in the message box.
4. Calculate: type for example deposit RM50 claim 100PPU, then click Calculate. The deposit, bonus, total balance and turnover for each game type are worked out from the numbers in the promo text (percentage, Min Deposit, Max Bonus, and lines like Webslot x5). Check the numbers before you send.
5. The calculator works only when the promo text has a percentage bonus. Fixed bonuses such as RM60 get RM8 are not calculated.
6. Turnover is worked out as (deposit + bonus) x multiplier, as in your example.

UPDATES

For everyone (juniors too)
1. Open the SR panel. The bottom shows your version. A red dot on the SR button means a new version is ready.
2. Double-click Update Smart Reply.bat in your Smart Reply folder. If Windows shows a blue box, click More info, then Run anyway.
3. When it says Done, click SR, then Reload now. Then press F5 on LiveChat.
4. Click What's new in the panel to read the release notes.
Your keys and settings are saved in the browser, not in the files, so an update never removes them.
If something goes wrong, the old files are in the backup folder that the updater shows (in your Temp folder).

For the owner (you)
1. One time: put smart-reply.zip and version.json on Google Drive. Share each as Anyone with the link, role Viewer. Only you may edit them. Whoever can change these two files can change what your juniors install, so never give edit rights to anyone else.
2. Make a direct link for each file: https://drive.google.com/uc?export=download&id=FILE_ID
   FILE_ID is the long text in the share link, between /d/ and /view.
3. Open update-config.json in the Smart Reply folder. Paste the link of version.json as versionUrl, and the link of smart-reply.zip as zipUrl. Save.
4. Zip your Smart Reply folder and send it to your juniors. They unzip it to their Desktop and use Load unpacked in brave://extensions, once.
5. For every new version you receive two files: smart-reply.zip and version.json. In Drive, right-click the existing file, choose Manage versions, then Upload new version. The links stay the same. Drive can take a few minutes to show the new file.
6. Juniors then see the red dot and run Update Smart Reply.bat.
The updater checks a checksum, so a damaged or changed download is refused.

GOOD TO KNOW
1. Your keys stay only in this browser. Never paste them in chats.
2. AI drafting sends chat text to Groq, so only use it where your company allows this. Live Copilot uses the same drafting route as Create customer reply and never sends the resulting LiveChat message itself.
3. If a reply is wrong, fix the sheet row, not the code.
