SMART REPLY FOR LIVECHAT  (your own extension, separate from your colleague's)

WHAT IT DOES
1. Reads the open LiveChat conversation.
2. Picks the matching rows from your knowledge sheet.
3. Writes the reply in the customer's language and puts it in the message box.
4. Manual tools create drafts that you check and send yourself.
5. Optional Live Copilot watches new common questions and puts an editable expected reply directly in the empty LiveChat message box. You check it and press Enter yourself; Copilot never sends.
6. If a normal match fails, the saved Groq key can expand the question into multilingual search terms and search the full local archive again.
7. Missing safe general questions go to a local Learning queue. You can explicitly approve a checked reusable draft into reviewed Knowledge Hub memory.
8. The interface uses comfortable, readable text throughout the main panel and Quick Check while retaining its compact narrow-screen layout.
9. A strictly verified Quick Check recommends a complete Deposit, Promotion, or Withdrawal sentence in the selected or detected language. You still review and send it yourself.
10. Click the highlighted Quick Check result, or focus it and press Enter or Space, to place its prepared reply into an empty LiveChat message box. Nothing is sent automatically.
11. Withdrawal Quick Check understands the approved backend remarks and prepares the matching English, Malay, or Chinese action for the customer without guessing unknown or conflicting remarks.
12. Every approved withdrawal outcome can prepare its mapped English, Malay, or Chinese sentence even when the page shows pagination, but only for one matching valid Today row. This covers Payment closed, an explicit turnover amount, Please submit bank, Holder not same, get full name, and belum main fs; the pagination warning stays visible.
13. A Withdrawal check also prepares cached Deposit and Promotion views for the same chat. Switching those buttons does not repeat the backend search.

SET UP (about 15 minutes, one time)

Step 1. Install the extension
1. Unzip this folder to your Desktop and name the folder Smart Reply.
2. Open brave://extensions and turn on Developer mode.
3. Click Load unpacked and choose the Smart Reply folder.

Step 2. Make your knowledge sheet
1. Open Google Drive and upload knowledge-starter.csv.
2. Right-click it, choose Open with, then Google Sheets.
3. Click Share, choose Anyone with the link, role Viewer, and copy the link.
Add a new row whenever you meet a question the sheet does not cover. The more rows, the better the replies.
Columns: TOPIC, KEYWORDS (words the customer may type, in any language, separated by commas), ENGLISH, MALAY, CHINESE, NOTES (when to use the row).
Keep the row named RULES. It is always sent to the AI.

Step 3. Get your keys (keep them private)
1. LiveChat: Developer Console, Settings, Authorization, Personal Access Tokens. Create a token that can read chats, then copy the Base64 encoded token. Copilot does not need write access because it never sends.
2. Groq: create a free key at console.groq.com.

Step 3b. Your promo sheet (the one with PROMO CODE, ENG, MALAY, CHINESE)
1. Open your promo Google Sheet and click Share.
2. Choose Anyone with the link, role Viewer, and copy the link.
3. Do not change the sheet. The extension reads every tab by itself (hidden tabs are skipped).
It finds the header row with ENG, MALAY and CHINESE on each tab. The first column is the promo code or name.

Step 4. Save them in the extension
1. Open LiveChat and press F5. A green message appears at the top, and a blue SR button appears at the bottom left.
2. Click SR, then Settings. Paste the LiveChat token, the Groq key, the knowledge sheet link, and the promo sheet link. Click Save, then Back.
3. Click Refresh knowledge and Refresh promos. They show the number of rows and promos.

HOW TO USE
1. For a common question, open the Reply tab and click Create customer reply (or press Alt and R).
2. Read the draft in the message box, correct it if needed, then press Send yourself.
3. If facts or an account status need checking, open Ask an operator. Click Prepare operator question, review it, then click Copy for WeChat.
4. You can switch to another LiveChat conversation while waiting. The unfinished operator handoff is kept for that chat until the page is refreshed.
5. When the operator replies, return to the customer chat and paste the confirmed answer in Step 2.
6. Choose the customer language and click Prepare customer reply. Review the draft before using it in LiveChat.
7. If the operator says the check is still pending, tick that box so the reply does not imply completion or approval.

LIVE COPILOT (OPTIONAL AUTO-DRAFT)
1. Open Reply > Live Copilot and click Turn Copilot on.
2. Copilot immediately handles the latest customer message, then watches for new customer messages every five seconds. Draft latest message now lets you intentionally retry the current message.
3. For a safe common question, it uses the same approved knowledge, current promotion rules, local clarification and reviewed AI route as Create customer reply. If no reviewed answer matches, it searches every conversation already stored in the Knowledge Hub regardless of category and compares both the old customer question and agent answer.
4. The expected reply is inserted directly into the empty LiveChat message box. Check or edit it, then press Enter yourself. Copilot never presses Enter, clicks Send, or calls the LiveChat send API.
5. Existing LiveChat text and existing panel drafts are never overwritten. Clear or send the current draft before another one can be prepared.
6. General deposit, withdrawal, promotion and rebate questions may use a reusable archived answer. Customer-specific status, balance, amount, failure, missing-payment, credential, backend-protected, conflicting, ambiguous or operator-only enquiries stop for manual checking.
7. Copilot turns off when the selected LiveChat conversation changes or the page reloads. Turn it on separately for the intended chat.
8. Knowledge Hub categories organize conversations but never limit the global local search. Retrieve or import the required archive range in Knowledge Hub first; on-demand LiveChat archive lookup remains a bounded keyword fallback to avoid slow replies and API rate limits.
9. If keyword matching finds nothing and a Groq key is saved, multilingual query expansion searches English, Malay and Chinese wording across reviewed knowledge and the full local archive. It creates search terms only; the normal guarded drafting step still decides whether there is enough support.

FAST ARCHIVE INDEX (FOR LARGE HUBS)
1. After updating, close any old Knowledge Hub tabs, refresh LiveChat, then open Smart Reply > Settings > Archive performance.
2. Click Build / resume fast index. Existing raw threads, reviewed knowledge, labels and backups are not reset or deleted.
3. The one-time migration works in batches and shows indexed threads plus safe answer candidates. You may click Pause or close the page; click Build / resume later to continue from the saved position.
4. Copilot searches only bounded indexed candidates instead of scanning every raw thread. New retrieved and imported conversations are indexed automatically.
5. Until the status says Ready, search coverage is partial. Copilot shows this clearly and does not incorrectly save a missed question as unanswered.
6. Simple game-access complaints are handled locally before archive or AI lookup. Smart Reply asks which game failed and requests the error details or screenshot without guessing a cause.

LEARNING (REVIEWED ONLY)
1. When no supported answer exists, the extension masks and stores the safe general question locally. Open Settings > Learning queue to view or copy the missing questions and their counts.
2. After the extension prepares a genuinely reusable draft, check or edit it carefully. Tick the confirmation below Draft reply, then click Approve this draft as knowledge.
3. The approved question and answer become reviewed Knowledge Hub memory for later matching. Approval is blocked for account-specific results, statuses, amounts, credentials, secrets and other unsafe output.
4. Never approve a one-customer answer as general knowledge. Nothing is learned automatically, nothing is uploaded by the Learning queue, and Copilot still never sends.

ACCOUNT QUICK CHECK
1. Open Check. Smart Reply detects the login username and customer language from the current LiveChat conversation. Correct the username or choose Find from chat if the customer supplied another account.
2. Leave the period on Today, or choose Last 7 days. Pick Deposit, Promotion, or Withdrawal, then click the large Check button. Deposit and Promotion each search only their required report set. Withdrawal reads withdrawal, deposit, promotion and turnover together so its related Deposit and Promotion views can be opened immediately afterward without another search.
3. Deposit shows status, amount, requested time, confirm time, reference/transfer reference, and its conservative turnover cross-check. Only one uniquely matched MYR Finish record with the same turnover deposit and no newer pending deposit can recommend the full credited sentence with amount and confirmation time. The time is labelled backend time because its timezone is not inferred.
4. Promotion shows the claim status, remark, code/reference and confirm time separately from promotion-turnover status, required turnover, recorded bets and turnover confirm time. A full credited-bonus sentence requires one unique Confirmed claim whose remark explicitly says Credited and whose code matches the unconflicted turnover row. Otherwise Quick Check keeps the safe waiting/operator route; use the Promos tab for general promotion details.
5. Withdrawal shows status, amount, confirm time and backend remark, followed by promotion code, promotion confirm time, promotion turnover and promotion status. Requested time and reference are hidden from this compact result. It recognizes Payment closed, Unfinished turnover with an exact positive RM amount, Please submit bank, Holder not same, get full name, and belum main fs, then recommends the approved customer action in English, Malay, or Chinese. A recognized specific remark overrides a generic Payment closed status. Different specific causes, different turnover amounts, unknown wording, and Contact LiveChat remain operator-only. A calculated remaining-turnover amount is allowed only for one current unfinished promotion with matched deposit evidence and no conflicting obligation.
6. No Today match means only "No record found in today's loaded results"; it does not claim that no transaction exists. Use Try last 7 days when appropriate. A narrow Exact row result is allowed when Today shows exactly one matching MYR withdrawal row with a positive amount, numeric reference and valid request time, and its date matches the valid one-day report. Any of the six approved withdrawal mappings can then prepare its exact sentence immediately while leaving the pagination warning visible. A turnover sentence uses only the positive RM amount written in the displayed status or remark; it never calculates or guesses the amount.
7. The recommended full reply is editable. There is no extra withdrawal-reference checkbox. Click the highlighted result header, or focus it and press Enter or Space, to place the prepared reply directly into the empty LiveChat composer; Copy and Use in LiveChat remain available below. Every route rechecks the same chat and successful backend reports, and results expire after five minutes. It never sends or overwrites text. Unknown or conflicting wording, Contact LiveChat or operator instructions, negated wording, invalid evidence, multiple rows, date mismatches, and amountless or calculated paginated results keep the safe waiting/operator route. Ask operator prepares a concise handoff when human checking is needed.
8. Each LiveChat chat keeps its own username, language choice, period, category, result, cached related results and draft for this page session. Switching Customer A → B → A restores A's work and never displays a late A result in B.
9. Backend records remain local and are not sent to AI. Open Advanced account tools for the old full five-report overview, multi-username lookup, receipt review and manual fallbacks.
10. Quick Check uses larger labels, buttons, result values, warnings and reply text for easier reading. On narrow screens its controls and result rows stack vertically instead of shrinking the text.

PROMOS
1. When a customer types a promo code or name that is in your promo sheet, Auto reply puts the exact promo text in the message box, in the customer's language. Nothing is rewritten.
2. If the customer asks a question about the promo, the AI gets the real promo text and answers from it.
3. Find promo: type a few letters of a code or name, click the result, and the text goes in the message box.
4. Calculate: type for example deposit RM50 claim 100PPU, then click Calculate. The deposit, bonus, total balance and turnover for each game type are worked out from the numbers in the promo text (percentage, Min Deposit, Max Bonus, and lines like Webslot x5). Check the numbers before you send.
5. The calculator works only when the promo text has a percentage bonus. Fixed bonuses such as RM60 get RM8 are not calculated.
6. Turnover is worked out as (deposit + bonus) x multiplier, as in your example.

UPDATES

For everyone (juniors too)
1. Open the SR panel. The bottom shows your version. A red dot on the SR button means a new version is ready.
2. Double-click Update Smart Reply.bat in your Smart Reply folder. If Windows shows a blue box, click More info, then Run anyway.
3. When it says Done, click SR, then Reload now. Then press F5 on LiveChat.
4. Click What's new in the panel to read the release notes.
Your keys and settings are saved in the browser, not in the files, so an update never removes them.
If something goes wrong, the old files are in the backup folder that the updater shows (in your Temp folder).

For the owner (you)
1. One time: put smart-reply.zip and version.json on Google Drive. Share each as Anyone with the link, role Viewer. Only you may edit them. Whoever can change these two files can change what your juniors install, so never give edit rights to anyone else.
2. Make a direct link for each file: https://drive.google.com/uc?export=download&id=FILE_ID
   FILE_ID is the long text in the share link, between /d/ and /view.
3. Open update-config.json in the Smart Reply folder. Paste the link of version.json as versionUrl, and the link of smart-reply.zip as zipUrl. Save.
4. Zip your Smart Reply folder and send it to your juniors. They unzip it to their Desktop and use Load unpacked in brave://extensions, once.
5. For every new version you receive two files: smart-reply.zip and version.json. In Drive, right-click the existing file, choose Manage versions, then Upload new version. The links stay the same. Drive can take a few minutes to show the new file.
6. Juniors then see the red dot and run Update Smart Reply.bat.
The updater checks a checksum, so a damaged or changed download is refused.

GOOD TO KNOW
1. Your keys stay only in this browser. Never paste them in chats.
2. AI drafting sends chat text to Groq, so only use it where your company allows this. Live Copilot uses the same drafting route as Create customer reply and never sends the resulting LiveChat message itself.
3. If a reply is wrong, fix the sheet row, not the code.
