/* Label-driven report search only. No guessed input names and no account actions. */
(function(){
  const core=globalThis.SRAccountCore;
  const kind=()=>core&&location.origin==='https://mcd88.kg8.co'?Object.keys(core.paths).find(k=>core.paths[k]===location.pathname):null;
  const visible=e=>e.getClientRects().length>0&&!e.disabled&&getComputedStyle(e).visibility!=='hidden';
  function label(e){const labels=Array.from(e.labels||[]).map(l=>l.textContent),cell=e.closest('td'),names=[...new Set([e.getAttribute('aria-label'),...labels,cell?.previousElementSibling?.textContent].filter(Boolean).map(core.key).filter(Boolean))];return names.length===1?names[0]:'';}
  function unique(elements,names){const matches=elements.filter(e=>names.includes(label(e)));return matches.length===1?matches[0]:null;}
  function locate(){
    const type=kind();if(!type)return {error:'Not an allowed account-report path.'};
    if(document.querySelector('input[type="password"]'))return {error:'Log in yourself before checking this report.'};
    const matches=[];
    for(const form of Array.from(document.forms)){
      const action=new URL(form.getAttribute('action')||location.href,document.baseURI||location.href);
      if(action.origin!==location.origin||action.pathname!==location.pathname)continue;
      if(action.search&&(type!=='balance'||Array.from(action.searchParams.keys()).some(k=>k!=='id')||!/^\d+$/.test(action.searchParams.get('id')||'')||action.search!==location.search))continue;
      if(form.target&&!['_self',window.name].includes(form.target))continue;
      const controls=Array.from(form.elements).filter(visible),buttons=controls.filter(e=>e.tagName==='BUTTON'||e.tagName==='INPUT'&&['submit','button','image','reset'].includes(e.type));
      if(buttons.some(e=>/^(?:approve|reject|pay|payout|cancel withdrawal|delete|resubmit|confirm payment|批准|拒绝|付款|出款|取消|删除|重新提交|确认付款)$/i.test(core.clean(e.value||e.textContent))))continue;
      const submit=buttons.filter(e=>e.type==='submit'&&/^(?:submit|search|查询|提交|搜索)$/i.test(core.clean(e.value||e.textContent)));
      const inputs=controls.filter(e=>e.tagName==='INPUT'&&['text','search','date','datetime-local'].includes(e.type));
      const member=unique(inputs,type==='balance'?['membername','memberaccount','username']:['memberaccount','memberusername','username','loginusername']);
      const from=unique(inputs,['datestart','startdate']),to=unique(inputs,['dateend','enddate']);
      if(!member||submit.length!==1||(!['turnover','balance'].includes(type)&&(!from||!to)))continue;
      // Extra active filters could conceal records. Do not reset or click unknown controls.
      let restrictive=false;
      for(const e of controls){
        if(e===member||e===from||e===to||e.type==='hidden'||e.type==='submit'||e.type==='button'||e.type==='reset')continue;
        const name=label(e);
        if(e.tagName==='SELECT'){
          if(name==='currency'||name==='status')continue;
          const selected=e.options[e.selectedIndex];if(selected&&!/^(?:all|please select(?:\s*>*)?|ascending|descending|全部|所有)$/i.test(core.clean(selected.textContent)))restrictive=true;
        }else if(['checkbox','radio'].includes(e.type)){if(e.checked){const radioText=core.clean(Array.from(e.labels||[]).map(l=>l.textContent).join(' ')||e.nextSibling?.textContent);if(e.type!=='radio'||!/^(?:not use|upper|lower|same|ascending|descending)$/i.test(radioText))restrictive=true;}}
        else if(e.tagName==='INPUT'&&String(e.value||'').trim())restrictive=true;
      }
      if(restrictive)continue;
      const selects=controls.filter(e=>e.tagName==='SELECT');
      const currencyControls=selects.filter(e=>label(e)==='currency'),statusControls=selects.filter(e=>label(e)==='status');
      if(currencyControls.length>1||statusControls.length>1)continue;
      matches.push({form,member,from,to,button:submit[0],currency:unique(selects,['currency']),status:unique(selects,['status'])});
    }
    return matches.length===1?matches[0]:{error:'Cannot safely identify one unrestricted labelled report search form. Search this page manually, then use Read loaded reports. Checked radio/extra filters can require manual search.'};
  }
  function id(){return globalThis.__SRWithdrawalDocumentId||(globalThis.__SRWithdrawalDocumentId=Date.now().toString(36)+'-'+Math.random().toString(36).slice(2));}
  function inspect(){const r=locate();return r.error?{ready:false,error:r.error}:{ready:true,documentId:id(),member:core.who(r.member.value),currency:core.clean(r.currency?.options[r.currency.selectedIndex]?.textContent),statusFilter:core.clean(r.status?.options[r.status.selectedIndex]?.textContent)};}
  function set(input,value){if(!input)return;const formatted=input.type==='date'?value.slice(0,10):input.type==='datetime-local'?value.replace(' ','T'):value;Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,formatted);input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));if(input.value!==formatted)throw new Error('Report field did not accept its value.');}
  function option(select,text){if(!select)throw new Error('Report '+text+' filter label is not verified. Use manual search.');const options=Array.from(select.options).filter(o=>core.clean(o.textContent).toLowerCase()===text.toLowerCase());if(options.length!==1)throw new Error('The report filter has no unique '+text+' option. Use manual search.');select.value=options[0].value;select.dispatchEvent(new Event('change',{bubbles:true}));}
  function run(args){
    const r=locate();if(r.error)return {scheduled:false,error:r.error};
    if(!/^[a-zA-Z0-9_.-]{1,255}$/.test(args?.member||'')||!/^\d{4}-\d{2}-\d{2} 00:00:00$/.test(args?.from||'')||!/^\d{4}-\d{2}-\d{2} 23:59:59$/.test(args?.to||''))return {scheduled:false,error:'Invalid report search parameters.'};
    try{
      set(r.member,args.member);set(r.from,args.from);set(r.to,args.to);
      if(args.verifyMember&&kind()==='balance'){
        // A positive exact-member row proves existence even in a MYR-only list.
        // Missing or restricted filters must never be used to prove absence.
        if(r.currency)option(r.currency,Array.from(r.currency.options).some(o=>/^all$/i.test(core.clean(o.textContent)))?'All':'MYR');
        if(r.status&&Array.from(r.status.options).some(o=>/^all$/i.test(core.clean(o.textContent))))option(r.status,'All');
      }else if(kind()!=='turnover'){option(r.currency,'MYR');option(r.status,'All');}
    }catch(e){return {scheduled:false,error:e.message};}
    const previous=id();setTimeout(()=>{if(!kind()||!r.button.isConnected||cancelled.has(args.jobToken))return;const current=locate();if(!current.error&&current.form===r.form&&current.button===r.button&&core.who(current.member.value)===core.who(args.member))r.button.click();},150);
    return {scheduled:true,documentId:previous};
  }
  const cancelled=globalThis.__SRAccountCancelledJobs||(globalThis.__SRAccountCancelledJobs=new Set());
  function cancel(jobToken){if(jobToken)cancelled.add(jobToken);while(cancelled.size>500)cancelled.delete(cancelled.values().next().value);}
  globalThis.SRAccountSearch={inspect,run,label,cancel};
})();
