/* Account overview: local parsing and display only. No storage or network. */
(function(){
  const paths={balance:'/website/accounts/member_list.php',deposit:'/website/deposit/deposit_report.php',promotion:'/website/promotion/promotion_report.php',turnover:'/website/withdraw/withdraw_turnover.php',withdrawal:'/website/withdraw/withdraw_report.php'};
  const clean=value=>String(value||'').replace(/\s+/g,' ').trim();
  const key=value=>clean(value).toLowerCase().replace(/[^a-z0-9]/g,'');
  const who=value=>(String(value||'').split(/\r?\n/).map(v=>v.trim().replace(/^\+\s*/,'')) .find(v=>v&&!/^\([^)]*\)$/.test(v))||'').replace(/\s*\([^)]*\)\s*$/,'').toLowerCase();
  const number=value=>{const text=clean(value).replace(/,/g,'');return /^\d+(?:\.\d+)?$/.test(text)?Number(text):null;};
  const money=value=>value==null?'Not verified':'RM'+Number(value).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:3});
  const turnoverNumber=value=>value==null?'Not verified':Number(value).toLocaleString('en-US',{minimumFractionDigits:3,maximumFractionDigits:3});
  function columns(kind,labels){
    const names=labels.map(key),find=(...allowed)=>names.findIndex(v=>allowed.includes(v));
    let result;
    if(kind==='balance')result={member:find('account','username','member'),amount:find('balance'),currency:find('currency')};
    else if(kind==='deposit'||kind==='withdrawal')result={id:find('noid','id'),member:find('useragent','member','username'),status:find('status'),currency:find('currency'),amount:find('amount'),time:find('timeconfirmtime','requesttime','time'),remarks:kind==='withdrawal'?find('remark','remarks','reason','rejectreason'):-1,transferReference:kind==='deposit'?find('transferid'):-1};
    else if(kind==='promotion')result={id:find('noid','no','id'),member:find('user','username','member'),status:find('status'),code:find('code','promotioncode'),remarks:find('remark','remarks'),time:find('time','promotiontime'),confirmed:find('confirmtime','promotionconfirmtime')};
    else if(kind==='promotionTurnover')result={member:find('member'),code:find('promotioncode'),id:find('promotionlistid'),time:find('promotiontime'),confirmed:find('promotionconfirmtime'),bet:find('memberbetamount'),required:find('promotionturnover'),status:find('status')};
    else if(kind==='rebate')result={member:find('member'),amount:find('vipturnoverbonus'),confirmed:find('confirmtime'),end:find('endtime'),bet:find('memberbetamount'),required:find('promotionturnover'),status:find('status')};
    else if(kind==='providers')result={provider:find('provider'),bet:find('turnover')};
    else return null;
    const required=kind==='balance'?['member','amount','currency']:kind==='providers'?['provider','bet']:kind==='rebate'?['member','amount','confirmed','status']:kind==='promotion'||kind==='promotionTurnover'?['member','code','time','status']:['id','member','status','currency','amount','time'];
    return required.every(name=>result[name]>=0)?result:null;
  }
  function parse(kind,matrix){
    let cols,index=-1;
    for(let i=0;i<Math.min(matrix.length,30);i++){cols=columns(kind,matrix[i]);if(cols){index=i;break;}}
    if(index<0)return null;
    const out=[];
    for(const cells of matrix.slice(index+1)){
      const at=name=>cols[name]>=0?String(cells[cols[name]]||'').trim():'';
      if(kind==='providers'){const provider=clean(at('provider')),bet=number(at('bet'));if(provider&&bet!==null&&!/^all turnover/i.test(provider))out.push({provider,bet});continue;}
      const member=who(at('member'));if(!/^[a-z0-9_.-]{1,255}$/.test(member))continue;
      if(kind==='balance'){const amount=number(at('amount'));if(amount!==null)out.push({member,currency:clean(at('currency')),amount});continue;}
      const times=at('time').match(/\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}/g)||[];
      const row={member,status:clean(at('status')),requestedAt:times[0]||'',confirmedAt:clean(at('confirmed'))||times[1]||''};
      if(kind==='deposit'||kind==='withdrawal'){
        const ids=at('id').match(/\d{4,}/g);row.id=ids?.at(-1)||'';row.currency=clean(at('currency'));row.amount=number(at('amount'));if(!row.id||row.amount===null)continue;if(kind==='deposit')row.transferReference=clean(at('transferReference')).slice(0,150);
      }
      if(kind==='promotion'||kind==='promotionTurnover'){row.code=clean(at('code'));row.id=clean(at('id'));if(!row.code)continue;}
      if(kind==='promotionTurnover'||kind==='rebate'){row.bet=number(at('bet'));row.required=number(at('required'));}
      if(kind==='rebate'){row.amount=number(at('amount'));row.endAt=clean(at('end'));}
      if(kind==='withdrawal'||kind==='promotion')row.remarks=clean(at('remarks')).slice(0,400);
      out.push(row);
    }
    return out;
  }
  function latest(rows,time='requestedAt'){
    const valid=rows.filter(r=>/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(r[time]||'')).sort((a,b)=>b[time].localeCompare(a[time]));
    if(!valid.length||valid.length!==rows.length||valid.length>1&&valid[0][time]===valid[1][time])return null;
    return valid[0];
  }
  function validate(code,providers,promos){
    const matches=promos.filter(p=>clean(p.code).toLowerCase()===clean(code).toLowerCase());
    if(!matches.length)return 'Not verified: no exact promo-code rule. No alias was guessed.';
    const texts=[...new Set(matches.map(p=>clean(p.en)))];
    if(texts.length!==1||!texts[0])return 'Not verified: duplicate or missing English terms.';
    const text=texts[0],embedded=text.match(/promo\s*code\s*[:：]\s*([a-z0-9]+)/i);
    if(embedded&&embedded[1].toLowerCase()!==clean(code).toLowerCase())return 'Not verified: code column conflicts with the terms.';
    const slotOnly=/(?:webslot\s+only|only\s+for\s+webslot|only\s+(?:can\s+)?play\s+(?:at\s+)?webslot\s*(?:&|and)\s*appslot|for\s+all\s+slot\s+games\s+only)/i.test(text);
    const liveOnly=/(?:only\s+can\s+play\s+live\s*&\s*sport|for\s+(?:all\s+)?(?:live\s*\/\s*sport|sport)\s+games\s+only)/i.test(text);
    const excluded=(text.split(/not applicable\s*:|not allowed\s*:|excluding\s*:/i)[1]||'').split(/\n\s*\n/)[0];
    const restrictions=excluded.split(/[,、]/).map(clean).filter(Boolean);
    const flags=providers.filter(p=>p.bet>0).filter(p=>{
      const name=key(p.provider);
      return slotOnly&&/casino|sports?\b|fishing/i.test(p.provider)||liveOnly&&/\bslots?\b/i.test(p.provider)||restrictions.some(item=>key(item).length>=4&&name.includes(key(item)));
    });
    if(flags.length)return 'Potential mismatch: '+flags.map(p=>p.provider+' '+money(p.bet)).join('; ')+'. Report-wide totals; game category, claim-period attribution and consequence need operator review.';
    return 'No obvious provider-label mismatch found. Exact games, period, free-spin stages and historical rule version are not verified.';
  }
  // Owner-confirmed SPOTUN10 example: backend required turnover minus counted bets.
  // Do not apply this to winover, other codes, old periods or combined obligations.
  function turnoverSummary(report,username){
    if(!report||report.error||report.member!==username)return {value:'Not verified',note:'Turnover report unavailable or member not verified.'};
    const rows=report.promotionRows.filter(row=>row.member===username),rebates=report.rebateRows.filter(row=>row.member===username);
    const open=rows.filter(row=>/^unfinished$/i.test(row.status)),rebateOpen=rebates.filter(row=>/^unfinished$/i.test(row.status));
    const note='General deposit check: '+(report.baseStatus||'not shown')+'. '+open.length+' unfinished promotion record(s); '+rebateOpen.length+' unfinished rebate record(s).';
    if(open.length){
      const row=open[0];
      if(open.length===1&&/^SPOTUN10$/i.test(row.code)&&row.requestedAt&&row.requestedAt===report.duration?.[0]&&Number.isFinite(row.required)&&Number.isFinite(row.bet)&&row.bet>=0&&row.required>row.bet){
        const remaining=Math.round((row.required-row.bet)*100)/100;
        if(remaining<=0)return {value:'Unfinished promotion — manual check',note:note+' Remaining amount is below display precision.'};
        return {value:'Unfinished — '+money(remaining)+' remaining',note:'SPOTUN10 · 10% Sportsbook: '+money(row.required)+' required − '+money(row.bet)+' counted = '+money(remaining)+'. '+note+' Eligible-game checking is separate.',remaining,code:row.code};
      }
      return {value:'Unfinished promotion — manual check',note:note+' Remaining amount/active applicability is not verified for these records.'};
    }
    if(rebateOpen.length)return {value:'Unfinished rebate — manual check',note:note+' Active applicability needs review.'};
    return {value:report.baseStatus||'Not verified',note:note+' Withdrawal eligibility is not inferred.'};
  }
  const promotionName=code=>/^SPOTUN10$/i.test(code)?'10% Sportsbook':code;
  function depositReset(username,reports,confirmed=false){
    const valid=t=>{const m=String(t||'').match(/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/);return !!m&&Number(m[4])<24&&Number(m[5])<60&&Number(m[6])<60&&new Date(Date.UTC(Number(m[1]),Number(m[2])-1,Number(m[3]))).toISOString().slice(0,10)===t.slice(0,10);};
    const no=reason=>({applied:false,reason});
    if(!confirmed)return no('Previous-balance exhaustion before the new deposit has not been confirmed.');
    const dep=reports.deposit,prom=reports.promotion,turn=reports.turnover;
    if(!dep||dep.error||!prom||prom.error||!turn||turn.error||turn.member!==username)return no('Deposit, promotion or turnover report is unavailable/mismatched.');
    if(dep.pagination||prom.pagination||turn.pagination)return no('Complete deposit/promotion coverage is not verified (pagination).');
    const deposits=dep.rows.filter(x=>x.member===username&&x.currency==='MYR'&&/^finish$/i.test(x.status));
    const last=latest(deposits,'confirmedAt');if(!last||!valid(last.requestedAt)||!valid(last.confirmedAt)||!Number.isFinite(last.amount)||last.amount<=0)return no('A unique latest confirmed successful MYR deposit is required.');
    if(!/^all$/i.test(prom.statusFilter||''))return no('Promotion status filter must be All to verify no new claim/attempt.');
    const range=prom.dateRange||[];
    if(range.length!==2||range[0]>last.requestedAt||range[1]<turn.duration?.[1])return no('Promotion report date range does not cover the new deposit through the turnover report end.');
    if(turn.deposit!==last.amount||!turn.duration||turn.duration.length!==2||![last.requestedAt,last.confirmedAt].includes(turn.duration[0])||!Number.isFinite(turn.totalBet)||turn.duration[1]<last.confirmedAt)return no('Turnover duration/amount does not match the latest deposit.');
    const claims=prom.rows.filter(x=>x.member===username&&/^confirmed$/i.test(x.status));
    const old=turn.promotionRows.filter(x=>x.member===username);
    if(prom.rows.some(x=>x.member===username&&!/^confirmed$/i.test(x.status)&&(!valid(x.requestedAt)||x.requestedAt>=last.requestedAt)))return no('A new or undated promotion attempt needs manual review.');
    if(!old.length)return no('No previous promotion record to reset; use the normal deposit-only check.');
    if([...claims,...old].some(x=>!valid(x.confirmedAt)||!valid(x.requestedAt)))return no('Promotion confirmation/request time is missing.');
    if([...claims,...old].some(x=>x.confirmedAt>=last.confirmedAt||x.requestedAt>=last.requestedAt))return no('A promotion is at/after the new deposit; do not apply deposit-only x1.');
    const previous=latest(old,'confirmedAt');if(!previous||last.confirmedAt<=previous.confirmedAt)return no('New deposit confirmation is not strictly after the previous promotion confirmation.');
    const remaining=Math.max(0,Math.round((last.amount-turn.totalBet)*100)/100);
    return {applied:true,remaining,value:remaining>0?'Unfinished — '+money(remaining)+' deposit turnover remaining':'Finished — deposit ×1',reason:'Operator confirmed prior promotion balance exhaustion and no new promotion. Confirmed deposit '+last.confirmedAt+' is after previous promotion '+previous.confirmedAt+'. '+money(last.amount)+' × 1 − '+money(turn.totalBet)+' counted = '+money(remaining)+' remaining. All games count for this deposit-only check. Previous promotion rows are historical under this assertion; rebate requirements and withdrawal eligibility remain separate.'};
  }
  function turnoverInsight(username,report){
    const unavailable=message=>({verified:false,depositAt:'',periodEnd:'',deposit:null,totalBet:null,providers:[],promotion:null,interpretation:message});
    if(!report||report.error||report.member!==username)return unavailable(report?.error||'Turnover report unavailable or member not verified.');
    const duration=Array.isArray(report.duration)?report.duration.slice(0,2):[],validTime=value=>/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(value||'');
    if(duration.length!==2||!duration.every(validTime))return unavailable('Turnover duration is missing or invalid, so the latest-deposit time is not verified.');
    const providers=(report.providers||[]).filter(row=>Number.isFinite(row.bet)&&row.bet>0).sort((a,b)=>b.bet-a.bet||a.provider.localeCompare(b.provider));
    const promotionRows=(report.promotionRows||[]).filter(row=>row.member===username),promotion=latest(promotionRows,'confirmedAt');
    let interpretation='No unique latest promotion confirmation was found in Checking Turnover Status. Do not infer that no promotion balance exists.';
    if(promotion){
      if(promotion.confirmedAt>duration[0])interpretation='Promotion confirmed after the latest-deposit time, so this promotion record is inside the current deposit turnover period. Backend status: '+(promotion.status||'not shown')+'. Remaining promotion balance and withdrawal eligibility are not inferred.';
      else if(promotion.confirmedAt<duration[0]&&/^unfinished$/i.test(promotion.status))interpretation='A newer deposit is shown, but this promotion is still marked Unfinished. The new deposit/play remains under the shown promotion turnover until the backend status changes.';
      else if(promotion.confirmedAt<duration[0]&&/^finish(?:ed)? turnover$/i.test(promotion.status))interpretation='The latest deposit is after this finished promotion. No unfinished promotion turnover is shown, but exhaustion of the promotion balance is not proved by timestamps alone.';
      else if(promotion.confirmedAt<duration[0])interpretation='The latest deposit is after this promotion confirmation, but the promotion status is not an approved Finished/Unfinished value. Operator review is required.';
      else interpretation='Promotion confirmation time equals the latest-deposit time. Their order and applicability are not verified.';
    }
    return {verified:true,depositAt:duration[0],periodEnd:duration[1],deposit:Number.isFinite(report.deposit)?report.deposit:null,totalBet:Number.isFinite(report.totalBet)?report.totalBet:null,providers,promotion,interpretation};
  }
  function quickSummary(username,reports){
    const kinds=['balance','deposit','promotion','turnover','withdrawal'],warnings=[],source={};
    for(const kind of kinds){
      const report=reports[kind];
      if(!report||report.error){warnings.push(kind+': '+(report?.error||'report unavailable'));continue;}
      source[kind]={readAt:report.readAt||'',dateRange:Array.isArray(report.dateRange)?report.dateRange.slice(0,2):[],pagination:!!report.pagination,manual:!!report.manual};
      if(report.pagination)warnings.push(kind+': pagination detected, so the latest record across every page is not verified.');
      if(report.manual)warnings.push(kind+': the loaded report was read after an operator-confirmed manual search.');
    }
    const missing=(kind,message)=>({verified:false,value:'Not verified',note:message||'Report unavailable.'});
    let report=reports.balance,rows=report&&!report.error?report.rows.filter(row=>row.member===username&&row.currency==='MYR'):[];
    const balance=report&&!report.error&&rows.length===1?{verified:true,value:money(rows[0].amount),note:'Current member-list snapshot. Wallet coverage and history are not verified.'}:missing('balance',report?.error||'A unique exact-member MYR balance was not found.');
    report=reports.deposit;rows=report&&!report.error?report.rows.filter(row=>row.member===username&&row.currency==='MYR'):[];let row=latest(rows);
    const deposit=row?{verified:true,value:money(row.amount),note:'Backend status: '+(row.status||'not shown')+' · Requested '+row.requestedAt+(row.confirmedAt?' · Confirmed '+row.confirmedAt:''),row}:missing('deposit',report?.error||'No unique latest MYR deposit was found in the loaded period.');
    report=reports.promotion;rows=report&&!report.error?report.rows.filter(row=>row.member===username):[];row=latest(rows);
    const promotion=row?{verified:true,value:row.code,note:'Backend status: '+(row.status||'not shown')+' · Claimed '+row.requestedAt+(row.confirmedAt?' · Confirmed '+row.confirmedAt:''),row}:missing('promotion',report?.error||'No unique latest promotion was found in the loaded period.');
    const turnover=turnoverInsight(username,reports.turnover);
    report=reports.withdrawal;rows=report&&!report.error?report.rows.filter(row=>row.member===username&&row.currency==='MYR'):[];row=latest(rows);
    const withdrawal=row?{verified:true,value:row.status||'Status not shown',note:'Ref '+row.id+' · '+money(row.amount)+' · Requested '+row.requestedAt+(row.confirmedAt?' · Confirmed '+row.confirmedAt:''),remark:row.remarks||'',row}:missing('withdrawal',report?.error||'No unique latest MYR withdrawal was found in the loaded period.');
    return {username,balance,deposit,promotion,turnover,withdrawal,source,warnings};
  }
  function summarize(username,reports,promos,ruleError='',options={}){
    const lines=['Username: '+username,'Operator-only account overview — not a customer reply.'],warnings=[];
    const get=kind=>{const r=reports[kind];if(!r||r.error){lines.push(kind.charAt(0).toUpperCase()+kind.slice(1)+': Not verified — '+(r?.error||'report unavailable'));return null;}if(r.pagination)warnings.push(kind+': pagination detected; latest/global completeness not verified.');if(r.manual)warnings.push(kind+': manually loaded report; operator confirmed the search.');lines.push('['+kind+'] Read '+r.readAt+' · '+(r.dateRange?.join(' — ')||'report duration shown below'));return r;};
    const balance=reports.balance;if(balance&&!balance.error){const matches=balance.rows.filter(x=>x.member===username&&x.currency==='MYR');lines.push('Current balance: '+(matches.length===1?money(matches[0].amount):'Not verified — exact unique member balance required.')+' · Read '+balance.readAt+' · Wallet coverage/history not verified.');}else lines.push('Current balance: Not verified — '+(balance?.error||'report unavailable'));
    const reset=depositReset(username,reports,!!options.resetConfirmed);
    if(options.resetConfirmed)lines.push('New-deposit reset: '+(reset.applied?'APPLIED — ':'NOT APPLIED — ')+reset.reason);
    let depositCandidate=null,promotionCandidate=null;
    let r=get('deposit');if(r){const rows=r.rows.filter(x=>x.member===username&&x.currency==='MYR'&&/^finish$/i.test(x.status)),last=latest(rows);depositCandidate=last;lines.push('Last deposit'+(r.pagination?' candidate':' (loaded range)')+': '+(last?money(last.amount)+' · '+last.requestedAt+' · Confirmed '+(last.confirmedAt||'not shown')+' · Ref '+last.id+' · Status '+last.status:'Not verified — no unique latest MYR Finish record in loaded rows.'));}
    r=get('promotion');if(r){const rows=r.rows.filter(x=>x.member===username&&/^confirmed$/i.test(x.status)),last=latest(rows);promotionCandidate=last;lines.push('Promotion'+(r.pagination?' candidate':' (latest confirmed in loaded range)')+': '+(last?last.code+' · Claimed '+last.requestedAt+' · Confirmed '+(last.confirmedAt||'not shown'):'No unique latest confirmed claim found; full history not verified.'));}
    r=get('turnover');if(r){
      const promo=r.promotionRows.filter(x=>x.member===username),rebate=r.rebateRows.filter(x=>x.member===username),unfinished=promo.filter(x=>/^unfinished$/i.test(x.status));
      const aligned=!depositCandidate||(depositCandidate.amount===r.deposit&&depositCandidate.requestedAt===r.duration?.[0]);
      const conflictingClaim=promotionCandidate&&r.duration?.length===2&&promotionCandidate.requestedAt>=r.duration[0]&&promotionCandidate.requestedAt<=r.duration[1]&&!promo.length;
      if(!aligned)warnings.push('Deposit and turnover snapshots differ in amount or start time. Refresh and check; no deposit-only completion inferred.');
      if(conflictingClaim)warnings.push('Promotion report contains a claim in this turnover duration but no matching promotion turnover rows are shown. No deposit-only completion inferred.');
      lines.push('Turnover report duration: '+(r.duration?.join(' — ')||'not verified'));
      if(r.deposit!==null&&r.totalBet!==null)lines.push('Turnover report deposit: '+money(r.deposit)+' · Recorded bets '+money(r.totalBet));
      if(promo.length){lines.push('Promotion turnover: '+unfinished.length+' unfinished record(s); active/expired applicability not verified.');for(const row of promo.slice(0,20)){lines.push('• '+row.code+' · '+row.status+' · Claim '+row.requestedAt+' · Ref '+row.id);lines.push('  Game check: '+(ruleError?'Not verified — '+ruleError:validate(row.code,r.providers,promos)));}}
      else if(aligned&&!conflictingClaim&&!r.promotionTable&&r.deposit!==null&&r.totalBet!==null&&r.member===username&&r.duration?.length===2){lines.push('Promotion turnover: no promotion rows shown in this loaded report.');lines.push('Deposit turnover (owner rule, no promotion shown): '+money(r.deposit)+' × 1 = '+money(r.deposit)+'; recorded '+money(r.totalBet)+' → '+(r.totalBet>=r.deposit?'Finished':'Unfinished')+'. All games count for this deposit-only check.');}
      else lines.push('Turnover: Not verified — promotion history/member/duration or totals are incomplete.');
      const summary=reset.applied?{value:reset.value,note:reset.reason}:turnoverSummary(r,username);lines.push('Turnover summary: '+summary.value+' · '+summary.note);
      if(r.baseStatus)lines.push('General turnover status shown: '+r.baseStatus+' (separate from promotion/rebate status).');
      const last=latest(rebate,'confirmedAt');lines.push('Daily rebate: '+(last?money(last.amount)+' · Credited at '+last.confirmedAt+' (owner-confirmed meaning) · Turnover '+last.status:'No unique latest rebate shown.'));
      const remaining=rebate.filter(x=>/^unfinished$/i.test(x.status));if(remaining.length)lines.push('Rebate turnover: '+remaining.length+' unfinished record(s); applicability needs review.');
      const active=r.providers.filter(p=>p.bet>0);if(active.length)lines.push('Provider activity: '+active.map(p=>p.provider+' '+money(p.bet)).join('; '));
      if(promo.length>20)warnings.push('Only first 20 promotion rows displayed. Full report needs review.');
    }
    r=get('withdrawal');if(r){const rows=r.rows.filter(x=>x.member===username&&x.currency==='MYR'),last=latest(rows);lines.push('Withdrawal'+(r.pagination?' candidate':' (latest in loaded range)')+': '+(last?'Ref '+last.id+' · '+last.currency+' '+last.amount+' · '+last.status+' · '+last.requestedAt:'No unique latest withdrawal found; do not conclude there are none.'));if(last)lines.push('Withdrawal remark: '+(last.remarks||'No remark shown; no reason inferred.'));}
    lines.push('Rules: '+(ruleError?'Not verified — '+ruleError:'Refreshed from Google Sheets for this check. Historical applicability is not verified.'));
    lines.push('Report timestamps are shown verbatim; backend timezone is not verified.');
    lines.push('Withdrawal approval/payment eligibility: Not inferred.');
    if(warnings.length)lines.push('Coverage warnings:\n'+warnings.join('\n'));
    return lines.join('\n');
  }
  const api={paths,clean,key,who,number,money,turnoverNumber,columns,parse,latest,validate,turnoverInsight,quickSummary,summarize,turnoverSummary,promotionName,depositReset};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else globalThis.SRAccountCore=api;
})();
